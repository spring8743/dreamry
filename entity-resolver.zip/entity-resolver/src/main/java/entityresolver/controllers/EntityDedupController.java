package entityresolver.controllers;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Example;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import entityresolver.models.EntityDedup;
import entityresolver.models.EntityDedupDao;
import entityresolver.models.EntityRules;


@Controller 
@RequestMapping(path="/entitydedup") 
public class EntityDedupController {
	
	@Autowired // This means to get the bean called userRepository
	private EntityDedupDao entityDedupRepository;
	
	@Autowired
	private EntityResolverController entityResolverController;
	
	@Autowired 
	private EntityUtilityController entityUtilityController;
	
	ArrayList<EntityDedup> partyCsv = null;
	
	//threshold to determine two party name match or not
	Double threshold = 0.068;
	
	//Temperary folder to store the download csv file
	private String outputPath = "c://work//entity_resolution//party_resolution_2019-07-01.csv";
	
	/**
	 * This method is used to upload CSV file and save to DB from front-end UI
	 * @param file
	 * @throws IllegalStateException
	 * @throws IOException
	 */
	@CrossOrigin
	@ResponseBody
    @RequestMapping(value="/uploadCsv", method = RequestMethod.POST)
    public void uploadCsv(@RequestParam("file") MultipartFile file) throws IllegalStateException, IOException {
		 //Define variable for each line
		 String line;
		 
		 partyCsv = new ArrayList<EntityDedup>();
//		 EntityResolverController entityResolverController = new EntityResolverController();
		 
		 List<EntityRules> nameRules= entityUtilityController.getRule("name_rules");
		 List<EntityRules> shortenRules = entityUtilityController.getRule("shorten_rules");
		 List<EntityRules> nullRules = entityUtilityController.getRule("null_rules");
		 
		 //Read the upload csv file content
	     InputStream is = file.getInputStream();
	     BufferedReader br = new BufferedReader(new InputStreamReader(is));
	     //Skip the first line 'header'
	     br.readLine();
	     while ((line = br.readLine()) != null) {
	    	 //Since it's csv file, split the party_name and party_cuntry by comma
	    	 
	    	 EntityDedup entity = new EntityDedup();
	    	 entity.setEntityName(line.split(",")[0]);
	    	 entity.setEntityNameStd(entityUtilityController.partyCleanup(line.split(",")[0], nameRules, shortenRules, nullRules));
	    	 entity.setEntityCountry(line.split(",")[1]);
//	    	 entityDedupRepository.save(entity);
	    	 partyCsv.add(entity);
	     }
		
    	 System.out.println("upload request successfully ");
    }


	/**
	 * This method is used when user click the submit button on the front-end UI
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@CrossOrigin
	@ResponseBody
	@RequestMapping(value="/submitCsv", method = RequestMethod.GET)
	public ResponseEntity<InputStreamResource>  submitCsv(HttpServletRequest request) throws IOException {
		
		for(int i= 0; i <= partyCsv.size()-2; i ++) {
			if(partyCsv.get(i).getEntityNameref() != null) continue;
			
			for(int j= i + 1; j <= partyCsv.size()-1; j++) {
				if(partyCsv.get(i).getEntityCountry().equalsIgnoreCase("NULL") || partyCsv.get(i).getEntityCountry().equalsIgnoreCase(partyCsv.get(j).getEntityCountry())) {
					Double distance = entityUtilityController.calculateDistance(partyCsv.get(i).getEntityNameStd(), partyCsv.get(j).getEntityNameStd());
					
					if(distance <= threshold) {
						partyCsv.get(i).setEntityNameref(partyCsv.get(i).getEntityName());
						partyCsv.get(i).setEntityCountryref(partyCsv.get(i).getEntityCountry());
						partyCsv.get(i).setConfidence(1.0);
						partyCsv.get(j).setEntityNameref(partyCsv.get(i).getEntityName());
						partyCsv.get(j).setEntityCountryref(partyCsv.get(i).getEntityCountry());
						partyCsv.get(j).setConfidence(1- distance);
					}
				}
				
			}
		}
		
		// write request result to local folder first
		BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath));
		// write the header
		writer.write("EntityName, EntityCountry, EntityNameStd, EntityNameRef, EntityCountryRef, MatchConfidence \n");
				
		for(EntityDedup entity : partyCsv) {
			//save to database
//			entityDedupRepository.save(entity);
			
			writer.write(entity.getEntityName() + "," + entity.getEntityCountry() + "," + entity.getEntityNameStd() + "," + entity.getEntityNameref() + "," + entity.getEntityCountryref() + "," + entity.getConfidence() + "\n");
			System.out.println(entity.getEntityName() + " | " + entity.getEntityCountry() + " | " + entity.getEntityNameStd() + " | " + entity.getEntityNameref() + " | " + entity.getEntityCountryref() + " | " + entity.getConfidence());
		}
		
		writer.close();
		
		System.out.println("submit request successfully ");
		InputStreamResource resource = new InputStreamResource(new FileInputStream(new File(outputPath)));
		
		//set the http request header
		HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=party_resolution.csv");
        header.add("Cache-Control", "no-cache, no-store, must-revalidate");
        header.add("Pragma", "no-cache");
        header.add("Expires", "0");

	    return ResponseEntity.ok()
	            .headers(header)
	            .contentType(MediaType.parseMediaType("application/octet-stream"))
	            .body(resource);
	}
}
