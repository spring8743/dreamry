package entityresolver.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.wcohen.ss.JaroWinkler;

import entityresolver.models.EntityRules;
import entityresolver.models.EntityRulesDao;
import entityresolver.models.SciClient;
import entityresolver.models.SciClientDao;

import org.springframework.data.domain.Example;



@Controller    // This means that this class is a Controller
public class EntityUtilityController {
	
	@Autowired // This means to get the bean called userRepository
	private EntityRulesDao entityRulesRepository;
	
	@Autowired // This means to get the bean called userRepository
	private SciClientDao sciClientRepository;
	
    /**
     * get all the rules by ruleType
     * @param ruleType
     * @return
     */
	public List<EntityRules> getRule(String ruleType) {
		EntityRules rules = new EntityRules();
		rules.setRuleType(ruleType);
		Example example = Example.of(rules);
		
		//get the rules by ruleType 
		return entityRulesRepository.findAll(example);
		
	}
	
	/**
	 * getSciByBlock to feach the sci list by block
	 * @param block
	 * @return
	 */
	public List<SciClient> getSciByBlock(String block) {
		SciClient sci = new SciClient();
		sci.setLongNameBlock(block);
		Example example = Example.of(sci);
		
		return sciClientRepository.findAll(example);
		
	}
	
	/**
	 * calculateDistance to calculate the distance base on party_name and sci name
	 * @param leftStr
	 * @param rightStr
	 * @return
	 */
	public double calculateDistance(String leftStr, String rightStr) {
		JaroWinkler jaroWinkler = new JaroWinkler();
		Double distance = 1 - jaroWinkler.score(leftStr, rightStr);
		return distance;
	}
	
	
	/**
	 * partyCleanup to do remove the special character and standardlize the party name
	 * @param party_name
	 * @return
	 */
	public String partyCleanup(String party_name, List<EntityRules> nameRules, List<EntityRules> shortenRules, List<EntityRules> nullRules) {
		//call the formatSpecialChar
    	party_name = formatSpecialChar(party_name);
    	//apply different rules for the party name
    	party_name = getStandardName(party_name, nameRules);
    	party_name = getStandardName(party_name, shortenRules);
    	party_name = getStandardName(party_name, nullRules);
    	
    	//replace the BLANK to space
    	party_name = party_name.replaceAll("BLANK", "").replaceAll("\\s+", " ").trim();
    	
    	return party_name;
    }
    
    /**
     * formatSpecialChar
     * @param party_name
     * @return
     */
    private  String formatSpecialChar(String party_name) {
    	String format_party_name = party_name.toUpperCase().replaceAll("[^a-zA-Z0-9\\s]", " ").replaceAll("\\s+", " ").trim();
    	return format_party_name;
    }
    
    /**
     * This method is used to get standard name from different rules
     * @param party_name
     * @param rule_name
     * @return
     */
    private  String getStandardName(String party_name, List<EntityRules> ruleList) {
    	String std_party_name =  new String();
    	Boolean findFlag = false;
    	
		for (EntityRules obj : ruleList) {
			//If we find the rule input str
			if (party_name.indexOf(obj.getInputStr()) > -1) {
				std_party_name = new String();
				//We need to split the party_name to get full match
				for (String subName : party_name.split(" ")) {
					if (subName.equalsIgnoreCase(obj.getInputStr())) {
						//replace the match words
						subName = obj.getStandardStr();
						findFlag = true;
					}
					std_party_name += subName + " ";
				}

				if (findFlag == true) {
					party_name = std_party_name;
				} else {
					std_party_name = new String();
				}
			}
		}

    	return party_name;
    }

    
    
	
	
}
