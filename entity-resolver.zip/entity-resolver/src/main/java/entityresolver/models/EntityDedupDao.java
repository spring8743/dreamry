package entityresolver.models;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EntityDedupDao extends JpaRepository<EntityDedup, Long>{ 

}
