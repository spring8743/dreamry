package entityresolver.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity // This tells Hibernate to make a table out of this class
@Table(name = "entity_dedup")
@EntityListeners(AuditingEntityListener.class)
public class EntityDedup {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "entity_id", updatable = false, nullable = false)
    private Long entityId;
	
	@Column(name = "entity_name")
	private String entityName;
	
	@Column(name = "entity_country")
	private String entityCountry;
	
	@Column(name = "entity_namestd")
	private String entityNameStd;
	
	@Column(name = "entity_name_ref")
	private String entityNameref;
	
	@Column(name = "entity_country_ref")
	private String entityCountryref;
	
	@Column(name = "confidence")
	private Double confidence;

	public Double getConfidence() {
		return confidence;
	}

	public void setConfidence(Double confidence) {
		this.confidence = confidence;
	}

	public String getEntityNameref() {
		return entityNameref;
	}

	public void setEntityNameref(String entityNameref) {
		this.entityNameref = entityNameref;
	}

	public String getEntityCountryref() {
		return entityCountryref;
	}

	public void setEntityCountryref(String entityCountryref) {
		this.entityCountryref = entityCountryref;
	}

	public Long getEntityId() {
		return entityId;
	}

	public void setEntityId(Long entityId) {
		this.entityId = entityId;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getEntityCountry() {
		return entityCountry;
	}

	public void setEntityCountry(String entityCountry) {
		this.entityCountry = entityCountry;
	}

	public String getEntityNameStd() {
		return entityNameStd;
	}

	public void setEntityNameStd(String entityNameStd) {
		this.entityNameStd = entityNameStd;
	}
}
