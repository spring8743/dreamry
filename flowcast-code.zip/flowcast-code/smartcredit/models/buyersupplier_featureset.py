# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/models/buyersupplier_featureset.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 619 bytes
from sqlalchemy import text
from sqlalchemy.dialects.postgresql import JSONB
from smartcredit.models import db

class BuyerSupplierFeatureSetModel(db.Model):
    __tablename__ = 'buyersupplier_featureset'
    id = db.Column(db.Integer, primary_key=True, autoincrement='auto')
    timestamp = db.Column(db.TIMESTAMP(timezone=True), nullable=False, server_default=text('now()'))
    buyer_id = db.Column(db.VARCHAR, index=True, nullable=False)
    supplier_id = db.Column(db.VARCHAR, index=True, nullable=False)
    doc_date = db.Column(db.TIMESTAMP(timezone=True), nullable=False)
    features = db.Column(JSONB)