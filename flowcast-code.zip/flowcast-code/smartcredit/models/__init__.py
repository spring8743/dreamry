# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/models/__init__.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 1092 bytes
import os, dotenv, inspect
from flowcast.config import BaseConfig
from sqlalchemy_wrapper import SQLAlchemy

def get_connection_string():
    dotenv_filename = 'db.env'
    dotenv_path = os.environ.get('SCR_DB', None)
    if not dotenv_path:
        dotenv_dir = os.path.dirname(os.path.abspath(inspect.stack()[-1][1]))
        dotenv_path = os.path.join(dotenv_dir, dotenv_filename)
    sc_config = (BaseConfig(section='postgres', paths=dotenv_path)).get()
    user = sc_config.pg_user
    host = sc_config.pg_host
    password = sc_config.pg_password
    port = sc_config.pg_port
    dbname = sc_config.pg_database
    return 'postgresql://%s:%s@%s:%s/%s' % (
     user, password, host, port, dbname)


db = SQLAlchemy(get_connection_string())
from .client_featureset import ClientFeatureSetModel
from .buyersupplier_featureset import BuyerSupplierFeatureSetModel
from .currency_featureset import CurrencyFeatureSetModel
from .prediction import PredictionModel
from .transaction import TransactionModel
from .transactionhistory import TransactionHistoryModel