# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/models/transactionhistory.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 2291 bytes
from flowcast.db.hive import Model, TimestampColumn, StringColumn, IntColumn, DoubleColumn

class TransactionHistoryModel(Model):
    _tablename_ = 'scr_history'
    buyer_country = StringColumn(nullable=True)
    buyer_id = StringColumn()
    credit_grade = StringColumn()
    cty_code = StringColumn()
    cust_leid = StringColumn()
    doc_ccy_adj_amt = DoubleColumn()
    doc_ccy_amt = DoubleColumn()
    doc_ccy_code = StringColumn()
    doc_date = StringColumn()
    doc_id = StringColumn()
    doc_type_code = StringColumn()
    dr = DoubleColumn()
    due_date = StringColumn()
    fin_tenor = IntColumn()
    fin_tenor_start_date = StringColumn()
    grace_period = IntColumn()
    industry_sector = StringColumn()
    isic_code = StringColumn()
    late_days = IntColumn()
    maturity_date = StringColumn()
    product_code = StringColumn()
    pymt_alloc_amt = DoubleColumn()
    pymt_ccy_code = StringColumn()
    pymt_to_doc_fx_rate = DoubleColumn()
    supplier_country = StringColumn()
    supplier_id = StringColumn()
    tenor = IntColumn()
    tenor_start_date = StringColumn()
    year_rate = DoubleColumn()
    goods_category_code = StringColumn(nullable=True)
    goods_desc = StringColumn(nullable=True)
    ship_from = StringColumn(nullable=True)
    ship_to = StringColumn(nullable=True)
    pymt_value_date = StringColumn(nullable=True)
    supplier_name = StringColumn(nullable=True)
    buyer_name = StringColumn(nullable=True)
    sci_city = StringColumn(nullable=True)
    sci_state = StringColumn(nullable=True)
    sci_address_line_1 = StringColumn(nullable=True)
    sci_address_line_2 = StringColumn(nullable=True)

    @classmethod
    def query_all(cls, limit=None):
        query = '\n            SELECT * FROM {table_name}\n            {limit_clause}\n        '
        table_name = cls._tablename_
        if limit:
            if not type(limit) == int:
                raise Exception('Limit must be an integer.')
            limit = 'LIMIT %s ' % limit
        else:
            limit = ''
        query = query.format(table_name=table_name, limit_clause=limit)
        return cls.models_from_query(query)