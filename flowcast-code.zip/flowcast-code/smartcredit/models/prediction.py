# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/models/prediction.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 3759 bytes
from flowcast.db.hive import Model, TimestampColumn, StringColumn, IntColumn, DoubleColumn

class PredictionModel(Model):
    _tablename_ = 'doc_pred_daily'
    load_time_stamp = TimestampColumn()
    model_version = StringColumn()
    buyer_country = StringColumn(nullable=True)
    buyer_id = StringColumn()
    doc_date = TimestampColumn()
    doc_id = StringColumn()
    doc_usd_amt = DoubleColumn()
    leid = StringColumn()
    product = StringColumn()
    pymt_alloc_amt = DoubleColumn()
    pymt_to_doc_fx_rate = DoubleColumn()
    year_rate = DoubleColumn()
    dr = DoubleColumn(nullable=True)
    dr_buckets = DoubleColumn(nullable=True)
    supplier_country = StringColumn(nullable=True)
    supplier_id = StringColumn()
    late_days = IntColumn(nullable=True)
    late_days_buckets = DoubleColumn(nullable=True)
    dr_buckets_pred = IntColumn()
    dr_buckets_pred_0 = DoubleColumn()
    dr_buckets_pred_1 = DoubleColumn()
    dr_buckets_pred_2 = DoubleColumn()
    dr_buckets_pred_3 = DoubleColumn()
    dr_buckets_pred_4 = DoubleColumn()
    dr_buckets_pred_5 = DoubleColumn(nullable=True)
    dr_buckets_pred_6 = DoubleColumn(nullable=True)
    dr_buckets_pred_7 = DoubleColumn(nullable=True)
    dr_buckets_pred_8 = DoubleColumn(nullable=True)
    dr_buckets_pred_9 = DoubleColumn(nullable=True)
    dr_buckets_pred_confidence = DoubleColumn()
    dr_explanation_column_1 = StringColumn(nullable=True)
    dr_explanation_column_2 = StringColumn(nullable=True)
    dr_explanation_column_3 = StringColumn(nullable=True)
    dr_explanation_column_4 = StringColumn(nullable=True)
    dr_explanation_column_5 = StringColumn(nullable=True)
    dr_explanation_value_1 = DoubleColumn(nullable=True)
    dr_explanation_value_2 = DoubleColumn(nullable=True)
    dr_explanation_value_3 = DoubleColumn(nullable=True)
    dr_explanation_value_4 = DoubleColumn(nullable=True)
    dr_explanation_value_5 = DoubleColumn(nullable=True)
    late_days_buckets_pred = IntColumn()
    late_days_buckets_pred_0 = DoubleColumn()
    late_days_buckets_pred_1 = DoubleColumn()
    late_days_buckets_pred_2 = DoubleColumn()
    late_days_buckets_pred_3 = DoubleColumn()
    late_days_buckets_pred_4 = DoubleColumn()
    late_days_buckets_pred_5 = DoubleColumn()
    late_days_buckets_pred_6 = DoubleColumn(nullable=True)
    late_days_buckets_pred_7 = DoubleColumn(nullable=True)
    late_days_buckets_pred_8 = DoubleColumn(nullable=True)
    late_days_buckets_pred_9 = DoubleColumn(nullable=True)
    late_days_buckets_pred_confidence = DoubleColumn()
    late_days_explanation_column_1 = StringColumn(nullable=True)
    late_days_explanation_column_2 = StringColumn(nullable=True)
    late_days_explanation_column_3 = StringColumn(nullable=True)
    late_days_explanation_column_4 = StringColumn(nullable=True)
    late_days_explanation_column_5 = StringColumn(nullable=True)
    late_days_explanation_value_1 = DoubleColumn(nullable=True)
    late_days_explanation_value_2 = DoubleColumn(nullable=True)
    late_days_explanation_value_3 = DoubleColumn(nullable=True)
    late_days_explanation_value_4 = DoubleColumn(nullable=True)
    late_days_explanation_value_5 = DoubleColumn(nullable=True)

    @classmethod
    def query_all(cls, limit=None):
        query = '\n            SELECT * FROM {table_name}\n            {limit_clause}\n        '
        table_name = cls._tablename_
        if limit:
            if not type(limit) == int:
                raise Exception('Limit must be an integer.')
            limit = 'LIMIT %s ' % limit
        else:
            limit = ''
        query = query.format(table_name=table_name, limit_clause=limit)
        return cls.models_from_query(query)