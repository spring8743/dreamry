# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/scripts/apischemacreator.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 7073 bytes
import genson, json, os, argparse
from smartcredit import SCBModel

class APISchemaGenerator:
    model_schema_filename = 'model_schema.json'
    api_schema_filename = 'api_schema.json'
    extra_info_filename = 'api_schema_extra_info.json'

    def __init__(self, models_folder, model_name):
        self.models_folder = models_folder
        self.model_name = model_name

    def load_api_schema_extra_info(self):
        extra_info_folder = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), 'misc')
        extra_info_filepath = os.path.join(extra_info_folder, APISchemaGenerator.extra_info_filename)
        with open(extra_info_filepath) as (extra_info_file):
            extra_info = json.loads(extra_info_file.read())
        return extra_info

    def generate(self):
        model = SCBModel(self.models_folder, self.model_name)
        model.load_model_schema()
        model_schema = model.model_schema['model_fields']
        extra_info = self.load_api_schema_extra_info()
        numeric_fields = list(set(model_schema['numeric_features']) - set(model_schema['client_features']) - set(model_schema['buyer_supplier_features']) - set(model_schema['external_currency_features']) - set(extra_info['prediction_time_fields']))
        string_fields = list(set(model_schema['categorical_features']) - set(extra_info['prediction_time_fields']))
        builder = genson.SchemaBuilder()
        builder.add_schema({'type':'object',  'properties':{}})
        for field_name in numeric_fields:
            field_value = 1.0
            builder.add_object({field_name: field_value})

        for field_name in string_fields:
            field_value = 'str'
            builder.add_object({field_name: field_value})

        schema = builder.to_schema()
        allowed_values = model_schema['allowed_values']
        for field_name in string_fields:
            field_allowed_values = allowed_values[field_name]
            schema['properties'][field_name]['enum'] = field_allowed_values

        required = []
        for field_name, field_details in extra_info['additional_fields'].items():
            if field_details.get('required', False):
                required.append(field_name)
                del extra_info['additional_fields'][field_name]['required']
            schema['properties'][field_name] = field_details

        for field_name, field_details in extra_info['field_details'].items():
            schema['properties'][field_name].update(field_details)

        for field_name in numeric_fields + string_fields:
            if field_name not in model_schema['allow_null']:
                required.append(field_name)

        if required:
            schema['required'] = required
        for field_name in schema['properties'].keys():
            schema['properties'][field_name]['$id'] = '#/properties/data/properties/attributes/properties/predictors/items'
            schema['properties'][field_name]['$id'] += '/properties/%s' % field_name

        schema['additionalProperties'] = False
        schema['$id'] = '#/properties/data/properties/attributes/properties/predictors/items/'
        del schema['$schema']
        schema = {'$schema':'http://json-schema.org/draft-07/schema#', 
         '$id':'#/', 
         'type':'object', 
         'title':'The Root Schema', 
         'properties':{'data': {'$id':'#/properties/data', 
                   'type':'object', 
                   'title':'The Data Schema', 
                   'properties':{'attributes':{'$id':'#/properties/data/properties/attributes', 
                     'type':'object', 
                     'title':'The Attributes Schema', 
                     'properties':{'predictors': {'$id':'#/properties/data/properties/attributes/properties/predictors', 
                                     'type':'array', 
                                     'items':schema}}, 
                     'required':[
                      'predictors'], 
                     'additionalProperties':False}, 
                    'id':{'$id':'#/properties/data/properties/id', 
                     'type':'string', 
                     'title':'The Id Schema', 
                     'example':'2018-10-14T18:09:31.297513Z'}, 
                    'type':{'$id':'#/properties/data/properties/type', 
                     'type':'string', 
                     'enum':[
                      'PredictorInput'], 
                     'title':'The Type Schema', 
                     'example':'PredictorInput'}}, 
                   'required':[
                    'attributes',
                    'id',
                    'type'], 
                   'additionalProperties':False}}, 
         'required':[
          'data'], 
         'additionalProperties':False}
        api_schema_filepath = model.get_api_schema_filepath()
        with open(api_schema_filepath, 'w') as (api_schema_file):
            api_schema_file.write(json.dumps(schema, indent=4))


parser = argparse.ArgumentParser(description='Generates JSONSchema files from ModelSchema files.')
parser.add_argument('base_folder', type=str, help='The base folder where models are stored.')
parser.add_argument('--model_names', type=str, help='A comma-separated list of model names to generate api schemas for.',
  default='dr_buckets,late_days_buckets',
  required=False)
args = parser.parse_args()
for model_name in args.model_names.split(','):
    generator = APISchemaGenerator(args.base_folder, model_name)
    generator.generate()
    print('Generated API schema for %s under %s' % (
     model_name,
     os.path.join(args.base_folder, model_name)))