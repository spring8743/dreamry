# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/scripts/derivedfeaturesimporter.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 3074 bytes
import argparse, pandas
from smartcredit import FeaturesHandler

def import_derivedfeatures(csv_filepath, clear_old_features, raise_on_dupes):
    data = pandas.read_csv(csv_filepath)
    derived_features = ['buyer_supplier_dilution_ave_180d', 'buyer_supplier_dilution_ave_360d', 'buyer_supplier_dilution_ave_90d', 'buyer_supplier_dilution_ave_all', 'buyer_supplier_doc_usd_amt_ave_180d', 'buyer_supplier_doc_usd_amt_ave_360d', 'buyer_supplier_doc_usd_amt_ave_90d', 'buyer_supplier_doc_usd_amt_ave_all', 'buyer_supplier_doc_usd_amt_stddev_180d', 'buyer_supplier_doc_usd_amt_stddev_360d', 'buyer_supplier_doc_usd_amt_stddev_90d', 'buyer_supplier_doc_usd_amt_stddev_all', 'buyer_supplier_is_late_ave_180d', 'buyer_supplier_is_late_ave_360d', 'buyer_supplier_is_late_ave_90d', 'buyer_supplier_is_late_ave_all', 'buyer_supplier_late_days_ave_180d', 'buyer_supplier_late_days_ave_360d', 'buyer_supplier_late_days_ave_90d', 'buyer_supplier_late_days_ave_all', 'buyer_supplier_past_invoice_count_180d', 'buyer_supplier_past_invoice_count_360d', 'buyer_supplier_past_invoice_count_90d', 'buyer_supplier_past_invoice_count_all', 'buyer_supplier_term_ave_180d', 'buyer_supplier_term_ave_360d', 'buyer_supplier_term_ave_90d', 'buyer_supplier_term_ave_all', 'client_dilution_ave_180d', 'client_dilution_ave_360d', 'client_dilution_ave_90d', 'client_dilution_ave_all', 'client_doc_usd_amt_ave_180d', 'client_doc_usd_amt_ave_360d', 'client_doc_usd_amt_ave_90d', 'client_doc_usd_amt_ave_all', 'client_doc_usd_amt_stddev_180d', 'client_doc_usd_amt_stddev_360d', 'client_doc_usd_amt_stddev_90d', 'client_doc_usd_amt_stddev_all', 'client_is_late_ave_180d', 'client_is_late_ave_360d', 'client_is_late_ave_90d', 'client_is_late_ave_all', 'client_late_days_ave_180d', 'client_late_days_ave_360d', 'client_late_days_ave_90d', 'client_late_days_ave_all', 'client_past_invoice_count_180d', 'client_past_invoice_count_360d', 'client_past_invoice_count_90d', 'client_past_invoice_count_all', 'client_term_ave_180d', 'client_term_ave_360d', 'client_term_ave_90d', 'client_term_ave_all', 'currency_vector_180d', 'currency_vector_30d', 'currency_vector_7d', 'currency_volatility_180d', 'currency_volatility_30d', 'currency_volatility_7d', '%_doc_usd_amt_previous_q2', '%_doc_usd_amt_previous_q1', '%_doc_usd_amt_previous_q4', '%_doc_usd_amt_previous_q3']
    FeaturesHandler.store_from_df(data, derived_features, clear_old_features=clear_old_features, raise_on_dupes=raise_on_dupes)


parser = argparse.ArgumentParser(description='Imports precomputed features from a pandas dataframe csv dump to Postgres. ')
parser.add_argument('csv_filepath', type=str, help='The path to the csv dump file')
parser.add_argument('--no-clear', dest='clear', action='store_true', help='Dont clear old features before inserting new ones. Default: False',
  default=False,
  required=False)
parser.add_argument('--ignore_dupes', dest='ignore_dupes', action='store_true', help='Ignore mismatch between duplicate features. Default: False',
  default=False,
  required=False)
args = parser.parse_args()
import_derivedfeatures(args.csv_filepath, not args.clear, not args.ignore_dupes)