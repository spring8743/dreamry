# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/args/args.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 9376 bytes
"""
    smartcredit.args.args
    ~~~~~~~~~~~~~~
    :copyright: � 2018 by Flowcast Inc.
"""
import argparse, datetime
from flowcast.args import BaseArgs
from smartcredit.helpers.date_utils import decrease_month

class BatchMonthlyArgs(BaseArgs):
    config_section = 'undefined'
    prog_name = 'undefined'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def parse_args(self):
        now = datetime.datetime.utcnow()
        default_date = decrease_month(now).strftime('%Y-%m-%d')
        parser = argparse.ArgumentParser(description=self.prog_name)
        parser.add_argument('--dr_weights', nargs='*',
          default=[
         '0.0', '0.15', '0.40', '0.80', '1.0'],
          help="Dilution rate weights. Default: ['0.15', '0.40', '0.80', '1.0']")
        parser.add_argument('--ld_weights', nargs='*',
          default=[
         '0.0', '0.10', '0.40', '0.75', '0.90', '1.0'],
          help="Late dates weights.Default: ['0.05', '0.25', '0.60', '0.90', '1.0']")
        parser.add_argument('--dr_field_name', type=str,
          default='dr_buckets_pred',
          help='Dilution rate field name prefix')
        parser.add_argument('--ld_field_name', type=str,
          default='late_days_buckets_pred',
          help='Late days field name prefix')
        parser.add_argument('--dr_bands_label_ranges', type=float,
          nargs='*',
          default=[
         0, 0.0595, 0.118, 0.21, 0.25],
          help='Dilution rate band labels range.                 Default: [0, 0.0595, 0.1180, 0.21, 0.25]')
        parser.add_argument('--ld_bands_label_ranges', type=float,
          nargs='*',
          default=[
         0, 0.04, 0.0875, 0.169, 0.235],
          help='Late days band labels range.                 Default: [0, 0.04, 0.0875, 0.169, 0.235]')
        parser.add_argument('--dr_bands', type=float,
          nargs='*',
          default=[
         0.0, 0.02, 0.05, 0.1, 0.1],
          help='Dilution rate bands values.                 Default: [0.0, 0.02, 0.05, 0.10, 0.10]')
        parser.add_argument('--ld_bands', type=float,
          nargs='*',
          default=[
         0.0, 15.0, 30.0, 60.0, 90.0, 90.0],
          help='Late days bands values.                 Default: [0.0, 15.0, 30.0, 60.0, 90.0, 90.0]')
        parser.add_argument('--dr_bands_fc', type=float,
          nargs='*',
          default=[
         0.0, 0.02, 0.05, 0.1, 0.1],
          help='Dilution rate bands values.                 Default: [0.0, 0.02, 0.05, 0.10, 0.10]')
        parser.add_argument('--ld_bands_fc', type=float,
          nargs='*',
          default=[
         0.0, 15.0, 30.0, 60.0, 90.0, 90.0],
          help='Late days bands values.                 Default: [0.0, 15.0, 30.0, 60.0, 90.0, 90.0]')
        parser.add_argument('--dr_bands_labels', type=str,
          nargs='*',
          default=[
         'A', 'B', 'C', 'D', 'E'],
          help="Dilution rate band labels range.                 Default: ['A', 'B', 'C', 'D', 'E']")
        parser.add_argument('--ld_bands_labels', type=str,
          nargs='*',
          default=[
         '1', '2', '3', '4', '5'],
          help="Late days band labels range.                 Default: ['1', '2', '3', '4', '5']")
        parser.add_argument('--rolling_back_windows', type=int,
          nargs='*',
          default=[
         12],
          help='Rolling back windows. Default: [12]')
        parser.add_argument('--discount_rate', type=float,
          default=0.06,
          help='Discount rate to be used for cost of lateness. Default: 0.06')
        parser.add_argument('--start_date', type=str,
          default=default_date,
          help='Start date to processed in format YYYY-MM-DD             (Default is previous month).')
        parser.add_argument('--end_date', type=str,
          default=None,
          help='End date to be processed in format YYYY-MM-DD             (Default is previous month).')
        parser.add_argument('--months', type=int,
          help='Number of months to process from previous months.')
        parser.add_argument('--hive_input_host', type=str,
          help='Hive host to be used as input.')
        parser.add_argument('--hive_input_port', type=int,
          help='Hive port to be used for input source. Default: 10000')
        parser.add_argument('--hive_input_db', type=str,
          help='Hive database to be used for input source. Default: default')
        parser.add_argument('--hive_input_auth', type=str,
          help='Hive auth method to be used. Default: LDAP')
        parser.add_argument('--hive_input_username', type=str,
          help='Hive username for input.')
        parser.add_argument('--hive_input_password', type=str,
          help='Hive password for input.')
        parser.add_argument('--hive_input_table', type=str,
          help='Hive table to be used as input.')
        parser.add_argument('--hive_tmp_table_name', type=str,
          default='tmp_tf_seller_monthly',
          help='Hive temp table name to be used. Default: tmp_tf_seller_monthly')
        parser.add_argument('--hive_output_host', type=str,
          help='Hive host to be used as output.')
        parser.add_argument('--hive_output_port', type=int,
          help='Hive port to be used for output source.')
        parser.add_argument('--hive_output_db', type=str,
          help='Hive database to be used for output.')
        parser.add_argument('--hive_output_auth', type=str,
          help='Hive auth method to be used.')
        parser.add_argument('--hive_output_username', type=str,
          help='Hive username for output.')
        parser.add_argument('--hive_output_password', type=str,
          help='Hive password for output.')
        parser.add_argument('--hive_output_table', type=str,
          help='Hive table to store results.')
        parser.add_argument('--hive_input_primary_key', type=str,
          default='cust_leid',
          help='Hive input table primary key to be used for queries.            Default: cust_leid')
        parser.add_argument('--hive_input_product_key', type=str,
          default='product_code',
          help='Hive input table product to be used for queries.            Default: product_code. Use "null" to omit it')
        parser.add_argument('--hive_input_amount_expr', type=str,
          default='ABS((doc_ccy_amt+doc_ccy_adj_amt)*year_rate)',
          help='Hive input document amount SQL expression.            Default: ABS((doc_ccy_amt+doc_ccy_adj_amt)*year_rate)')
        parser.add_argument('--hive_output_truncate', help='Truncate output table before inserting data')
        parser.add_argument('--hive_output_table_format', default='PARQUET',
          choices=[
         'PARQUET', 'TEXTFILE', 'RCFILE', 'ORC', 'AVRO'],
          help='Output table format. Default: PARQUET')
        self.extra_args(parser)
        self.params = parser.parse_args()

    def get_params(self):
        return super().get_params()

    def prepare_args(self):
        """Prepare arguments merging attributes coming from the config
        module with parameters passed through as cli arguments
        """
        if self.params.end_date is None:
            self.params.end_date = self.params.start_date
        if self.params.months is not None:
            now = datetime.datetime.utcnow().replace(day=1)
            previous_month = decrease_month(now)
            self.params.end_date = previous_month.strftime('%Y-%m-%d')
            start_date = previous_month
            for _ in range(int(self.params.months) - 1):
                start_date = decrease_month(start_date)

            self.params.start_date = start_date.strftime('%Y-%m-%d')
        if self.params.hive_output_truncate in ('true', '1'):
            self.params.hive_output_truncate = True
        else:
            self.params.hive_output_truncate = False


class SellerMonthlyArgs(BatchMonthlyArgs):
    config_section = 'seller_agg'
    prog_name = 'Batch Seller Monthly Score'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def extra_args(self, args_obj):
        pass


class SellerBuyerMonthlyArgs(BatchMonthlyArgs):
    config_section = 'seller_buyer_agg'
    prog_name = 'Batch Seller Buyer Monthly Score'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def extra_args(self, args_obj):
        args_obj.add_argument('--hive_input_buyer_key', type=str,
          default='buyer_id',
          help='Hive input table buyer id to be used for queries.            Default: buyer_id')
        args_obj.add_argument('--hive_cust_cntpty_tmp_tbl', type=str,
          default='cust_cntpty_tmp',
          help='Hive input temp table name for cust-cntpty.            Default: cust_cntpty_tmp')