# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/alembic/versions/870032281b28_baseline.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 324 bytes
"""baseline

Revision ID: 870032281b28
Revises: 
Create Date: 2019-02-12 21:56:27.037055

"""
from alembic import op
import sqlalchemy as sa
revision = '870032281b28'
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    pass


def downgrade():
    pass