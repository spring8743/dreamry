# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/alembic/versions/69ae8ff34890_base_tables.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 3005 bytes
"""base tables

Revision ID: 69ae8ff34890
Revises: 870032281b28
Create Date: 2019-02-12 22:09:38.931550

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
revision = '69ae8ff34890'
down_revision = '870032281b28'
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('buyersupplier_featureset', sa.Column('id', sa.Integer(), nullable=False), sa.Column('timestamp', sa.TIMESTAMP(timezone=True), server_default=sa.text('now()'), nullable=False), sa.Column('buyer_id', sa.VARCHAR(), nullable=False), sa.Column('supplier_id', sa.VARCHAR(), nullable=False), sa.Column('doc_date', sa.TIMESTAMP(timezone=True), nullable=False), sa.Column('features', postgresql.JSONB(astext_type=sa.Text()), nullable=True), sa.PrimaryKeyConstraint('id'))
    op.create_index(op.f('ix_buyersupplier_featureset_buyer_id'), 'buyersupplier_featureset', ['buyer_id'], unique=False)
    op.create_index(op.f('ix_buyersupplier_featureset_supplier_id'), 'buyersupplier_featureset', ['supplier_id'], unique=False)
    op.create_table('client_featureset', sa.Column('id', sa.Integer(), nullable=False), sa.Column('timestamp', sa.TIMESTAMP(timezone=True), server_default=sa.text('now()'), nullable=False), sa.Column('client_id', sa.VARCHAR(), nullable=False), sa.Column('doc_date', sa.TIMESTAMP(timezone=True), nullable=False), sa.Column('features', postgresql.JSONB(astext_type=sa.Text()), nullable=True), sa.PrimaryKeyConstraint('id'))
    op.create_index(op.f('ix_client_featureset_client_id'), 'client_featureset', ['client_id'], unique=False)
    op.create_table('currency_featureset', sa.Column('id', sa.Integer(), nullable=False), sa.Column('timestamp', sa.TIMESTAMP(timezone=True), server_default=sa.text('now()'), nullable=False), sa.Column('currency_code', sa.VARCHAR(), nullable=False), sa.Column('doc_date', sa.TIMESTAMP(timezone=True), nullable=False), sa.Column('features', postgresql.JSONB(astext_type=sa.Text()), nullable=True), sa.PrimaryKeyConstraint('id'))
    op.create_index(op.f('ix_currency_featureset_currency_code'), 'currency_featureset', ['currency_code'], unique=False)


def downgrade():
    op.drop_index(op.f('ix_currency_featureset_currency_code'), table_name='currency_featureset')
    op.drop_table('currency_featureset')
    op.drop_index(op.f('ix_client_featureset_client_id'), table_name='client_featureset')
    op.drop_table('client_featureset')
    op.drop_index(op.f('ix_buyersupplier_featureset_supplier_id'), table_name='buyersupplier_featureset')
    op.drop_index(op.f('ix_buyersupplier_featureset_buyer_id'), table_name='buyersupplier_featureset')
    op.drop_table('buyersupplier_featureset')