# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/helpers/aggregations.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 31540 bytes
"""
    smartcredit.helpers.aggregations
    ~~~~~~~~~~~~~~
    :copyright: � 2018 by Flowcast Inc.
"""
import logging, pandas
from smartcredit.helpers.date_utils import get_lower_boundary_date_as_str, get_upper_boundary_date_as_str
from smartcredit.templates.aggregations import SELLER_MONTHLY_SQL, TF_SQL, JOIN_SQL, COST_OF_LATENESS_SQL, COST_OF_DILUTION, CONFIDENCE_SQL, SELLER_MONTHLY_CONDITIONS_CLAUSES, IN_MONTH_SQL, IN_WINDOW_SQL, IN_MONTH_COND, EXPLANATIONS_SQL, ACTUAL_PREDICTED_SQL, ACTUAL_TO_SCORE_SQL, SELLER_BUYER_SQL, JOIN_SQL_CUST_CNTPTY, SELLER_BUYER_CASE_TMPL
logger = logging.getLogger('root.compute_aggregations')

def weighted_score(doc_amount, doc_predictions, weights):
    return doc_amount * sum([p * w for p, w in zip(doc_predictions, weights)])


def compute_generic_score(documents, weights, discount_rate, rolling_windows):
    """Compute an aggregated generic score using the given weights and rolling
        window. If you want to calculate an specific score you can set it up
        using different weights.
    
    :param documents: the documents to use for the computation. Must be a 
        list of tuples with each tuple representing one document, i.e.:
            (doc_amount, ld_pred_bucket_1, ... , ld_pred_bucket_n)
    :type documents: List of tuples
    :param weights: weights for each bucket. This must be ordered and match
        the number of buckets
    :type weights: List of floats
    :param rolling_windows: Rolling windows to be used for calculations
    :type rolling_windows: List of integers
    
    Score:
        documents: [(doc_amt_1, p1, p2, ... , pk), ...]
        weights: [w1, w2, ..., wk]
        Partial Score (ps):
            ps = (p1_1*w1 + ... + pk_1*wk) * doc_amt_1 + ...
                + (p1_n*w1 + ...+ pk_n*wk) * doc_amt_n
                -> from 1 to k weights for each n document
            total_amount = (doc_amt1 + ... + doc_amtn) -> from 1 to n documents
        Score (S):
            S = ps / total_amount
    
    """
    try:
        total_amount = 0.0
        current_score = 0.0
        for doc in documents:
            doc_amount, doc_predictions = doc[0], doc[1:]
            current_score += weighted_score(doc_amount, doc_predictions, weights)
            total_amount += doc_amount

        return current_score / total_amount
    except IndexError:
        logger.critical("Weights passed doesn't match document predictions")
        raise
    except Exception as e:
        logger.critical('Error: %s' % e)
        raise


def compute_late_days_score(documents, weights=[
 0.05, 0.1, 0.2, 0.3, 1.0], discount_rate=0.06, rolling_windows=[3, 12]):
    """Compute late days score using using calling the compute_generic_score
    with the default parameters for late days score 
    """
    return compute_generic_score(documents, weights, discount_rate, rolling_windows)


def compute_dilution_rate_score(documents, weights=[
 0.33, 0.66, 1.0], discount_rate=0.06, rolling_windows=[3, 12]):
    """Compute late days score using using calling the compute_generic_score
    with the default parameters for late days score 
    """
    return compute_generic_score(documents, weights, discount_rate, rolling_windows)


def products_dedup(products, separator=','):
    return separator.join(set(products))


def gen_sql_conditions(conditions):
    return ('AND').join(conditions)


def compute_flowcast_score(cod, col, drs, lds):
    """Compute flowcast score for the given parameters.
    Args:
        cod: cost of dilution.
        col: cost of lateness.
        drs: dilution rate score.
        lds: late days score.
    
    Returns:
        A Flowcast score for the given parameters
    """
    tc = cod + col
    if tc == 0.0:
        return 1.0
        return 4 * (lds * col / tc + drs * cod / tc) + 1


def sql_scalar_product_statement(*vectors):
    """Generates an SQL statement representing an
    scalar product between vectors.
    Args:
        vectors: List of vectors to be multiplied
    
    Returns:
        Return an SQL string representing the scalar product
        between vectors.
    """
    return ('+').join(map(lambda x: ('*').join(map(lambda y: str(y), x)), zip(*vectors)))


def return_if_not_null(dl):
    for row in dl:
        if not pandas.isnull(row):
            return row


def timeframe_ranges(windows, as_string=True):
    """Generates a list of tuples for the given windows
    containing key, value for the whole timeframe range.
    Args:
        windows: List of windows
        as_string: Boolean determining if values should
            returned as strings
    
    Returns:
        A list of tuples containing all timeframe values
        for the whole range (from 0 up to window value).
    """
    values = []
    for window in windows:
        for i in range(0, window + 1):
            values.append((window, window - i))

    if as_string:
        return map(lambda x: '(%d,%d)' % (x[0], x[1]), values)
        return values


def get_inline_sql(columns, values, tf, amount, uid):
    """Get the SQL query for inline explode.
    
    Args:
        columns: Columns names to be flattened
        values: Values for the corresponding cols
        tf: Timeframe value
        amount: SQL expression representing amount
        uid: Unique id to use to join data. Default: leid
    
    Returns:
        Return a nicely formatted query ready & waiting to be executed :)
    """
    structs = []
    for c, v in zip(columns, values):
        structs.append('struct(%s, %s, %s, %s, %s)' % (uid, tf, c, v, amount))

    return 'INLINE(ARRAY(%s))' % (',').join(structs)


def get_top_n_features(data, prefix, top_n=5):
    """Given a pre-calculated explanation aggs Pandas DataFrame
    this method will return a Pandas DataFrame containing
    top_n features ready to be joined with scores aggs.
    Args:
        data: Pandas DataFrame containing pre-calculated data for explanation
            aggregations.
        prefix: String prefix to be used for column names.
        top_n: Number of features to be fetched.
    
    Returns:
        Return a nicely formatted query ready & waiting to be executed :)
    """
    cols = [
     'seller_id', 'rolling_month_window']
    cols += ['%scolumn_%s' % (prefix, i) for i in range(1, top_n + 1)]
    cols += ['%svalue_%s' % (prefix, i) for i in range(1, top_n + 1)]
    top_features = pandas.DataFrame(columns=cols)
    data.columns = ['seller_id', 'rolling_month_window', 'col_name', 'col_value']
    data['abs_col_value'] = data.apply(lambda row: abs(float(row.get('col_value') if row.get('col_value') else 0.0)),
      axis=1)
    grouped_data = data.groupby(['seller_id', 'rolling_month_window'])
    for group in grouped_data.groups:
        sorted_data = grouped_data.get_group(group).sort_values('abs_col_value',
          ascending=False)
        current = {'seller_id':group[0],  'rolling_month_window':group[1]}
        for i in range(top_n):
            try:
                current['%scolumn_%s' % (prefix, i + 1)] = sorted_data.iloc[i].get('col_name')
                current['%svalue_%s' % (prefix, i + 1)] = sorted_data.iloc[i].get('col_value')
            except IndexError:
                current['%scolumn_%s' % (prefix, i + 1)] = None
                current['%svalue_%s' % (prefix, i + 1)] = None

        top_features = top_features.append(current, ignore_index=True)

    return top_features


def get_band(value, ranges, labels):
    """Given a the value, band ranges and labels for bands
    returns the corresponding band for the value
    Args:
        value: Numeric value to be evaluated
        ranges: List of range lower limits
        labels: List of labels to be used.
    Returns:
        Label correspoding to the actual score value
    """
    if value == 0.0:
        return labels[0]
        for i in range(1, len(ranges) - 1):
            if value < ranges[i]:
                return labels[i]
        else:
            return labels[-1]


def get_score_bands(data, ranges, labels, fields):
    """Given a Pandas DataFrame calculate and set the
    score bands for the given fields and bands
    Args:
        data: Pandas DataFrame containing pre-calculated data for explanation
            aggregations.
        ranges: List of ranges to determine the labels.
        labels: List of labels to be used.
        fields: List of fields to be used.
    
    Returns:
        Pandas DataFrame with the corresponding score bands
    """
    for field in fields:
        data[field] = data.apply(lambda row: get_band(float(row[field]), ranges, labels),
          axis=1)


def get_actual_or_predicted(ranges, pred_fields, actual_value_field):
    """
    Args:
        ranges: Bands ranges for predictions.
        pred_fields: Fields names for predicted values for bands
        actual_value_field: Name of the field containing the actual value.
    Returns:
        String represeting actual SQL statement to get the actual or
            the predicted value depending if it exists ot not.
    
    """
    exprs = []
    pivot = [
     0.0] + ranges[0:-1]
    for i, j, k in zip(pivot, ranges, pred_fields):
        exprs.append('%f * %s' % (i + (j - i) / 2.0, k))

    return ACTUAL_PREDICTED_SQL.format(field_name=actual_value_field,
      scalar_expr=('+').join(exprs))


def get_actual_score_case_stmt(weights, amount):
    """
    Args:
        weights: weights for the current score
        amount: amount of the corresponding document
    Returns:
        String represeting an SQL statement to get the correspondig score
        given an actual value
    """
    stmt_tmpl = 'WHEN %s THEN %s*%s'
    stmts = []
    for i, w in enumerate(weights, start=0):
        stmts.append(stmt_tmpl % (i, w, amount))

    return (' ').join(stmts)


def get_score_case_stmt_from_actuals(field, band_ranges, weights, amount):
    """
    Args:
        field: field reference to be used
        band_ranges: band ranges
        weights: weights for the current score
        amount: amount of the corresponding document
    Returns:
        String represeting an SQL statement to get the correspondig score
        given an actual value
    """
    stmt_tmpl = 'WHEN %s > %s THEN %s*%s'
    stmts = ['WHEN %s = 0.0 THEN 0.0' % field]
    for b, w in zip(band_ranges, weights[1:]):
        stmts.append(stmt_tmpl % (field, b, w, amount))

    return (' ').join(stmts[::-1])


def get_case_stmt_template(band_ranges, field, target_field, value, max_bands=10):
    """
    Args:
        band_ranges: band ranges
        field: field name to be used to fetch the actual value
        target_field: target field name
        value: value when case condition mets
        max_bands: max number of bands that can exist.
    Returns:
        String represeting an SQL statement to get the values for
        the correspoding bands
    """
    pivot = [
     band_ranges[0]] + band_ranges[:-1]
    stmts = []
    for s, e, i in zip(pivot, band_ranges, range(len(pivot))):
        fn = '%s_%s' % (target_field, i)
        if s == e:
            if s == 0.0:
                stmts.append(SELLER_BUYER_CASE_TMPL % (
                 '{%s} = %s' % (field, s), value, fn))
            else:
                stmts.append(SELLER_BUYER_CASE_TMPL % (
                 '{%s} >= %s' % (field, e), value, fn))
        else:
            if i < len(pivot) - 2:
                ineq_op = '<='
            else:
                ineq_op = '<'
            stmts.append(SELLER_BUYER_CASE_TMPL % (
             '%s < {%s} AND {%s} %s %s' % (
              s, field, field, ineq_op, e),
             value, fn))

    for i in range(len(band_ranges), max_bands):
        fn = '%s_%s' % (target_field, i)
        stmts.append('NULL AS %s,' % fn)

    return ('\n').join(stmts)


def get_middle_value_stmt(ranges, field_name, else_val='NULL'):
    """
    Args:
        ranges: range of values for bands
        field_name: field name to compare
        else_val: default value for else case
    Returns:
        String represeting an SQL statement to get the middle value of the
        corresponding band.
    """
    query_tmpl = 'CASE {field} {when_expr} ELSE {else_val} END'
    stmt_tmpl = 'WHEN %s THEN %s'
    stmts = []
    for i, r in enumerate(ranges, start=0):
        if i > 0:
            val = ranges[i - 1] + (r - ranges[i - 1]) / 2.0
        else:
            val = 0.0
        stmts.append(stmt_tmpl % (i, val))

    return query_tmpl.format(field=field_name,
      when_expr=(' ').join(stmts),
      else_val=else_val)


def prepare_agg_query(ld_weights, dr_weights, ld_label, dr_label, target_date, lower_date_boundary, lower_limit_window, ld_ranges, ld_ranges_fc, dr_ranges, dr_ranges_fc, discount_rate, table_name, tmp_tbl_name, input_pk, input_product, amount_expr, tbl_alias='scr_scr', tmp_tbl_alias='seller_monthly_tmp'):
    """Prepare aggregation query using the query template for the given
    parameters
    Args:
        ld_weights: Late days weights.
        dr_weights: Dilution rate weights.
        ld_label: Late days base label.
        dr_label: Dilution rate base label.
        ld_ranges: Late Days ranges.
        ld_ranges_fc: Late Days ranges for FC score.
        dr_ranges: Dilution rate ranges.
        dr_ranges_fc: Dilution rate ranges for FC score.
        target_date: Target date to compute scores.
        lower_date_boundary: Lower limit for date range.
        discount_rate: Discount rate to be used for dilution cost.
        lower_limit_window: Greatest window to be used.
        table_name: Source table name.
        tmp_tbl_name: Source table name.
        input_pk: Hive input table primary key to be used for queries.
        input_product: Hive input table product to be used for queries.
        amount_expr: Valid SQL expression representing the document amount.
        tbl_alias: Table alias.
        tmp_tbl_alias: Temp table alias.
    
    Returns:
        Returns a nicely formatted query ready & waiting to be executed :)
    """
    timeframe_stmt = TF_SQL.format(tmp_tbl_alias=tmp_tbl_alias)
    in_month_stmt = IN_MONTH_COND.format(target_date=target_date)
    product_stmt = "CONCAT_WS(',', COLLECT_SET(%s))" % input_product if input_product.lower() != 'null' else input_product
    model_version_stmt = "CONCAT_WS(',', COLLECT_SET(model_version))"
    ld_amount_vector = [amount_expr] * len(ld_weights)
    ftd_ld_labels = [ld_label + '_%d' % i for i, _ in enumerate(ld_weights, 0)]
    ld_score_stmt, ld_score_month_stmt = ['%s / %s' % (query.format(agg_func='SUM', expr_val='0', is_in_month=in_month_stmt, expr=ACTUAL_PREDICTED_SQL.format(field_name=ACTUAL_TO_SCORE_SQL.format(when_expr=get_score_case_stmt_from_actuals('late_days', ld_ranges_fc, ld_weights, amount_expr)), scalar_expr=sql_scalar_product_statement(ld_weights, ftd_ld_labels, ld_amount_vector))), query.format(agg_func='SUM', is_in_month=in_month_stmt, expr=amount_expr, expr_val='0')) for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    dr_amount_vector = [
     amount_expr] * len(dr_weights)
    ftd_dr_labels = [dr_label + '_%d' % i for i, _ in enumerate(dr_weights, 0)]
    dr_score_stmt, dr_score_month_stmt = ['%s / %s' % (query.format(agg_func='SUM', expr_val='0', is_in_month=in_month_stmt, expr=ACTUAL_PREDICTED_SQL.format(field_name=ACTUAL_TO_SCORE_SQL.format(when_expr=get_score_case_stmt_from_actuals('dr', dr_ranges_fc, dr_weights, amount_expr)), scalar_expr=sql_scalar_product_statement(dr_weights, ftd_dr_labels, dr_amount_vector))), query.format(agg_func='SUM', expr_val='0', is_in_month=in_month_stmt, expr=amount_expr)) for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    late_days_avg_window, late_days_avg_month = ['%s' % (query.format(agg_func='AVG', expr_val='NULL', is_in_month=in_month_stmt, expr=ACTUAL_PREDICTED_SQL.format(field_name='late_days', scalar_expr=get_middle_value_stmt(ld_ranges, 'late_days_buckets_pred')))) for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    dilution_rate_avg_window, dilution_rate_avg_month = ['%s' % (query.format(agg_func='AVG', expr_val='NULL', is_in_month=in_month_stmt, expr=ACTUAL_PREDICTED_SQL.format(field_name='dr', scalar_expr=get_middle_value_stmt(dr_ranges, 'dr_buckets_pred')))) for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    ld_confidence_stmt, ld_confidence_month_stmt = ['%s / %s' % (query.format(agg_func='SUM', expr_val='0', is_in_month=in_month_stmt, expr=CONFIDENCE_SQL.format(greatest_expr=(',').join(ftd_ld_labels), pred_sum=('-').join(ftd_ld_labels), amount_expr=amount_expr)), query.format(agg_func='SUM', expr_val='0', is_in_month=in_month_stmt, expr=amount_expr)) for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    dr_confidence_stmt, dr_confidence_month_stmt = ['%s / %s' % (query.format(agg_func='SUM', expr_val='0', is_in_month=in_month_stmt, expr=CONFIDENCE_SQL.format(greatest_expr=(',').join(ftd_dr_labels), pred_sum=('-').join(ftd_dr_labels), amount_expr=amount_expr)), query.format(agg_func='SUM', expr_val='0', is_in_month=in_month_stmt, expr=amount_expr)) for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    cost_of_lateness_stmt, cost_of_lateness_month_stmt = [query.format(agg_func='SUM', expr_val='0', is_in_month=in_month_stmt, expr=COST_OF_LATENESS_SQL.format(late_days=ACTUAL_PREDICTED_SQL.format(field_name='late_days', scalar_expr=get_middle_value_stmt(ld_ranges, 'late_days_buckets_pred')), discount_rate=discount_rate, amount_expr=amount_expr)) for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    cost_of_dilution_stmt, cost_of_dilution_month_stmt = [query.format(agg_func='SUM', expr_val='0', is_in_month=in_month_stmt, expr=COST_OF_DILUTION.format(dilution_rate=ACTUAL_PREDICTED_SQL.format(field_name='dr', scalar_expr=get_middle_value_stmt(dr_ranges, 'dr_buckets_pred')), amount_expr=amount_expr)) for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    total_amount_stmt, total_amount_month_stmt = [query.format(agg_func='SUM', expr_val='0', is_in_month=in_month_stmt, expr=amount_expr) for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    total_count_stmt, total_count_month_stmt = [query.format(agg_func='COUNT', expr_val='NULL', is_in_month=in_month_stmt, expr='1') for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    total_count_buyers_stmt, total_count_buyers_month_stmt = [(query.format(agg_func='COUNT(DISTINCT', expr_val='NULL', is_in_month=in_month_stmt, expr='buyer_id')) + ')' for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    conditions = SELLER_MONTHLY_CONDITIONS_CLAUSES.format(lower_date_boundary=lower_date_boundary,
      target_date=get_upper_boundary_date_as_str(target_date, '%Y-%m-%d %H:%M:%S'),
      uid=input_pk)
    join_stmt = JOIN_SQL.format(table_name=tmp_tbl_name,
      table_alias=tmp_tbl_alias,
      target_date=target_date)
    return SELLER_MONTHLY_SQL.format(group_column_name=input_pk,
      target_date="'%s'" % target_date,
      product_stmt=product_stmt,
      timeframe_stmt=timeframe_stmt,
      late_days_score=ld_score_stmt,
      late_days_score_month_stmt=ld_score_month_stmt,
      dilution_rate_score_stmt=dr_score_stmt,
      dilution_rate_score_month_stmt=dr_score_month_stmt,
      late_days_avg=late_days_avg_window,
      late_days_avg_month_stmt=late_days_avg_month,
      dilution_rate_avg_stmt=dilution_rate_avg_window,
      dilution_rate_avg_month_stmt=dilution_rate_avg_month,
      late_days_confidence_stmt=ld_confidence_stmt,
      late_days_confidence_month_stmt=ld_confidence_month_stmt,
      dilution_rate_confidence_stmt=dr_confidence_stmt,
      dilution_rate_confidence_month_stmt=dr_confidence_month_stmt,
      cost_of_lateness_stmt=cost_of_lateness_stmt,
      cost_of_lateness_month_stmt=cost_of_lateness_month_stmt,
      cost_of_dilution_stmt=cost_of_dilution_stmt,
      cost_of_dilution_month_stmt=cost_of_dilution_month_stmt,
      total_amount_stmt=total_amount_stmt,
      total_amount_month_stmt=total_amount_month_stmt,
      total_count_stmt=total_count_stmt,
      total_count_month_stmt=total_count_month_stmt,
      total_count_buyers_stmt=total_count_buyers_stmt,
      total_count_buyers_month_stmt=total_count_buyers_month_stmt,
      model_version_stmt=model_version_stmt,
      table_name=table_name,
      tbl_alias=tbl_alias,
      join_stmt=join_stmt,
      conditions=conditions)


def prepare_expl_agg_query(table_name, tfs, prefix, target_date, tmp_tbl_name, primary_key='leid', amount_expr='doc_usd_amt', top_n=5, tbl_alias='scr_scr', tmp_tbl_alias='seller_monthly_tmp'):
    """This method generates a  pre-aggregation query for explanations
    Args:
        table_name: Soruce table name where documents predictions are stored.
        tfs: Timeframes to be processed.
        prefix: Explanation field name prefix.
        target_date: String representation of the target date
        tmp_tbl_name: Temp table name.
        primary_key: Key representing the unique identifier to group by.
        amount_expr: SQL expression representing amount
        top_n: Number of features to be fetched.
        tbl_alias: Source table alias.
        tmp_tbl_alias: Temp table alias.
    
    Returns:
        Query string to get pre-aggregate data for explanations.
    """
    queries = []
    for tf in tfs:
        lower_date_boundary = get_lower_boundary_date_as_str(target_date, [tf], '%Y-%m-%d %H:%M:%S')
        columns = [prefix + 'column_%d' % i for i in range(1, top_n + 1)]
        values = [prefix + 'value_%d' % i for i in range(1, top_n + 1)]
        queries.append(EXPLANATIONS_SQL.format(inline_stmt=get_inline_sql(columns, values, tf, amount_expr, primary_key),
          table_name=table_name,
          tbl_alias=tbl_alias,
          join_clause=JOIN_SQL.format(table_name=tmp_tbl_name,
          table_alias=tmp_tbl_alias,
          target_date=target_date),
          conditions=SELLER_MONTHLY_CONDITIONS_CLAUSES.format(lower_date_boundary=lower_date_boundary,
          target_date=get_upper_boundary_date_as_str(target_date, '%Y-%m-%d %H:%M:%S'),
          uid=primary_key),
          extras='AND %s.tf = %s' % (tmp_tbl_alias, tf)))

    query = ('\nUNION ALL\n').join(queries)
    return query


def prepare_agg_query_cust_cntpty(target_date, lower_date_boundary, ld_ranges, dr_ranges, table_name, tmp_tbl_name, cust_cntpty_tmp, cust_col, cntpty_col, cust_op, cntpty_op, amount_expr, counts=False, tbl_alias='scr_in', tmp_tbl_alias='tf_tmp_tbl', cust_cntpty_tmp_tbl_alias='cc_tmp'):
    """Prepare aggregation query using the query template for the given
    parameters
    Args:
        target_date: Target date to compute scores.
        lower_date_boundary: Lower limit for date range.
        ld_ranges: Late Days ranges.
        dr_ranges: Dilution rate ranges.
        table_name: Source table name.
        tmp_tbl_name: Source temp table name for timframes.
        cust_cntpty_tmp: Source temp table for cust-cntpty ids.
        cust_col: Hive input table customer column to be used for queries.
        cntpty_col: Hive input table cntpty column to be used for queries.
        cust_op: Customer join operator for ON clause. Can be '=' or '!='
        cntpty_op: Counterparty join operator for ON clause. Can be '=' or '!='
        amount_expr: Valid SQL expression representing the document amount.
        counts: Calculate counts for the selected customer-counterparty
        tbl_alias: Table alias.
        tmp_tbl_alias: Temp table alias.
        cust_cntpty_tmp_tbl_alias: Customer-counterparty temp table alias.
    
    Returns:
        Returns a nicely formatted query ready & waiting to be executed :)
    """
    timeframe_stmt = TF_SQL.format(tmp_tbl_alias=tmp_tbl_alias)
    in_month_stmt = IN_MONTH_COND.format(target_date=target_date)
    model_version_stmt = "CONCAT_WS(',', COLLECT_SET(model_version))"
    late_days_avg_window, late_days_avg_month = ['%s' % (query.format(agg_func='AVG', expr_val='NULL', is_in_month=in_month_stmt, expr=ACTUAL_PREDICTED_SQL.format(field_name='late_days', scalar_expr=get_middle_value_stmt(ld_ranges, 'late_days_buckets_pred')))) for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    dilution_rate_avg_window, dilution_rate_avg_month = ['%s' % (query.format(agg_func='AVG', expr_val='NULL', is_in_month=in_month_stmt, expr=ACTUAL_PREDICTED_SQL.format(field_name='dr', scalar_expr=get_middle_value_stmt(dr_ranges, 'dr_buckets_pred')))) for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    total_amount_stmt, total_amount_month_stmt = [query.format(agg_func='SUM', expr_val='0', is_in_month=in_month_stmt, expr=amount_expr) for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    total_count_stmt, total_count_month_stmt = [query.format(agg_func='COUNT', expr_val='NULL', is_in_month=in_month_stmt, expr='1') for query in (IN_WINDOW_SQL, IN_MONTH_SQL)]
    conditions = SELLER_MONTHLY_CONDITIONS_CLAUSES.format(lower_date_boundary=lower_date_boundary,
      target_date=get_upper_boundary_date_as_str(target_date, '%Y-%m-%d %H:%M:%S'),
      uid=cust_col)
    conditions = (' ').join([
     conditions,
     ("AND {cntpty_col} != '1'").format(cntpty_col=cntpty_col)])
    join_stmt = JOIN_SQL.format(table_name=tmp_tbl_name,
      table_alias=tmp_tbl_alias,
      target_date=target_date)
    join_cust_cntpty_stmt = JOIN_SQL_CUST_CNTPTY.format(table_name=cust_cntpty_tmp,
      t_alias=cust_cntpty_tmp_tbl_alias)
    join_conds = ('AND {t_alias}.cust {cust_operator} {s_alias}.{cust_col} AND {t_alias}.cntpty {cntpty_operator} {s_alias}.{cntpty_col}').format(s_alias=tbl_alias,
      t_alias=cust_cntpty_tmp_tbl_alias,
      cust_col=cust_col,
      cntpty_col=cntpty_col,
      cust_operator=cust_op,
      cntpty_operator=cntpty_op)
    if counts:
        seller_buyer_counts_tmpl = get_case_stmt_template(dr_ranges, 'dr_field', 'dr_buckets_amt', '{amount}')
        seller_buyer_counts_tmpl += '\n' + get_case_stmt_template(ld_ranges, 'ld_field', 'late_days_buckets_amt', '{amount}')
        seller_buyer_counts_tmpl += '\n' + get_case_stmt_template(dr_ranges, 'dr_field', 'dr_buckets_txn_count', '1')
        seller_buyer_counts_tmpl += '\n' + get_case_stmt_template(ld_ranges, 'ld_field', 'late_days_buckets_txn_count', '1')
        counts_stmt = seller_buyer_counts_tmpl.format(dr_field=ACTUAL_PREDICTED_SQL.format(field_name='dr',
          scalar_expr=get_middle_value_stmt(dr_ranges, 'dr_buckets_pred')),
          ld_field=ACTUAL_PREDICTED_SQL.format(field_name='late_days',
          scalar_expr=get_middle_value_stmt(ld_ranges, 'late_days_buckets_pred')),
          is_in_month=IN_MONTH_COND.format(target_date=target_date),
          amount=amount_expr)
    else:
        counts_stmt = ''
    return SELLER_BUYER_SQL.format(cust_col=cust_col,
      cntpty_col=cntpty_col,
      target_date="'%s'" % target_date,
      timeframe_stmt=timeframe_stmt,
      late_days_avg=late_days_avg_window,
      late_days_avg_month_stmt=late_days_avg_month,
      dilution_rate_avg_stmt=dilution_rate_avg_window,
      dilution_rate_avg_month_stmt=dilution_rate_avg_month,
      total_amount_stmt=total_amount_stmt,
      total_amount_month_stmt=total_amount_month_stmt,
      total_count_stmt=total_count_stmt,
      total_count_month_stmt=total_count_month_stmt,
      model_version_stmt=model_version_stmt,
      table_name=table_name,
      tbl_alias=tbl_alias,
      tmp_tbl_alias=cust_cntpty_tmp_tbl_alias,
      conditions=conditions,
      join_stmt_timeframe=join_stmt,
      join_stmt_cust_cntpty=join_cust_cntpty_stmt,
      join_conds=join_conds,
      counts_stmt=counts_stmt)