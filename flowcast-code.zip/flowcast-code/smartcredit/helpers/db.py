# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/helpers/db.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 2552 bytes
"""
    smartcredit.helpers.db
    ~~~~~~~~~~~~~~
    :copyright: � 2018 by Flowcast Inc.
"""
import pandas
from pyhive import hive

def get_hive_conn(config):
    """Gets a hive connection using the given config
    
    Args:
        config: Config dictionary containing the following keys:
            host, database, username, auth and password.
    
    Example configuration object:
        {
            'host': 'somehostname',
            'database': 'somedbname',
            'username': 'someusername',
            'auth': 'someauthmethod',
            'password': 'someuserpassword'
        }
    """
    return hive.connect(**config)


def get_hive_cursor(config):
    """Gets a hive cursor using the given config
    
    Args:
        config: Config dictionary containing the following keys:
            host, database, username, auth and password.
    
    Example configuration object:
        {
            'host': 'somehostname',
            'database': 'somedbname',
            'username': 'someusername',
            'auth': 'someauthmethod',
            'password': 'someuserpassword'
        }
    """
    return (hive.connect(**config)).cursor()


def load_data_from_query(query, db_conn):
    """Loads data from a database using the given query.
    The output is a Pandas DataFrame
    
    Args:
        query: Query string to be executed
        db_conn: Database connection object.
    
    Returns:
        Pandas DataFrame containing data returned by the given query
    """
    data = (pandas.read_sql(query, con=db_conn)).astype(object)
    return data


def write_to_hive(data, columns, output_table, db_conn):
    """Write Pandas DataFrame into Hive
    
    Args:
        data: Pandas DataFrame containing data to be inserted into Hive.
    Returns:
        Number of rows inserted.
    """
    rows_to_insert = []
    for _, row in data.iterrows():
        row_values = [repr(row.get(col)) if row.get(col) is not None else 'null' for col in columns]
        row_insert = '(%s)' % (',').join(row_values).replace(',nan', ',null')
        rows_to_insert.append(row_insert)

    insert_stmt = 'INSERT INTO TABLE %s VALUES %s' % (
     output_table, (',').join(rows_to_insert))
    db_conn.execute(insert_stmt)
    return len(rows_to_insert)


def exec_in_hive(query, db_conn, cursor=False):
    """Execute query in hive
    
    Args:
        query: String corresponding to the query to be executed.
    """
    if cursor:
        db_conn.execute(query)
    else:
        db_conn.cursor().execute(query)