# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/helpers/date_utils.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 8447 bytes
"""
    smartcredit.helpers.date_utils
    ~~~~~~~~~~~~~~
    :copyright: � 2019 by Flowcast Inc.
"""
import re, datetime
from calendar import monthrange
import pandas as pd

def last_day_of_month(str_date):
    """Gets the last day of the month for the given string date
    Args:
        str_date: String date in the format YYYY-MM-DD
    
    Returns:
        A datetime object that correspond to the last day of the month for the
        given date, i.e:
    
        last_day_of_month_as_str('2018-11-05')
        -> datetime.datetime(2018,11,30)
    """
    year, month, _ = map(lambda x: int(x), str_date.split('-'))
    return datetime.datetime(year, month, monthrange(year, month)[1])


def last_day_of_month_as_str(str_date, str_format='%Y-%m-%d'):
    """Gets the last day of the month for the given string date
        as string.
    Args:
        str_date: String date in the format YYYY-MM-DD
        str_format: String format for the output string. Default is
            YYYY-MM-DD.
    
    Returns:
        A string that correspond to the last day of the month for the 
        given date, i.e:
    
        last_day_of_month_as_str('2018-11-05')
        -> '2018-11-30'
    """
    return last_day_of_month(str_date).strftime(str_format)


def first_day_of_month_as_str(str_date, str_format='%Y-%m-%d'):
    """Gets the first day of the month for the given string date
        as string.
    Args:
        str_date: String date in the format YYYY-MM-DD
        str_format: String format for the output string. Default is
            YYYY-MM-DD.
    
    Returns:
        A string that correspond to the first day of the month for the
        given date, i.e:
    
        first_day_of_month_as_str('2018-11-05')
        -> '2018-11-01'
    """
    year, month, _ = map(lambda x: int(x), str_date.split('-'))
    return datetime.date(year, month, 1).strftime(str_format)


def get_lower_boundary_date_as_str(target_date, lookback_windows, str_format='%Y-%m-%d'):
    """Gets the lower boundary for the given target date
        and look back windows
    Args:
        target_date: string datetime object representing the target date
        lookback_windows: list of look back windows to be used
    
    Returns:
        A string that correspond to the first day of the month of the
        farthest month given the lookback windows, i.e:
    
        get_lower_boundary_date_as_str('2018-11-05', [1, 3])
        -> '2018-08-01'
    """
    max_months = max(map(lambda x: float(x), lookback_windows))
    lower_boundary = datetime.datetime.strptime(target_date, str_format) - (datetime.timedelta(days=max_months * 30))
    return datetime.datetime(lower_boundary.year, lower_boundary.month, 1).strftime(str_format)


def decrease_month(date_obj):
    """Decrease date in one month
    
    Args:
        date_obj
    Returns:
        A datetime object with 1 month less.
    
        decrease_month(datetime.datetime(2018,10,13))
        -> datetime.datetime(2018,9,13)
    """
    try:
        nextmonthdate = date_obj.replace(month=date_obj.month - 1)
    except ValueError:
        if date_obj.month == 1:
            nextmonthdate = date_obj.replace(year=date_obj.year - 1, month=12)
        else:
            raise

    return nextmonthdate


def increase_month(date_obj):
    """Increase date in one month
    
    Args:
        date_obj
    Returns:
        A datetime object with 1 month more.
    
        increase_month(datetime.datetime(2018,10,13))
        -> datetime.datetime(2018,11,13)
    """
    try:
        nextmonthdate = date_obj.replace(month=date_obj.month + 1)
    except ValueError:
        if date_obj.month == 12:
            nextmonthdate = date_obj.replace(year=date_obj.year + 1, month=1)
        else:
            raise

    return nextmonthdate


def get_date_target_range(start_date, end_date, str_format='%Y-%m-%d'):
    """Gets a month by month date range
    
    Args:
        start_date: string datetime object representing the start date
        end_date: string datetime object representing the end date
        str_format: String format for the output string. Default is
            YYYY-MM-DD.
    
    Returns:
        A string that correspond to the first day of the month of the
        farthest month given the lookback windows, i.e:
    
        get_date_target_range('2018-07-05', '2018-08-07')
        -> ['2018-07-31 00:00:00', '2018-08-30 00:00:00']
    """
    end_date_dt = last_day_of_month(end_date)
    current_date = datetime.datetime.strptime(start_date, str_format)
    date_ranges = []
    while current_date <= end_date_dt:
        date_ranges.append(last_day_of_month_as_str(current_date.strftime(str_format), '%Y-%m-%d %H:%M:%S'))
        current_date = increase_month(current_date)

    return date_ranges


def get_upper_boundary_date_as_str(target_date, str_format='%Y-%m-%d'):
    """Gets the upper boundary for the given target date
    Args:
        target_date: string datetime object representing the target date
    
    Returns:
        A string that correspond to the first day of the next month
    
        get_upper_boundary_date_as_str('2018-12-31')
        -> '2019-01-01'
    """
    dt_obj = datetime.datetime.strptime(target_date, str_format).replace(day=1)
    dt_obj = increase_month(dt_obj)
    return first_day_of_month_as_str(dt_obj.strftime('%Y-%m-%d'), str_format)


def get_date_ranges(dates_count, count_limit=5000, days_limit=180):
    """ Get date ranges by chunks given count and days limits wichever
    happens first
    
    Parameters:
        dates_count: Sorted Pandas Dataframe containing counts by date with
            columns names 'doc_date' and 'doc_count'
        count_limit: Chunk size limit to be used. This is going to split data
            into smaller chunks if adding a date makes the chunk size bigger
            than the stablished by the parameter.
        days_limit: Chunk size date range limit in days. This is going to split
            data into smaller chunks if adding a date makes the chunk date
            range larger (in days) that the one specified by this limit.
    
    Returns:
        Python list with tuples of start and end days for each generated chunk
        according to the specified input data and limits.
    
    Usage:
        a = pd.DataFrame([
            ('2018-01-01', 5030),
            ('2018-07-05', 30),
            ('2018-08-01', 1200),
            ('2018-08-06', 4300),
            ('2018-08-07', 1100)],
            columns=['doc_date', 'doc_count']
            )
        a['doc_date'] = pd.to_datetime(a['doc_date'])
        a = a.sort_values('doc_date').reset_index(drop=True)
        print(get_date_ranges(a))
        [
            ('2018-01-01', '2018-01-02'),
            ('2018-07-05', '2018-08-02'),
            ('2018-08-06', '2018-08-07'),
            ('2018-08-07', '2018-08-08')
        ]
    """
    date_ranges = []
    one_day_td = pd.Timedelta('1 day')
    current_start = None
    current_end = None
    temp_end = None
    current_count = 0
    for i, row in dates_count.iterrows():
        is_last_row = i == len(dates_count) - 1
        if current_start is None:
            current_start = row['doc_date']
            current_count += row['doc_count']
        else:
            current_count += row['doc_count']
            if current_count >= count_limit or (row['doc_date'] - current_start).days > days_limit:
                temp_end = row['doc_date']
            else:
                current_end = row['doc_date']
        if temp_end is not None or is_last_row:
            if current_end is None:
                current_end = current_start
            date_ranges.append((
             current_start.isoformat().split('T')[0],
             (current_end + one_day_td).isoformat().split('T')[0]))
            if temp_end is not None:
                current_start = temp_end
                current_count = row['doc_count']
                temp_end = None
                if is_last_row:
                    date_ranges.append((
                     current_start.isoformat().split('T')[0],
                     (current_start + one_day_td).isoformat().split('T')[0]))
                else:
                    current_end = None
            else:
                current_start = None
                current_end = None
                current_count = 0

    return date_ranges