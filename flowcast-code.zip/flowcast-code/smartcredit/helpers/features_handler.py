# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/helpers/features_handler.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 7417 bytes
import json
from smartcredit.models import ClientFeatureSetModel, BuyerSupplierFeatureSetModel, CurrencyFeatureSetModel
from smartcredit.models import db
from sqlalchemy.sql.functions import concat
from pandas import Timestamp, DataFrame

class FeaturesHandler:

    @staticmethod
    def dedupe_df_on_fields(df, fields, only_features_with_prefix=None):
        groups = df.groupby(fields)
        for field_values, group_df in groups:
            group_featuresets = group_df.to_dict('records')
            group_featuresets_filtered = []
            for feature_set in group_featuresets:
                group_featuresets_filtered.append({key:value for key, value in feature_set.items() if key.startswith(only_features_with_prefix)})

            first_feature_set = group_featuresets_filtered[0]
            if not all([first_feature_set == feature_set for feature_set in group_featuresets_filtered]):
                raise Exception('Feature mismatch')

    @staticmethod
    def dedupe_on_field(features, fields):
        indexes = []
        uniques = {}
        for index, feature_set in enumerate(features):
            uniquely_identifiable_value = tuple([feature_set[field] for field in fields])
            if uniquely_identifiable_value in uniques:
                doc_date, list_index = uniques[uniquely_identifiable_value]
                if feature_set['doc_date'] > doc_date:
                    uniques[uniquely_identifiable_value] = (
                     feature_set['doc_date'], index)
                else:
                    uniques[uniquely_identifiable_value] = (
                     feature_set['doc_date'], index)

        return [features[index] for doc_date, index in uniques.values()]

    @staticmethod
    def store_client_features(features):
        prefix = 'client_'
        dedupe_on = ['client']
        client_feature_keys = [feature_key for feature_key in features[0].keys() if feature_key.startswith(prefix)]
        features = FeaturesHandler.dedupe_on_field(features, dedupe_on)
        try:
            for feature_set in features:
                client_features = {client_feature_key:feature_set[client_feature_key] for client_feature_key in client_feature_keys}
                client_id = feature_set['client']
                doc_date = feature_set['doc_date']
                feature = ClientFeatureSetModel(client_id=client_id,
                  doc_date=doc_date,
                  features=client_features)
                db.add(feature)

            db.commit()
        except:
            db.rollback()
            raise

    @staticmethod
    def store_buyer_supplier_features(features):
        prefix = 'buyer_supplier_'
        dedupe_on = ['buyer_id', 'supplier_id']
        buyer_supplier_feature_keys = [feature_key for feature_key in features[0].keys() if feature_key.startswith(prefix)]
        features = FeaturesHandler.dedupe_on_field(features, dedupe_on)
        try:
            for feature_set in features:
                buyer_supplier_features = {buyer_supplier_feature_key:feature_set[buyer_supplier_feature_key] for buyer_supplier_feature_key in buyer_supplier_feature_keys}
                buyer_id = feature_set['buyer_id']
                supplier_id = feature_set['supplier_id']
                doc_date = feature_set['doc_date']
                feature = BuyerSupplierFeatureSetModel(buyer_id=buyer_id,
                  supplier_id=supplier_id,
                  doc_date=doc_date,
                  features=buyer_supplier_features)
                db.add(feature)

            db.commit()
        except:
            db.rollback()
            raise

    @staticmethod
    def store_external_currency_features(features):
        prefix = 'currency_'
        dedupe_on = ['doc_ccy_code']
        currency_feature_keys = [feature_key for feature_key in features[0].keys() if feature_key.startswith(prefix)]
        features = FeaturesHandler.dedupe_on_field(features, dedupe_on)
        try:
            for feature_set in features:
                currency_features = {currency_feature_key:feature_set[currency_feature_key] for currency_feature_key in currency_feature_keys}
                currency_code = feature_set['doc_ccy_code']
                doc_date = feature_set['doc_date']
                feature = CurrencyFeatureSetModel(currency_code=currency_code,
                  doc_date=doc_date,
                  features=currency_features)
                db.add(feature)

            db.commit()
        except:
            db.rollback()
            raise

    @staticmethod
    def store_from_df(df, clear_old_features=True, raise_on_dupes=True):
        if raise_on_dupes:
            FeaturesHandler.dedupe_df_on_fields(df, ['client', 'doc_date'], 'client_')
            FeaturesHandler.dedupe_df_on_fields(df, ['buyer_id', 'supplier_id', 'doc_date'], 'buyer_supplier_')
            FeaturesHandler.dedupe_df_on_fields(df, ['doc_ccy_code', 'doc_date'], 'ext_currency')
        features = df.to_dict('records')
        if clear_old_features:
            db.session.query(ClientFeatureSetModel).delete()
            db.session.query(BuyerSupplierFeatureSetModel).delete()
            db.session.query(CurrencyFeatureSetModel).delete()
        FeaturesHandler.store_client_features(features)
        FeaturesHandler.store_buyer_supplier_features(features)
        FeaturesHandler.store_external_currency_features(features)

    def load_client_features(client_ids):
        features = []
        features_ = db.session.query(ClientFeatureSetModel).filter(ClientFeatureSetModel.client_id.in_(client_ids))
        features_ = {featureset.client_id:featureset for featureset in features_}
        for client_id in client_ids:
            if client_id in features_:
                features.append(features_[client_id].features)
            else:
                features.append(None)

        return features

    def load_buyer_supplier_features(buyer_supplier_ids):
        features = []
        buyer_supplier_ids = ['%s_%s' % (buyer_supplier_id[0], buyer_supplier_id[1]) for buyer_supplier_id in buyer_supplier_ids]
        features_ = db.session.query(BuyerSupplierFeatureSetModel).filter(concat(BuyerSupplierFeatureSetModel.buyer_id, '_', BuyerSupplierFeatureSetModel.supplier_id).in_(buyer_supplier_ids))
        features_ = {'%s_%s' % (featureset.buyer_id, featureset.supplier_id):featureset for featureset in features_}
        for buyer_id_supplier_id in buyer_supplier_ids:
            if buyer_id_supplier_id in features_:
                features.append(features_[buyer_id_supplier_id].features)
            else:
                features.append(None)

        return features

    def load_currency_features(currency_codes):
        features = []
        features_ = db.session.query(CurrencyFeatureSetModel).filter(CurrencyFeatureSetModel.currency_code.in_(currency_codes))
        features_ = {featureset.currency_code:featureset for featureset in features_}
        for currency_code in currency_codes:
            if currency_code in features_:
                features.append(features_[currency_code].features)
            else:
                features.append(None)

        return features

    @staticmethod
    def load_to_dict(primary_keys):
        primary_keys_concatenaded = ['%s_%s_%s' % (client_id, buyer_id, supplier_id) for client_id, buyer_id, supplier_id in primary_keys]
        features_ = db.session.query(FeatureModel).filter(concat(FeatureModel.client_id, '_', FeatureModel.buyer_id, '_', FeatureModel.supplier_id).in_(primary_keys_concatenaded))
        features = []
        for primary_key in primary_keys_concatenaded:
            for feature in features_:
                feature_pk_concatenated = '%s_%s_%s' % (
                 feature.client_id, feature.buyer_id, feature.supplier_id)
                if feature_pk_concatenated == primary_key:
                    features.append(feature.features)

        if len(features) != len(primary_keys):
            raise Exception("Couldn't find precomputed features all primary keys. Requested \n (client_id, buyer_id, supplier_id) \n %s" % ('\n').join(['(%s, %s, %s)' % primary_key for primary_key in primary_keys]))
        return features

    @staticmethod
    def load_to_df(primary_keys):
        features = FeaturesHandler.load_to_dict(primary_keys)
        df = DataFrame.from_dict(features)
        return df