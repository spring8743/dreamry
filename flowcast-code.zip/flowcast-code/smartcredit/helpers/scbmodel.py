# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit/helpers/scbmodel.py
# Compiled at: 2019-03-07 20:38:51
# Size of source mod 2**32: 11721 bytes
import copy, datetime, json, logging, json, jsonschema, pandas, os, gc, strict_rfc3339
from smartcredit import FeaturesHandler
from sklearn.externals import joblib
logger = logging.getLogger('root.scbmodel')

class SCBModel(object):
    null_value_placeholder = 'NA'
    model_schema_filename = 'model_schema.json'
    api_schema_filename = 'api_schema.json'
    predictor_filename = 'predictor.pkl'

    def __init__(self, folder, model_name):
        self.models_folder = folder
        self.model_name = model_name
        self.predictor = None
        self.api_schema = None
        self.model_schema = None

    def load_predictor(self):
        predictor_folder = os.path.join(self.models_folder, self.model_name)
        predictor_path = os.path.join(predictor_folder, self.predictor_filename)
        logger.debug('Trying to load predictor %s' % self.model_name)
        predictor = joblib.load(predictor_path)
        logger.debug('Loaded %s predictor' % self.model_name)
        self.predictor = predictor

    def load_api_schema(self):
        api_schema_folder = os.path.join(self.models_folder, self.model_name)
        api_schema_path = os.path.join(api_schema_folder, self.api_schema_filename)
        with open(api_schema_path) as (api_schema_file):
            api_schema = json.loads(api_schema_file.read())
        self.api_schema = api_schema

    def validate_api_input(self, api_input):
        validator = jsonschema.Draft4Validator(schema=self.api_schema,
          format_checker=jsonschema.FormatChecker())
        return sorted(validator.iter_errors(api_input), key=str)

    def rfc3339_to_datetime(self, s):
        return datetime.datetime.fromtimestamp(strict_rfc3339.rfc3339_to_timestamp(s))

    def load_client_features(self, client_ids):
        features = []
        features_keys = self.model_schema['model_fields']['client_features']
        stored_features = FeaturesHandler.load_client_features(client_ids)
        for stored_feature in stored_features:
            if stored_feature:
                features.append(stored_feature)
            else:
                features.append({key:0 for key in features_keys})

        return features

    def load_buyer_supplier_features(self, buyer_supplier_ids):
        features = []
        features_keys = self.model_schema['model_fields']['buyer_supplier_features']
        stored_features = FeaturesHandler.load_buyer_supplier_features(buyer_supplier_ids)
        for stored_feature in stored_features:
            if stored_feature:
                features.append(stored_feature)
            else:
                features.append({key:0 for key in features_keys})

        return features

    def load_currency_features(self, currency_codes):
        features = []
        features_keys = self.model_schema['model_fields']['external_currency_features']
        stored_features = FeaturesHandler.load_currency_features(currency_codes)
        for stored_feature in stored_features:
            if stored_feature is not None:
                features.append(stored_feature)
            else:
                raise Exception("Couldn't find precalced currency features for all codes.")

        return features

    def merge_precalc_features(self, input_features):
        client_ids = [features['client_id'] for features in input_features]
        buyer_supplier_ids = [(features['buyer_id'], features['supplier_id']) for features in input_features]
        currency_codes = [features['doc_ccy_code'] for features in input_features]
        client_features = self.load_client_features(client_ids)
        buyer_supplier_features = self.load_buyer_supplier_features(buyer_supplier_ids)
        currency_features = self.load_currency_features(currency_codes)
        for index in range(len(input_features)):
            input_features[index].update(client_features[index])
            input_features[index].update(buyer_supplier_features[index])
            input_features[index].update(currency_features[index])

        return input_features

    def handle_prediction_time_features(self, features):
        for index, datapoint in enumerate(features):
            features[index]['due_date_dow'] = self.rfc3339_to_datetime(features[index]['due_date']).weekday()
            features[index]['maturity_date_dow'] = self.rfc3339_to_datetime(features[index]['maturity_date']).weekday()
            features[index]['days_between_fin_tenor_and_tenor'] = (self.rfc3339_to_datetime(features[index]['fin_tenor_start_date']) - self.rfc3339_to_datetime(features[index]['tenor_start_date'])).days
            features[index]['days_between_fin_tenor_and_due_date'] = (self.rfc3339_to_datetime(features[index]['due_date']) - self.rfc3339_to_datetime(features[index]['fin_tenor_start_date'])).days
            month = self.rfc3339_to_datetime(features[index]['doc_date']).month
            features[index]['quarter'] = (month - 1) // 3 + 1
            doc_usd_amount = features[index]['doc_ccy_amt'] * features[index]['exchange_rate']
            features[index]['doc_usd_amt'] = doc_usd_amount
            del features[index]['due_date']
            del features[index]['maturity_date']
            del features[index]['fin_tenor_start_date']
            del features[index]['tenor_start_date']
            del features[index]['doc_ccy_amt']
            del features[index]['exchange_rate']

        return features

    def predict(self, features, merge_precalc=True, compute_prediction_time_features=True):
        features_cp = copy.deepcopy(features)
        if merge_precalc:
            features_cp = self.merge_precalc_features(features_cp)
        if compute_prediction_time_features:
            features_cp = self.handle_prediction_time_features(features_cp)
        features_df = self.json_to_dataframe(features_cp)
        del features_cp
        gc.collect()
        features_df = self.one_hot_encode_df(features_df)
        columns_to_drop_on = [
         'client_id', 'buyer_id', 'supplier_id']
        if 'doc_date' in features_df:
            columns_to_drop_on.append('doc_date')
        features_df = features_df.drop(columns=columns_to_drop_on)
        features_df = features_df[sorted(features_df.columns.tolist())]
        buckets_probabilities = self.predict_from_dataframe(features_df)
        predictions = []
        for probabilities in buckets_probabilities:
            labels = self.model_schema['bucket_labels']
            predictions.append({'model_id':'1', 
             'prediction_time':datetime.datetime.utcnow().isoformat() + 'Z', 
             'probability':{label:probabilities[index] for index, label in enumerate(labels)}, 
             'buckets_prediction':labels[probabilities.index(max(probabilities))], 
             'buckets_confidence':max(probabilities)})

        return predictions

    def one_hot_encode_df(self, df):
        one_hot_encoded_fields = self.model_schema['model_fields']['categorical_features']
        for field_name in one_hot_encoded_fields:
            allowed_values = self.model_schema['model_fields']['allowed_values'][field_name]
            for allowed_value in allowed_values:
                col = df[field_name] == df[field_name].dtype.type(allowed_value)
                df['%s_%s' % (field_name, allowed_value)] = col

            allow_null = field_name in self.model_schema['model_fields']['allow_null']
            if allow_null:
                df['%s_%s' % (field_name, 'NA')] = df[field_name] == 'NA'

        df = df.drop(columns=one_hot_encoded_fields)
        return df

    def json_to_dataframe(self, json):
        return pandas.DataFrame.from_dict(json)

    def dataframe_to_json(self, dataframe):
        return dataframe.to_dict('records')

    def predict_from_dataframe(self, df):
        logger.debug('Predicting from columns: %s' % str(df.columns.tolist()))
        return self.predictor.predict_proba(df).tolist()

    def store_model(self, predictor, data, numeric_features, categorical_features, labels):
        self.store_predictor(predictor)
        self.store_schema(data, numeric_features, categorical_features, labels)

    def get_predictor_filepath(self):
        folder = os.path.join(self.models_folder, self.model_name)
        predictor_path = os.path.join(folder, self.predictor_filename)
        return predictor_path

    def get_api_schema_filepath(self):
        return os.path.join(self.models_folder, self.model_name, self.api_schema_filename)

    def get_model_schema_filepath(self):
        return os.path.join(self.models_folder, self.model_name, self.model_schema_filename)

    def create_model_folder(self):
        folder = os.path.join(self.models_folder, self.model_name)
        if not os.path.exists(folder):
            os.makedirs(folder)

    def load_model_schema(self):
        model_schema_filepath = self.get_model_schema_filepath()
        with open(model_schema_filepath) as (model_schema_file):
            model_schema = json.loads(model_schema_file.read())
        self.model_schema = model_schema

    def store_predictor(self, predictor):
        self.create_model_folder()
        predictor_path = self.get_predictor_filepath()
        joblib.dump(predictor, predictor_path)

    def store_schema(self, data, numeric_features, categorical_features, labels):
        self.create_model_folder()
        schema = {}
        schema['bucket_labels'] = labels
        schema['model_fields'] = {}
        schema['model_fields']['numeric_features'] = numeric_features
        schema['model_fields']['categorical_features'] = categorical_features
        schema['model_fields']['client_features'] = list(filter(lambda feature: feature.startswith('client_'), numeric_features))
        schema['model_fields']['buyer_supplier_features'] = list(filter(lambda feature: feature.startswith('buyer_supplier_'), numeric_features))
        schema['model_fields']['external_currency_features'] = list(filter(lambda feature: feature.startswith('ext_currency_'), numeric_features))
        schema['model_fields']['allowed_values'] = {}
        schema['model_fields']['allow_null'] = []
        for feature in categorical_features:
            unique_values = data[feature].unique().tolist()
            field_null_value_placeholder = SCBModel.null_value_placeholder
            if field_null_value_placeholder in unique_values:
                schema['model_fields']['allow_null'].append(feature)
                unique_values.pop(unique_values.index(field_null_value_placeholder))
            schema['model_fields']['allowed_values'][feature] = [str(value) for value in unique_values]

        model_schema_folder = os.path.join(self.models_folder, self.model_name)
        model_schema_filepath = os.path.join(model_schema_folder, self.model_schema_filename)
        with open(model_schema_filepath, 'w') as (model_schema_file):
            model_schema_file.write(json.dumps(schema, indent=4))