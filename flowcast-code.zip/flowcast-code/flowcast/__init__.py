# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: flowcast/__init__.py
# Compiled at: 2019-03-07 20:38:41
# Size of source mod 2**32: 182 bytes
"""
    flowcast
    ~~~~~
    Shared python tools and utils.
    :copyright: � 2018 by Flowcast Inc.
"""
__version__ = '0.4.0'
from .config import config