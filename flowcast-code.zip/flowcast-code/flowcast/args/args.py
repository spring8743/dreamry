# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: flowcast/args/args.py
# Compiled at: 2019-03-07 20:38:41
# Size of source mod 2**32: 2902 bytes
"""
    flowcast.args.args
    ~~~~~
    :copyright: � 2018 by Flowcast Inc.
"""
from abc import ABC, abstractmethod
from flowcast.config import BaseConfig

class BaseArgs(ABC):
    """ Base argument management class
    
    This abstact class handles cli arguments and config merges
    You need to inherit from BaseArgs and implement parse_args
    in order to be able to use it.
    
    Attributes:
        config_override: Boolean setting for config overriding.
        Default: False. When set to True, config files or environment
        variables overrides cli args
    
    
    Usage:
        You can use BaseArgs as follows:
    
        import argparse
        from flowcast.args import BaseArgs
    
    
        class SomeArgs(BaseArgs):
            def __init__(self, *args):
                super().__init__(*args)
    
            def prepare_args(self):
                pass
    
            def parse_args(self):
                parser = argparse.ArgumentParser(description='Some Args Parser')
                parser.add_argument('--some_arg',
                    type=str,
                    default='default string value',
                    help="Help description")
                self.params = parser.parse_args()
    
            def extra_args(self, args_obj):
                # You can setup extra args in case that
                # you are sharing a CLI arg parser class
                pass
        
        some_args = SomeArgs().get_params()
        print(some_args.some_arg)  # Use some_arg
    
    """
    params = None
    config_section = None

    def __init__(self, config_override=False, *args, **kwargs):
        self.override = config_override
        self.build_args()

    @abstractmethod
    def parse_args(self):
        pass

    @abstractmethod
    def prepare_args(self):
        pass

    @abstractmethod
    def extra_args(self, parser):
        pass

    def merge_args(self, config_section):
        """Merges config values with cli args when names matches for a given
        config section. In case of collision config values overrides cli args
        or you can set it up using BaseArgs `config_override` param.
        
        Args:
            config_section: Config section name.
        """
        config = {}
        try:
            config = (BaseConfig(section=config_section)).get()
        except Exception:
            pass

        for key, value in config.items():
            if not hasattr(self.params, key) or getattr(self.params, key) is None:
                setattr(self.params, key, value)
            elif self.override:
                setattr(self.params, key, value)

    def build_args(self):
        self.parse_args()
        self.merge_args(self.config_section)
        self.prepare_args()

    def get_params(self):
        return self.params