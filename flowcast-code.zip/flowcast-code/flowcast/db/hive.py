# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: flowcast/db/hive.py
# Compiled at: 2019-03-07 20:38:41
# Size of source mod 2**32: 11715 bytes
import datetime, flowcast.logging, logging
from flowcast.config import BaseConfig
from pyhive import hive
logger = logging.getLogger('root.hivear')

class ModelValidationException(Exception):
    pass


class classproperty(object):

    def __init__(self, fget):
        self.fget = fget

    def __get__(self, obj, cls):
        return self.fget(cls)


class Column(object):

    def __init__(self, nullable=False):
        self.nullable = nullable

    def __get__(self, obj, cls):
        if obj is None:
            return self
            if not getattr(obj, '_ardict', None):
                obj._ardict = {}
            return obj._ardict.get(str(id(self)), None)

    def __set__(self, obj, value):
        validation_passed, validation_message = self.validate(value)
        if validation_passed:
            if value is not None:
                if not getattr(obj, '_ardict', None):
                    obj._ardict = {}
                obj._ardict[str(id(self))] = self.cast_to_type(value)
            else:
                raise ModelValidationException(validation_message)

    @classmethod
    def get_none_repr(cls):
        return 'null'

    def is_nullable(self):
        return self.nullable


class FloatColumn(Column):

    def validate(self, value):
        if value != None and not isinstance(value, (int, float)):
            try:
                value = self.cast_to_type(value)
            except:
                return (
                 False, '%s is not int or float' % value)

            return (True, None)

    @classmethod
    def get_value_repr(cls, value):
        if value is None:
            return cls.get_none_repr()
            return '%s' % value

    def get_hive_type_as_string(self):
        return 'float'

    def cast_to_type(self, value):
        return float(value)


class DoubleColumn(Column):

    def validate(self, value):
        if value != None and not isinstance(value, (int, float)):
            try:
                value = self.cast_to_type(value)
            except:
                return (
                 False, '%s is not int or float' % value)

            return (True, None)

    @classmethod
    def get_value_repr(cls, value):
        if value is None:
            return cls.get_none_repr()
            return '%s' % value

    def get_hive_type_as_string(self):
        return 'double'

    def cast_to_type(self, value):
        return float(value)


class BigIntColumn(Column):

    def validate(self, value):
        if value != None and not isinstance(value, int):
            try:
                value = self.cast_to_type(value)
            except:
                return (
                 False, '%s is not an integer' % value)

            return (True, None)

    @classmethod
    def get_value_repr(cls, value):
        if value is None:
            return cls.get_none_repr()
            return '%s' % value

    def get_hive_type_as_string(self):
        return 'bigint'

    def cast_to_type(self, value):
        return int(value)


class IntColumn(Column):

    def validate(self, value):
        if value != None and not isinstance(value, int):
            try:
                value = self.cast_to_type(value)
            except:
                return (
                 False, '%s is not an integer' % value)

            return (True, None)

    @classmethod
    def get_value_repr(cls, value):
        if value is None:
            return cls.get_none_repr()
            return '%s' % value

    def get_hive_type_as_string(self):
        return 'int'

    def cast_to_type(self, value):
        return int(value)


class StringColumn(Column):

    def validate(self, value):
        if value != None and not isinstance(value, str):
            try:
                value = self.cast_to_type(value)
            except:
                return (
                 False, '%s is not a string' % value)

            return (True, None)

    @classmethod
    def get_value_repr(cls, value):
        if value is None:
            return cls.get_none_repr()
            return '"%s"' % value

    def cast_to_type(self, value):
        return str(value)

    def get_hive_type_as_string(self):
        return 'string'


class TimestampColumn(Column):

    def validate(self, value):
        if value != None:
            if not isinstance(value, datetime.datetime):
                return (False, 'Timestamp value must be a datetime object')
                return (True, None)

    @classmethod
    def get_value_repr(cls, value):
        if value is None:
            return cls.get_none_repr()
            return '"%s"' % value.strftime('%Y-%m-%d %H:%M:%S')

    def get_hive_type_as_string(self):
        return 'timestamp'

    def cast_to_type(self, value):
        return value


class Model:
    _isnew_ = True
    _create_table_if_not_exists_ = True
    _table_exists = None
    _conn = None

    @classproperty
    def attributes(cls):
        if not getattr(cls, '__attributes', None):
            cls._Model__attributes = list(filter(lambda attribute: not (attribute.startswith('_') or callable(getattr(cls, attribute))), [attr for attr in cls.__dict__.keys() if attr != 'attributes']))
        return cls._Model__attributes

    @classmethod
    def get_attributes(cls):
        return cls.attributes

    @classmethod
    def get_connection_parameters(cls):
        config = (BaseConfig(section='hive')).get()
        conn_config = {'host':config.host, 
         'database':config.database, 
         'username':config.username, 
         'auth':config.auth, 
         'password':config.password, 
         'port':int(config.port)}
        delete_keys = []
        for key, value in conn_config.items():
            if not value:
                delete_keys.append(key)

        for key in delete_keys:
            del conn_config[key]

        return conn_config

    @classmethod
    def get_connection(cls):
        if not cls._conn:
            cls._conn = hive.Connection(**cls.get_connection_parameters())
        return cls._conn

    @classmethod
    def instantiate_result_models(cls, results):
        models = []
        for result in results:
            properties = {cls.attributes[i]:result[i] for i in range(len(cls.attributes))}
            model = cls(**properties)
            model._isnew_ = False
            models.append(model)

        return models

    @classmethod
    def get_nullable_attributes(cls):
        nullable_attributes = []
        for attribute in cls.get_attributes():
            if getattr(cls, attribute).is_nullable():
                nullable_attributes.append(attribute)

        return nullable_attributes

    @classmethod
    def delete_table(cls):
        if cls.table_exists():
            query = '\n                DROP TABLE %s\n            ' % cls._tablename_
            cls._table_exists = None
            return cls.execute_query(query)

    @classmethod
    def truncate_table(cls):
        if cls.table_exists():
            query = '\n                TRUNCATE TABLE %s\n            ' % cls._tablename_
            cls._table_exists = None
            return cls.execute_query(query)

    @classmethod
    def flush(cls, batch_size=1000):
        if getattr(cls, '_insert_queue', None):
            n_records = len(cls._insert_queue)
            while cls._insert_queue:
                batch, cls._insert_queue = cls._insert_queue[:batch_size], cls._insert_queue[batch_size:]
                composite_query = '\n                    \n                    INSERT INTO {table_name} VALUES {values}\n                '
                composite_query = composite_query.format(table_name=cls._tablename_,
                  values=(',').join([model.get_values_statement() for model in batch]))
                cls.execute_query(composite_query, force_mr=False)
                logger.info('Inserted %s models (%s to go)' % (len(batch), len(cls._insert_queue)))

        else:
            logger.debug('Nothing to flush on class %s' % repr(cls))

    @classmethod
    def execute_query(cls, query, force_mr=False):
        conn = cls.get_connection()
        cursor = conn.cursor()
        if force_mr:
            cursor.execute('\n                set hive.execution.engine=mr\n            ')
        try:
            cursor.execute(query)
            try:
                result = cursor.fetchall()
            except BaseException as e:
                if str(e) == 'No result set':
                    result = True
                else:
                    raise

            cursor.close()
        except:
            cursor.close()
            conn.close()
            raise

        return result

    @classmethod
    def models_from_query(cls, query):
        cls.check_and_create_table()
        return cls.instantiate_result_models(cls.execute_query(query))

    def __init__(self, **kwargs):
        self.__class__.check_and_create_table()
        if kwargs:
            extra_keys = set(kwargs.keys()) - set(self.attributes)
            if extra_keys:
                raise ModelValidationException('Unknown properties: %s' % (',').join(extra_keys))
            for key, value in kwargs.items():
                setattr(self, key, value)

    @classmethod
    def check_and_create_table(cls):
        if cls._create_table_if_not_exists_:
            if not cls.table_exists():
                cls.create_table()
                cls._table_exists = True

    @classmethod
    def create_table(cls):
        sql = '\n            CREATE TABLE {table_name} ({columns})\n        '
        table_name = cls._tablename_
        columns = (',').join(['%s %s' % (attribute, getattr(cls, attribute).get_hive_type_as_string()) for attribute in cls.attributes])
        return cls.execute_query(sql.format(table_name=table_name, columns=columns))

    @classmethod
    def table_exists(cls):
        if cls._table_exists is None:
            sql = "\n                SHOW TABLES LIKE '%s'\n            " % cls._tablename_
            if len(cls.execute_query(sql)) == 1:
                cls._table_exists = True
            else:
                cls._table_exists = False
            return cls._table_exists

    def get_values_statement(self):
        values_repr = []
        for attribute in self.attributes:
            column_class = getattr(self.__class__, attribute)
            attribute_value = getattr(self, attribute)
            attribute_value_repr = column_class.__class__.get_value_repr(attribute_value)
            values_repr.append(attribute_value_repr)

        values = (',').join(values_repr)
        return '(%s)' % values

    def get_insert_statement(self):
        sql = '\n            \n            INSERT INTO {table_name}\n            VALUES {values};\n        '
        table_name = self._tablename_
        return sql.format(table_name=table_name, values=self.get_values_statement())

    def add_self_to_insert_queue(self):
        if not getattr(self.__class__, '_insert_queue', None):
            setattr(self.__class__, '_insert_queue', [])
        self.__class__._insert_queue.append(self)
        return True

    def add(self):
        for attribute in self.attributes:
            if getattr(self, attribute) is None:
                raise getattr(self.__class__, attribute).is_nullable() == False and ModelValidationException('Attribute %s is not nullable' % attribute)

        if not self._isnew_:
            raise Exception('Update not implemented')
        self.add_self_to_insert_queue()