# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: flowcast/security/flask.py
# Compiled at: 2019-03-07 20:38:41
# Size of source mod 2**32: 1610 bytes
from flask import request
from flowcast.security.cognito import OAuthValidator, OAuthValidationException, InvalidSignatureException, ExpiredTokenException
from flowcast.config import BaseConfig
from jose import JWTError
handlers = {'unauthorized':None, 
 'expired':None, 
 'invalid':None}

def require_oauth(f):

    def wf(*args, **kwargs):
        config = (BaseConfig(section='flask_oauth')).get()
        if not int(getattr(config, 'enabled', 1)):
            return f(*args, **kwargs)
            authorization_header = request.headers.get('Authorization', None)
        if authorization_header:
            access_token = authorization_header.replace('Bearer ', '')
            is_token_valid = False
            try:
                is_token_valid = OAuthValidator.validate_jwt_token(access_token)
            except OAuthValidationException as e:
                if handlers['unauthorized']:
                    return handlers['unauthorized'](str(e))
                    raise
            except (InvalidSignatureException, JWTError) as e:
                if handlers['invalid']:
                    return handlers['invalid'](str(e))
                    raise
            except ExpiredTokenException as e:
                if handlers['expired']:
                    return handlers['expired'](str(e))
                    raise

            if is_token_valid:
                return f(*args, **kwargs)
            else:
                e = 'No token found in the request.'
                if handlers['invalid']:
                    return handlers['invalid'](e)
                    raise OAuthValidationException(e)

    wf.__name__ = f.__name__
    return wf


def invalid_access_token_handler(f):
    handlers['invalid'] = f
    return f


def expired_access_token_handler(f):
    handlers['expired'] = f
    return f


def unauthorized_access_token_handler(f):
    handlers['unauthorized'] = f
    return f