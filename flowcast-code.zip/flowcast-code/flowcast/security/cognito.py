# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: flowcast/security/cognito.py
# Compiled at: 2019-03-07 20:38:41
# Size of source mod 2**32: 1733 bytes
import requests, json, time
from flowcast.config import BaseConfig
from jose import jwk, jwt
from jose.utils import base64url_decode

class OAuthValidationException(Exception):
    pass


class InvalidSignatureException(OAuthValidationException):
    pass


class ExpiredTokenException(OAuthValidationException):
    pass


class OAuthValidator:
    keys_url = 'https://cognito-idp.{}.amazonaws.com/{}/.well-known/jwks.json'
    _config = None
    _keys = {}

    @staticmethod
    def get_config():
        if not OAuthValidator._config:
            OAuthValidator._config = (BaseConfig(section='cognito_oauth')).get()
        return OAuthValidator._config

    @staticmethod
    def get_cognito_key(kid):
        config = OAuthValidator.get_config()
        region = config.region
        userpool_id = config.userpool_id
        keys_url = OAuthValidator.keys_url.format(region, userpool_id)
        response = requests.get(keys_url)
        keys = json.loads(response.text)['keys']
        for key in keys:
            if key['kid'] == kid:
                return jwk.construct(key)

        raise OAuthValidationException('No key with matching kid was found.')

    @staticmethod
    def validate_jwt_token(token):
        message = ('.').join(token.split('.')[:-1])
        message = message.encode('utf-8')
        encoded_signature = token.split('.')[-1]
        encoded_signature = encoded_signature.encode('utf-8')
        decoded_signature = base64url_decode(encoded_signature)
        headers = jwt.get_unverified_headers(token)
        kid = headers['kid']
        public_key = OAuthValidator.get_cognito_key(kid)
        if not public_key.verify(message, decoded_signature):
            raise InvalidSignatureException('Wrong signature')
        claims = jwt.get_unverified_claims(token)
        if time.time() > claims['exp']:
            raise ExpiredTokenException('Token is expired')
        return True