# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: flowcast/config/config.py
# Compiled at: 2019-03-07 20:38:41
# Size of source mod 2**32: 6645 bytes
"""
    flowcast.config
    ~~~~~
    :copyright: � 2018 by Flowcast Inc.
"""
import os, inspect, configparser
HOME = os.path.expanduser('~')
CWD = os.getcwd()

class Config(dict):

    def __init__(self):
        super().__init__()

    def __getattr__(self, name):
        if name in self:
            return self[name]
            raise AttributeError('No such attribute: ' + name)

    def __setattr__(self, name, value):
        self[name] = value

    def __delattr__(self, name):
        if name in self:
            del self[name]
        else:
            raise AttributeError('No such attribute: ' + name)


class BaseConfig(object):
    """ Base configuration class
    
    This class handles load and configuration overwrites using
    .ini config files values and/or environments variables. 
    Environment variables have precedence over any other source
    of configuration.
    
    Attributes:
        section: Config section name. i.e: grabber, api, etc
        env_prefix: String prefix used to setup os env vars
        search_paths: Ordered list of path to search for configuration files.
        Can be extended through class initialization using `paths` __init__
        args. By default looks for the following paths in order:
            1.- Path set by FC_CONFIG_FILE environment variable (if set)
            2.- $PWD/config.ini (execution folder)
            3.- $HOME/confih.ini (home folder)
    
    Usage:
        You can setup config variables using .ini files or enviroment files
        File:
        [mymodule]
        SOME_CONFIG_VAR_NAME = somevalue
    
        or Environment vars (using FC__ default prefix):
        export FC__MYMODULE__SOME_CONFIG_VAR_NAME=somevalue
    
        from flowcast.config import BaseConfig
        base_config = BaseConfig(env='mymodule', paths='mymodule_config.ini')
        config_properties = base_config.get()
        
        # Access config properties using lowercase names
        # This will access only the configurations for the specified section
        # or module
        config_properties.some_config_var_name
    
    """

    def __init__(self, section=None, env_prefix='FC', paths=None, separator='__', conf_env_var='FC_CONFIG_FILE', *args, **kwargs):
        """ Initializes the class
            Args:
                section: Section to be used. This could be a module or a component
                    name used as a reference for config.
                env_prefix: Environment variables prefix to be used to read
                    variables from the enviroment vars namespace. Default: 'FC'
                paths: Aditional paths to lookup config for. This could be a string
                    representing one path or can be a list of string representing
                    multiple paths. This will take precedence and will have more
                    priorioty that defaults ones. Order is important if you specify
                    a list.
                separator: Separator to be used to separate env_prefix, section or
                    module and the variable name. Default: '__'.
                    Example:FC__SECTION_NAME__VARIABLE_NAME where FC is the env
                    prefix, SECTION_NAME is the section/module name and
                    VARIABLE_NAME is the config attribute to be set.
                conf_env_var: Environment variable to set a full path to config
                    file. If this env var is set, the file there will be used.
        
        Returns:
            Pandas DataFrame object with the following columns:
                seller_id, late_days_score, dilution_rate_score,
                late_days_confidence, dilution_rate_confidence,
                cost_of_lateness, cost_of_dilution, total_amount
            """
        self.configured = False
        self.conf = Config()
        self.section = section if section is not None else inspect.getmodule(inspect.stack()[1][0]).__name__
        self.sep = separator
        self.env_prefix = env_prefix + self.sep
        self.search_paths = [
         os.path.join(CWD, 'config.ini'),
         os.path.join(HOME, 'config.ini')]
        if conf_env_var in os.environ:
            if len(os.environ[conf_env_var]) > 0:
                self.search_paths = [
                 os.environ[conf_env_var]] + self.search_paths
        if paths is not None:
            if not isinstance(paths, list):
                paths = [
                 paths]
            self.search_paths = paths + self.search_paths
        if not self.setup():
            raise Exception('No config found for section: [%s] nor [%s] environ prefix' % (
             self.section, self.env_prefix))

    def setup(self):
        """ Setup configuration from files in search path
        
            This method has 2 stages:
            1.- scan for config files and store variables if any file is
                found. While is processing files, if a config file is found the
                setup won't continue with the following files as the search
                path is ordered by precedence
            2.- Scan for os environment variables with the self.env_prefix
                (default 'FC') and the separator self.sep (default '__'). Any
                variable found is stored in the configuration dictionary and
                overrides values set by the config files.
        """
        parser = configparser.ConfigParser()
        for path in self.search_paths:
            if parser.read(path):
                if self.section not in parser:
                    pass
                else:
                    for key, value in parser[self.section].items():
                        self.conf[key] = value

                    self.configured = True
                    break

        env_vars = [x for x in os.environ.keys() if x[:len(self.env_prefix)] == self.env_prefix]
        env_vars_section = [x for x in env_vars if x.split(self.sep)[1].lower() == self.section]
        env_vars_filtered = [x for x in env_vars_section if os.environ[x] != '']
        for env_var in env_vars_filtered:
            self.conf[env_var.split(self.sep)[-1].lower()] = os.environ[env_var]

        if len(env_vars_filtered) > 0:
            self.configured = True
        return self.configured

    def get(self):
        return self.conf