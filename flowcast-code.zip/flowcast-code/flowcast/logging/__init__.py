# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: flowcast/logging/__init__.py
# Compiled at: 2019-03-07 20:38:41
# Size of source mod 2**32: 1360 bytes
import logging
from pythonjsonlogger import jsonlogger
from flowcast.config import BaseConfig
supported_keys = [
 'asctime',
 'created',
 'filename',
 'funcName',
 'levelname',
 'levelno',
 'lineno',
 'module',
 'msecs',
 'message',
 'name',
 'pathname',
 'process',
 'processName',
 'relativeCreated',
 'thread',
 'threadName']
log_format = lambda x: [('%({0:s})').format(i) for i in x]
config = (BaseConfig(section='logging')).get()
custom_format = (' ').join(log_format(supported_keys))
formatter = jsonlogger.JsonFormatter(custom_format)
log_type = getattr(config, 'type', 'STDOUT').lower()
log_level = getattr(logging, getattr(config, 'level', 'INFO'))
if log_type == 'stdout':
    logHandler = logging.StreamHandler()
    logHandler.setFormatter(formatter)
    logging.basicConfig(level=log_level,
      format='%(asctime)s %(name)s %(levelname)s %(message)s')
else:
    if log_type == 'file':
        log_filepath = config.log_filepath
        logHandler = logging.FileHandler(log_filepath)
        logHandler.setFormatter(formatter)
        logging.basicConfig(level=log_level,
          handlers=[
         logHandler])
    else:
        raise Exception('Invalid log type from configuration: %s' % log_type)