# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_api/__init__.py
# Compiled at: 2019-03-07 20:39:32
# Size of source mod 2**32: 2212 bytes
import logging, flowcast.logging, sys
from flask import Flask, jsonify, render_template, request
app = Flask(__name__)
logger = logging.getLogger(__name__)
from smartcredit_api.helpers import CustomJSONEncoder
from smartcredit_api.handlers import PredictHandler
from flowcast.security.flask import require_oauth
app.json_encoder = CustomJSONEncoder
PredictHandler.init()

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'OK'})


@app.route('/v1/predict', methods=['GET', 'POST'])
@require_oauth
def predict():
    request_json = {'data': {'id':'ad434964', 
              'type':'PredictorInput', 
              'attributes':{'predictors': [
                              {'client_id':'100574882', 
                               'buyer_id':'103771650', 
                               'supplier_id':'108415183', 
                               'cg':'14', 
                               'cty_code':'SP', 
                               'doc_ccy_code':'USD', 
                               'buyer_country':'JP', 
                               'supplier_country':'DF', 
                               'tenor':30, 
                               'fin_tenor':90, 
                               'doc_type_code':'POOL', 
                               'grace_period':10, 
                               'product':'PSHP', 
                               'due_date':'2018-08-25T12:42:31+00:00', 
                               'fin_tenor_start_date':'2018-08-25T12:42:31+00:00', 
                               'maturity_date':'2018-08-25T12:42:31+00:00', 
                               'tenor_start_date':'2018-08-25T12:42:31+00:00', 
                               'doc_ccy_amt':4, 
                               'doc_date':'2018-08-25T12:42:31+00:00', 
                               'exchange_rate':1.12}]}}}
    request_json = request.get_json(force=True)
    return PredictHandler.handle(request_json)


@app.route('/docs')
def docs():
    return render_template('docs.html')