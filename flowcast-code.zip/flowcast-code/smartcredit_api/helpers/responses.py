# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_api/helpers/responses.py
# Compiled at: 2019-03-07 20:39:32
# Size of source mod 2**32: 2970 bytes
from smartcredit_api import logger
import datetime
from flask import Response, json
from flask.json import JSONEncoder
import http

class CustomJSONEncoder(JSONEncoder):

    def default(self, obj):
        if isinstance(obj, Mock):
            return obj.__dict__
            if isinstance(obj, JsonData):
                return obj.__dict__
                if isinstance(obj, JsonError):
                    return obj.__dict__
                    return JSONEncoder.default(self, obj)


class Mock(object):

    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


class JsonData:

    def __init__(self, type, id=None, attributes=None):
        if not id:
            id = get_rfc3339_datetime()
        self.type = type
        self.id = str(id)
        self.attributes = attributes


class JsonError:

    def __init__(self, status, title, message, id=None, pointer=None, meta=None):
        if not id:
            id = get_rfc3339_datetime()
        self.id = str(id)
        self.status = str(status.value)
        self.code = ('{} {}').format(status, status.phrase)
        self.title = str(title)
        self.detail = str(message)
        if pointer:
            self.source = {'pointer': str(pointer)}
        if meta:
            self.meta = meta


def failure_response(errors, status=http.HTTPStatus.BAD_REQUEST):
    return json_response(payload={'errors': errors}, status=status)


def json_response(payload, status):
    return Response(response=json.dumps(payload), status=status,
      mimetype='application/vnd.api+json')


def success_response(data, status=http.HTTPStatus.OK):
    return json_response(payload={'data': data}, status=status)


def validation_error_response(validation_errors):
    formatted_errors = format_validation_errors(validation_errors)
    result = failure_response(formatted_errors)
    return result


def prediction_response(predictions):
    result = []
    for item in predictions:
        result.append(JsonData(id=get_rfc3339_datetime(),
          type='Prediction',
          attributes=item))

    return success_response(result)


def get_rfc3339_datetime(value=None):
    if value is None:
        value = datetime.datetime.utcnow()
    return value.isoformat('T') + 'Z'


def format_validation_errors(errors):
    result = []
    for error in errors:
        try:
            message = error.schema['x-message'][error.validator]
        except KeyError:
            message = error.message

        result.append(JsonError(status=http.HTTPStatus.BAD_REQUEST,
          title='Input Validation Error',
          pointer=error.schema['$id'],
          message=message,
          meta={'validator':error.validator, 
         'validator_value':error.validator_value}))

    return result