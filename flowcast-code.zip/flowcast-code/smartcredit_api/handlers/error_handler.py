# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_api/handlers/error_handler.py
# Compiled at: 2019-03-07 20:39:32
# Size of source mod 2**32: 2113 bytes
import http
from smartcredit_api import app, logger
from werkzeug.exceptions import HTTPException, default_exceptions
from flowcast.security.flask import unauthorized_access_token_handler, invalid_access_token_handler, expired_access_token_handler
from smartcredit_api.helpers import failure_response, JsonError
from smartcredit.models import db

@app.teardown_request
def teardown(exc):
    if db:
        if hasattr(db, 'session'):
            db.session.remove()


@app.errorhandler(404)
def handle_404(e):
    status = http.HTTPStatus.NOT_FOUND
    return failure_response(errors=[
     JsonError(status=status,
       title=status.description,
       message=internal_message if status is http.HTTPStatus.INTERNAL_SERVER_ERROR else str(e))],
      status=status)


@app.errorhandler(Exception)
def handle_error(e):
    status = http.HTTPStatus.INTERNAL_SERVER_ERROR
    internal_message = 'The server encountered an internal error and was unable to complete your request. Either the server is overloaded or there is an error in the application.'
    if isinstance(e, HTTPException):
        status = http.HTTPStatus(e.code)
    if status is http.HTTPStatus.INTERNAL_SERVER_ERROR:
        logger.error(('Internal Server Error: {}').format(e), exc_info=True)
    return failure_response(errors=[
     JsonError(status=status,
       title=status.description,
       message=internal_message if status is http.HTTPStatus.INTERNAL_SERVER_ERROR else str(e))],
      status=status)


@invalid_access_token_handler
@unauthorized_access_token_handler
@expired_access_token_handler
def unauthorized_error_response(message='No valid Bearer token provided.'):
    status = http.HTTPStatus.UNAUTHORIZED
    logger.info(message)
    return failure_response(errors=[
     JsonError(status=status,
       title=status.description,
       message=message)],
      status=status)