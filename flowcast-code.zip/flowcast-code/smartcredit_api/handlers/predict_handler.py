# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_api/handlers/predict_handler.py
# Compiled at: 2019-03-07 20:39:32
# Size of source mod 2**32: 2534 bytes
import os
from smartcredit_api import logger
from smartcredit_api.helpers.responses import CustomJSONEncoder, JsonData, failure_response, prediction_response, validation_error_response, get_rfc3339_datetime, Mock
from smartcredit import SCBModel
from flowcast.config import BaseConfig

class PredictHandler:
    model_names = [
     'dr_buckets', 'late_days_buckets']
    models = {}
    config = (BaseConfig(section='smartcredit_api')).get()

    @staticmethod
    def init():
        logger.info('Initializing PredictHandler')
        for model_name in PredictHandler.model_names:
            logger.info('Loading model %s' % model_name)
            model = SCBModel(PredictHandler.config.models_path, model_name)
            model.load_predictor()
            model.load_api_schema()
            model.load_model_schema()
            PredictHandler.models[model_name] = model

    @staticmethod
    def handle(request_json):
        validation_errors = PredictHandler.models['dr_buckets'].validate_api_input(request_json)
        if validation_errors:
            logger.info('Invalid request:\n%s\n%s', request_json, validation_errors)
            return validation_error_response(validation_errors)
            predictors = request_json['data']['attributes']['predictors']
            logger.info('Request valid - %s predictors' % len(predictors))
            predictions_dr = PredictHandler.models['dr_buckets'].predict(predictors)
            predictions_ld = PredictHandler.models['late_days_buckets'].predict(predictors)
            logger.info('Prediction successfull - building response')
            response = []
            for index in range(len(predictions_dr)):
                prediction_dr = Mock(**predictions_dr[index])
                prediction_ld = Mock(**predictions_ld[index])
                prediction = [
                 JsonData(type='DilutionRate',
                   attributes=prediction_dr),
                 JsonData(type='LateDays',
                   attributes=prediction_ld)]
                predictor_response = {'predictor':predictors[index], 
                 'predictions':prediction}
                predictor_response = Mock(**predictor_response)
                response.append(predictor_response)

            return prediction_response(response)