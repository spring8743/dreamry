# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/data_ingestion.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 2634 bytes
import pandas as pd
from pyhive import hive
from flowcast.config import BaseConfig
from smartcredit_tx.utils.utils import convert_dates, convert_floats
null_string = 'NA'

def find_replace(df, col, input_, repl, regex=False):
    df[col] = df[col].replace(input_, repl, regex=regex)


def transform_data(data):
    data.dropna(subset=['doc_date', 'doc_ccy_amt', 'fin_tenor', 'tenor'], inplace=True)
    max_date = max(pd.to_datetime(data['doc_date'], errors='coerce'))
    data.rename(columns={'product_code':'product',  'credit_grade':'cg', 
     'cust_leid':'leid', 
     'industry_sector':'Industry'},
      inplace=True)
    nulls = {'pymt_ccy_code':'USD',  'pymt_to_doc_fx_rate':'1', 
     'pymt_alloc_amt':'0', 
     'doc_ccy_adj_amt':'0.0', 
     'year_rate':'1.0', 
     'pymt_value_date':str(max_date), 
     'cg':null_string, 
     'buyer_country':null_string, 
     'supplier_country':null_string, 
     'Industry':null_string, 
     'doc_type_code':null_string}
    data.fillna(value=nulls, inplace=True)
    data = convert_dates(data, ['tenor_start_date', 'due_date', 'maturity_date', 'fin_tenor_start_date', 'doc_date'])
    data = convert_floats(data, ['pymt_alloc_amt', 'doc_ccy_amt', 'pymt_to_doc_fx_rate', 'year_rate',
     'dr', 'late_days', 'doc_ccy_adj_amt'])
    find_replace(data, 'buyer_country', '', null_string)
    find_replace(data, 'buyer_country', '\\s+', null_string, regex=True)
    data.fillna(null_string, inplace=True)
    return data


def load_data():
    hive_config = (BaseConfig(section='hive')).get()
    training_config = (BaseConfig(section='model_training')).get()
    conn_config = {'host':hive_config.host, 
     'port':int(hive_config.port), 
     'database':hive_config.database, 
     'username':hive_config.username, 
     'password':hive_config.password, 
     'auth':hive_config.auth}
    delete_keys = []
    for key, value in conn_config.items():
        if not value:
            delete_keys.append(key)

    for key in delete_keys:
        del conn_config[key]

    db_connection = hive.connect(**conn_config)
    data_pull = (pd.read_sql('select * from %s' % training_config.hive_table, con=db_connection)).astype(object)
    data_pull.columns = [col.split('.')[1] for col in data_pull.columns]
    return transform_data(data_pull)