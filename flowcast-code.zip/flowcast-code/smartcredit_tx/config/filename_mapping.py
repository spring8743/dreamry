# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/config/filename_mapping.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 2148 bytes
filename_mapping_OTP = {'invoice_date':{'default': {'filename_prefix':'OTP_ALL_SCBT_T_DOC_KEY_DTLS_', 
              'filename_type':'.txt', 
              'sep':'|', 
              'cols':[
               'cty_code', 'rec_id', 'deal_rec_id', 'doc_id', 'supplier_id', 'buyer_id', 'doc_type_code', 'doc_date', 'deal_id']}}, 
 'invoice_amount':{'default': {'filename_prefix':'OTP_ALL_SCBT_T_DOC_PROC_DTLS_', 
              'filename_type':'.txt', 
              'sep':'|', 
              'cols':[
               'rec_id', 'doc_id', 'doc_ccy_code', 'doc_ccy_amt', 'fin_flag']}}, 
 'invoice_detail':{'default': {'filename_prefix':'OTP_ALL_SCBT_T_DOC_ADDL_DTLS_', 
              'filename_type':'.txt', 
              'sep':'|', 
              'cols':[
               'rec_id', 'doc_id', 'tenor', 'tenor_start_date', 'due_date', 'grace_period', 'maturity_date', 'fin_tenor_start_date', 'fin_tenor', 'to_seq_no', 'from_seq_no']}}, 
 'deal_hist':{'default': {'filename_prefix':'OTP_ALL_SCBT_T_DEAL_HIST_', 
              'filename_type':'.txt', 
              'sep':'|', 
              'cols':[
               'sale_ledger_flag', 'pool_based_flag', 'step_code', 'deal_id', 'product_variant_code', 'rel_seq_no', 'value_date']}}, 
 'pymt':{'default': {'filename_prefix':'OTP_ALL_SCBT_T_PYMT_ALLOC_DTLS_', 
              'filename_type':'.txt', 
              'sep':'|', 
              'cols':[
               'doc_id', 'deal_rec_id', 'pymt_ccy_code', 'pymt_alloc_amt', 'doc_ccy_code', 'pymt_to_doc_fx_rate']}}, 
 'pymt_dtls':{'default': {'filename_prefix':'OTP_ALL_SCBT_T_PYMT_DTLS_', 
              'filename_type':'.txt', 
              'sep':'|', 
              'cols':[
               'deal_rec_id', 'pymt_value_date']}}}
filename_mapping_CG = {'CG':{'filenames':[
   'cg_data.txt',
   'cg_data_add.csv'], 
  'sep':[
   '\t',
   ',']}, 
 'sci_link':{'filenames':[
   'sci_link_otp.txt',
   'sci_link_add.csv'], 
  'sep':[
   '\t',
   ','], 
  'cols_to_rename':[{},
   {'otp_party_id': 'cust_id'}]}}