# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/explanations_lr.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 1786 bytes
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from smartcredit_tx.train import response_list
import numpy as np, pandas as pd, logging, gc
logger = logging.getLogger('root.explanations')
top_n = 5

def binarize_labels(data):
    return {response:data[response] == 0 for response in response_list}


def generate_explanations(data, data_exploded):
    response_bin = binarize_labels(data)
    scaler = StandardScaler(with_mean=False)
    scaled_data = scaler.fit_transform(data_exploded)
    for response in response_list:
        logger.debug('Starting to generate explanations for %s' % response)
        model = LogisticRegression(penalty='l1', fit_intercept=False)
        logger.debug('Response bin stats: %s' % repr(response_bin[response].value_counts()))
        model.fit(scaled_data, response_bin[response])
        preds = [1 if x == True else -1 for x in model.predict(scaled_data)]
        arr = np.multiply(scaled_data, model.coef_)
        arr = arr * np.array(preds).reshape(-1, 1)
        ix = np.argsort(np.abs(arr) * -1)[:, :top_n]
        response_label = response.replace('_buckets', '')
        data[[response_label + '_explanation_value_' + str(i + 1) for i in range(0, top_n)]] = pd.DataFrame(np.array([arr[x][ix[x]] for x in range(len(ix))]))
        del arr
        gc.collect()
        data[[response_label + '_explanation_column_' + str(i + 1) for i in range(0, top_n)]] = pd.DataFrame(np.array([np.array(data_exploded.columns)[ix[x]] for x in range(len(ix))]))

    return data