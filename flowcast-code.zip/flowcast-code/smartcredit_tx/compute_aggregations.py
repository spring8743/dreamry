# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/compute_aggregations.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 12062 bytes
"""
    smartcredit.compute_aggregations
    ~~~~~~~~~~~~~~
    :copyright: � 2018 by Flowcast Inc.

usage: compute_aggregations.py [-h]
        [--dr_weights [DR_WEIGHTS [DR_WEIGHTS ...]]]
        [--ld_weights [LD_WEIGHTS [LD_WEIGHTS ...]]]
        [--dr_field_name DR_FIELD_NAME]
        [--ld_field_name LD_FIELD_NAME]
        [--dr_bands_label_ranges DR_BANDS_LABEL_RANGES]
        [--ld_bands_label_ranges LD_BANDS_LABEL_RANGES]
        [--dr_bands DR_BANDS] [--ld_bands LD_BANDS]
        [--dr_bands_fc DR_BANDS_FC]
        [--ld_bands_fc LD_BANDS_FC]
        [--dr_bands_labels DR_BANDS_LABELS]
        [--ld_bands_labels LD_BANDS_LABELS]
        [--rolling_back_windows [ROLLING_BACK_WINDOWS ...]]
        [--discount_rate DISCOUNT_RATE]
        [--start_date START_DATE] [--end_date END_DATE]
        [--months MONTHS]
        [--hive_input_host HIVE_INPUT_HOST]
        [--hive_input_port HIVE_INPUT_PORT]
        [--hive_input_db HIVE_INPUT_DB]
        [--hive_input_auth HIVE_INPUT_AUTH]
        [--hive_input_username HIVE_INPUT_USERNAME]
        [--hive_input_password HIVE_INPUT_PASSWORD]
        [--hive_input_table HIVE_INPUT_TABLE]
        [--hive_tmp_table_name HIVE_TMP_TABLE_NAME]
        [--hive_output_host HIVE_OUTPUT_HOST]
        [--hive_output_port HIVE_OUTPUT_PORT]
        [--hive_output_db HIVE_OUTPUT_DB]
        [--hive_output_auth HIVE_OUTPUT_AUTH]
        [--hive_output_username HIVE_OUTPUT_USERNAME]
        [--hive_output_password HIVE_OUTPUT_PASSWORD]
        [--hive_output_table HIVE_OUTPUT_TABLE]
        [--hive_input_primary_key HIVE_INPUT_PRIMARY_KEY]
        [--hive_input_product_key HIVE_INPUT_PRODUCT_KEY]
        [--hive_input_amount_expr HIVE_INPUT_AMOUNT_EXPR]
        [--hive_output_truncate HIVE_OUTPUT_TRUNCATE]
        [--hive_output_table_format HIVE_OUTPUT_TABLE_FORMAT]
"""
__version__ = '1.4.0'
import argparse, datetime, logging, pandas, flowcast.logging
from calendar import monthrange
from flowcast.config import BaseConfig
from smartcredit.args import SellerMonthlyArgs
from smartcredit.templates.aggregations import TIMEFRAME_TEMP_SQL, TIMEFRAME_TEMP_SQL_VAL, EXPLANATIONS_SQL, SELLER_MONTHLY_CREATE_TABLE_SQL, PRE_AGG_NA_FILL, TRUNCATE_SQL
from smartcredit.helpers.aggregations import prepare_agg_query, compute_flowcast_score, timeframe_ranges, get_inline_sql, prepare_expl_agg_query, get_top_n_features, get_score_bands
from smartcredit.helpers.db import load_data_from_query, get_hive_cursor, write_to_hive, get_hive_conn, exec_in_hive
from smartcredit.helpers.date_utils import last_day_of_month_as_str, get_lower_boundary_date_as_str, get_date_target_range, decrease_month
logger = logging.getLogger('root.compute_aggregations')
logging.getLogger('pyhive').setLevel(logging.WARNING)

def fetch_aggregated_data(params, hive_conn):
    """Fetch aggregated data from hive using the aggregation query
    Args:
        params: Namespace object with the corresponding attributes.
        hive_conn: Hive connection object.
    
    Returns:
        Pandas DataFrame object with the following columns:
            seller_id, late_days_score, dilution_rate_score,
            late_days_confidence, dilution_rate_confidence,
            cost_of_lateness, cost_of_dilution, total_amount
    """
    lower_date_boundary = get_lower_boundary_date_as_str(params.target_date, params.rolling_back_windows, '%Y-%m-%d %H:%M:%S')
    lower_limit_window = max(params.rolling_back_windows,
      key=lambda x: float(x))
    query_str = prepare_agg_query(params.ld_weights, params.dr_weights, params.ld_field_name, params.dr_field_name, params.target_date, lower_date_boundary, lower_limit_window, params.ld_bands, params.ld_bands_fc, params.dr_bands, params.dr_bands_fc, params.discount_rate, params.hive_input_table, params.hive_tmp_table_name, params.hive_input_primary_key, params.hive_input_product_key, params.hive_input_amount_expr)
    logger.debug('Creating temporary table using query [%s]' % (TIMEFRAME_TEMP_SQL.format(table_name=params.hive_tmp_table_name)))
    exec_in_hive(TIMEFRAME_TEMP_SQL.format(table_name=params.hive_tmp_table_name), hive_conn)
    exec_in_hive(TIMEFRAME_TEMP_SQL_VAL.format(table_name=params.hive_tmp_table_name,
      values=(',').join(timeframe_ranges(params.rolling_back_windows))), hive_conn)
    logger.debug('Running the following query in hive: [%s]' % query_str)
    data = load_data_from_query(query_str, hive_conn)
    return data


def fetch_aggregated_explanations(query, hive_conn):
    """Fetch aggregated data from hive using the aggregation query
    Args:
        table_name: Soruce table name where documents predictions are stored.
        prefix: Explanation field name prefix.
        tfs: List of timeframes to be queries for.
        hive_conn: Hive connection object.
    
    Returns:
        Pandas DataFrame containing aggregated explanation data by seller id.
    """
    logger.debug('Fetching explanation data using this query: [%s]' % query)
    data = load_data_from_query(query, hive_conn)
    return data


def prepare_output_table(params):
    """Prepare output's table
    Args:
        params: Namespace object with the corresponding attributes.
    """
    conn_config = {'host':params.hive_output_host, 
     'port':int(params.hive_output_port), 
     'database':params.hive_output_db, 
     'username':params.hive_output_username, 
     'auth':params.hive_output_auth, 
     'password':params.hive_output_password}
    out_table_query = SELLER_MONTHLY_CREATE_TABLE_SQL.format(table_name=params.hive_output_table,
      tbl_format=params.hive_output_table_format)
    logger.debug('Creating output table if not exists Query: [%s]' % out_table_query)
    exec_in_hive(out_table_query, get_hive_conn(conn_config))
    if params.hive_output_truncate:
        logger.info('Truncating data from output table')
        exec_in_hive(TRUNCATE_SQL.format(table_name=params.hive_output_table), get_hive_conn(conn_config))


def store_aggregated_data(data, params):
    """Store aggregated data into hive using
    Args:
        data: Pandas DataFrame object.
        params: Namespace object with the corresponding attributes.
    """
    conn_config = {'host':params.hive_output_host, 
     'port':int(params.hive_output_port), 
     'database':params.hive_output_db, 
     'username':params.hive_output_username, 
     'auth':params.hive_output_auth, 
     'password':params.hive_output_password}
    logger.info("Fetching output's table schema")
    output_table = load_data_from_query('SELECT * FROM %s LIMIT 1' % params.hive_output_table, get_hive_conn(conn_config))
    columns = list(map(lambda x: x.split('.')[-1], list(output_table.columns)))
    logger.info('Inserting records in output table %s' % params.hive_output_table)
    records_stored = write_to_hive(data, columns, params.hive_output_table, get_hive_cursor(conn_config))
    logger.info('%d records stored into hive@%s' % (
     records_stored, params.hive_output_host))


def process_data(target_date, params):
    """Exexute and process data for the target date.
    Args:
        target_date: String object representing target date.
        params: Namespace object with attributes coming from cli args.
    """
    logger.info(('Processing date for: {target_date}').format(target_date=target_date))
    setattr(params, 'target_date', target_date)
    conn_config = {'host':params.hive_input_host, 
     'port':int(params.hive_input_port), 
     'database':params.hive_input_db, 
     'username':params.hive_input_username, 
     'auth':params.hive_input_auth, 
     'password':params.hive_input_password}
    hive_conn = get_hive_conn(conn_config)
    pre_agg_data = fetch_aggregated_data(params, hive_conn)
    ld_query = prepare_expl_agg_query(params.hive_input_table, params.rolling_back_windows, 'late_days_explanation_', params.target_date, params.hive_tmp_table_name, params.hive_input_primary_key, params.hive_input_amount_expr)
    dr_query = prepare_expl_agg_query(params.hive_input_table, params.rolling_back_windows, 'dr_explanation_', params.target_date, params.hive_tmp_table_name, params.hive_input_primary_key, params.hive_input_amount_expr)
    expl_agg_data_ld = fetch_aggregated_explanations(ld_query, hive_conn)
    ld_explanations = get_top_n_features(expl_agg_data_ld, 'late_days_explanation_')
    expl_agg_data_dr = fetch_aggregated_explanations(dr_query, hive_conn)
    dr_explanations = get_top_n_features(expl_agg_data_dr, 'dr_explanation_')
    if pre_agg_data.empty:
        logger.critical('No data availalble for date %s\n Config params: [%s]' % (
         params.target_date, str(params)))
        return
        pre_agg_data = pre_agg_data.fillna(PRE_AGG_NA_FILL)
        for postfix in ('_window', '_month'):
            pre_agg_data['flowcast_score' + postfix] = pre_agg_data.apply(lambda row: compute_flowcast_score(float(row['cost_of_dilution' + postfix]), float(row['cost_of_lateness' + postfix]), float(row['dilution_rate_score' + postfix]), float(row['late_days_score' + postfix])),
              axis=1)
            pre_agg_data['pg' + postfix] = pre_agg_data.apply(lambda row: compute_flowcast_score(float(row['cost_of_dilution' + postfix]), float(row['cost_of_lateness' + postfix]), float(row['dilution_rate_score' + postfix]), float(row['late_days_score' + postfix])),
              axis=1)

        get_score_bands(pre_agg_data, params.dr_bands, params.dr_bands_labels, [
         'dilution_rate_avg_window', 'dilution_rate_avg_month'])
        get_score_bands(pre_agg_data, params.ld_bands, params.ld_bands_labels, [
         'late_days_avg_window', 'late_days_avg_month'])
        agg_data = pandas.merge(pre_agg_data,
          ld_explanations,
          how='left',
          on=[
         'seller_id', 'rolling_month_window'])
        agg_data = pandas.merge(agg_data,
          dr_explanations,
          how='left',
          on=[
         'seller_id', 'rolling_month_window'])
        store_aggregated_data(agg_data, params)


def main():
    """ Load data from input sources, calculate aggregations for each
    score and outputs to the target sources
    """
    params = SellerMonthlyArgs().get_params()
    logger.info(('Getting Seller Monthly Score for {start_date} to {end_date}').format(start_date=params.start_date,
      end_date=params.end_date))
    logger.info('Using the following parameters: %s' % (';').join([
     'dr_weights: %s' % params.dr_weights,
     'ld_weights: %s' % params.ld_weights,
     'dr_bands_label_ranges: %s' % params.dr_bands_label_ranges,
     'ld_bands_label_ranges: %s' % params.ld_bands_label_ranges,
     'rolling_back_windows: %s' % params.rolling_back_windows,
     'discount_rate: %s' % params.discount_rate]))
    prepare_output_table(params)
    date_ranges = get_date_target_range(params.start_date, params.end_date)
    for date in date_ranges:
        process_data(date, params)


if __name__ == '__main__':
    main()