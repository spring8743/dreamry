# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/train.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 7379 bytes
import pandas as pd, numpy as np, six, csv, logging
from smartcredit_tx.config.feature_definitions import feature_definitions_data
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix as cm
from smartcredit import SCBModel
import flowcast.logging
logger = logging.getLogger('root.train')
logging.getLogger('pyhive').setLevel(logging.WARNING)
labels = {'dr_buckets':[
  '0%', '0%-2%', '2%-5%', '5%-10%', '10%+'], 
 'late_days_buckets':[
  '0', '0-15', '15-30', '30-60', '60-90', '90+']}
features = {'grace_period':'float', 
 'tenor':'float', 
 'fin_tenor':'float', 
 'doc_usd_amt':'float', 
 'due_date_dow':'float', 
 'maturity_date_dow':'float', 
 'cg':'object', 
 'product':'object', 
 'doc_ccy_code':'object', 
 'cty_code':'object', 
 'days_between_fin_tenor_and_due_date':'int', 
 'days_between_fin_tenor_and_tenor':'int', 
 'quarter':'object', 
 'client_%_doc_usd_amt_previous_q1':'float', 
 'client_%_doc_usd_amt_previous_q2':'float', 
 'client_%_doc_usd_amt_previous_q3':'float', 
 'client_%_doc_usd_amt_previous_q4':'float', 
 'buyer_country':'object', 
 'supplier_country':'object', 
 'doc_type_code':'object'}
features_time = {'currency_volatility':'float', 
 'currency_vector':'float'}
response_list = [
 'late_days_buckets', 'dr_buckets']

def add_features_to_dict(features_dict, extra_features_dict, df_cols):
    """
    Logic to add the windowed features to the features_dict
    """
    for k, v in six.iteritems(extra_features_dict):
        cols = df_cols[df_cols.str.contains(k)]
        for col in cols:
            features_dict[col] = 'float'


def features_expand(df, features, features_time, features_definitions_data):
    """
    Add the windowed features to the features_dict to be used in training
    """
    add_features_to_dict(features, features_time, df.columns)
    add_features_to_dict(features, features_definitions_data, df.columns)


def convert_data(df, features, date_column_id):
    """
    Take the list of training features and convert the column types. Split the features
    by numeric and categorical, then vectorize the dataframe's categorical features.
    Set the multiindex to the date_column_id + responses
    """
    for feature, typ in six.iteritems(features):
        if df[feature].dtype != typ:
            df[feature] = df[feature].astype(typ)

    numeric_features = [f for f in features.keys() if features[f] != 'object']
    categorical_features = [f for f in features.keys() if features[f] == 'object']
    result_df = df.set_index([date_column_id] + response_list + ['doc_id'], inplace=False)
    result_df = pd.get_dummies(result_df[numeric_features + categorical_features])
    result_df = result_df[sorted(result_df.columns.tolist())]
    return (
     result_df, result_df.columns, numeric_features, categorical_features)


def split_training_data(df, date_column_id, lower_cutoff, upper_cutoff):
    """
    Split the train and validation dataframe by 2 cutoff dates. Training data will equal <= lower_cutoff
    Validation data will equal > lower_cutoff and <= upper_cutoff.
    """
    date_lower_cutoff = pd.to_datetime(lower_cutoff)
    dates = pd.to_datetime(df.index.get_level_values(date_column_id))
    if upper_cutoff is None:
        date_upper_cutoff = max(dates)
    else:
        date_upper_cutoff = pd.to_datetime(upper_cutoff)
    train_ix = list(dates <= date_lower_cutoff)
    valid_ix = list((date_lower_cutoff < dates) & (dates <= date_upper_cutoff))
    return (
     train_ix, valid_ix)


def gen_model(data, response, train_ix, valid_ix, random_state, num_trees, max_depth, min_samples_leaf, n_jobs=-2):
    """
    Generate randomforest classifier on the training data. Produce the
    confusion matrix on the training and validation set
    """
    data_train = data[train_ix]
    data_valid = data[valid_ix]
    model = RandomForestClassifier(num_trees, random_state=random_state,
      n_jobs=n_jobs,
      max_depth=max_depth,
      min_samples_leaf=min_samples_leaf)
    model.fit(data_train, data_train.index.get_level_values(response))
    logger.info((' ').join((
     repr(response),
     'train:',
     repr(cm(data_train.index.get_level_values(response), model.predict(data_train))))))
    if len(data_valid) != 0:
        logger.info((' ').join((
         repr(response),
         'valid:',
         repr(cm(data_valid.index.get_level_values(response), model.predict(data_valid))))))
    return model


def model_importances(rf_model, columns):
    """
    Return a dataframe of features and the model importances from the randomforest
    """
    return pd.DataFrame({'features':columns,  'importances':rf_model.feature_importances_}).sort_values('importances',
      ascending=False)


def train(data, lower_cutoff='2017-03-01', upper_cutoff=None, date_column_id='doc_date', write_filename=None, random_state=None, models_folder=None, num_trees=500, max_depth=None, min_samples_leaf=1, column_filename='columns.csv', n_jobs=-2):
    """
    Logic to build a training and validation set, build model per each response, and return the model
    """
    models = dict()
    features_expand(data, features, features_time, feature_definitions_data)
    data_exploded, columns, numeric_features, categorical_features = convert_data(data, features, date_column_id)
    train_ix, valid_ix = split_training_data(data_exploded, date_column_id, lower_cutoff, upper_cutoff)
    for response in response_list:
        rf_model = gen_model(data_exploded, response, train_ix, valid_ix, random_state, num_trees, max_depth, min_samples_leaf, n_jobs)
        models[response] = rf_model
        response_label = response + '_pred'
        data.loc[:, response_label] = rf_model.predict(data_exploded)
        data.loc[:, response_label + '_confidence'] = np.max(rf_model.predict_proba(data_exploded), axis=1)
        data[[response_label + '_' + str(i) for i in range(len(set(data[response])))]] = pd.DataFrame(rf_model.predict_proba(data_exploded))
        if models_folder:
            model = SCBModel(models_folder, response)
            model.store_model(rf_model, data.rename(columns={'client': '_client'}), numeric_features, categorical_features, labels[response])

    if write_filename is not None:
        data.to_csv(write_filename, index=False)
    if column_filename is not None:
        with open(column_filename, 'w') as (wr_file):
            wr = csv.writer(wr_file, quoting=csv.QUOTE_ALL)
            wr.writerow(list(columns))
    return (
     models, data_exploded, columns, numeric_features, categorical_features)