# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/utils/compute_complex_features.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 2540 bytes
from time import time
import six, logging
logger = logging.getLogger('scr-transaction')

def process_features(df_subset, feature_definitions, ids, date_range, date_column_name, df):
    """
    For each feature in 'feature_definitions', compute the rolling window feature off
    the 'ids' and for the 'date_range' given. Compute this for the df_subset and set
    the values in the df.
    """
    id_column_name = ids.index.name
    for feature in feature_definitions:
        label = ('_').join([id_column_name, feature, date_range])
        params = {'df':df_subset,  'on':date_column_name, 
         'id_column_name':id_column_name, 
         'date_range':'36000d' if date_range == 'all' else date_range}
        for k, v in six.iteritems(feature_definitions[feature]['params']):
            params[k] = v

        df.at[(df_subset.index, label)] = feature_definitions[feature]['fn'](**params)


def process_features_by_date_range(df, feature_definitions, date_ranges, ids, date_column_name):
    """
    For the list of 'date_ranges', compute process_features for the list of 'ids' given
    Also, time is printed for benchmarking purposes. This should be logged instead.
    """
    id_count = 0
    t0 = time()
    total_ids = len(ids)
    for id_ in ids.index:
        df_subset = df[df[ids.index.name] == id_]
        for date_range in date_ranges:
            process_features(df_subset, feature_definitions, ids, date_range, date_column_name, df)

        id_count += 1
        if id_count % 50 == 0:
            logger.info(('{} / {} in {}s so far').format(id_count, total_ids, time() - t0))


def compute_complex_features(df, feature_definitions, date_ranges, compute_by=[
 'client', 'buyer_supplier'], date_column_name='doc_date'):
    """
    Given the 'date_ranges', features in 'feautre_definitions', id types to 'compute_by' and 
    the date column 'date_column_name' to run the rolling window calcs on, compute the 
    additional features.
    """
    for id_column_name in compute_by:
        df = df.sort_values([id_column_name, date_column_name]).reset_index(drop=1)
        ids = df.groupby(id_column_name)[date_column_name].agg(['min'])
        process_features_by_date_range(df, feature_definitions, date_ranges, ids, date_column_name)

    df.fillna(0, inplace=True)
    df = df.round(5)
    return df