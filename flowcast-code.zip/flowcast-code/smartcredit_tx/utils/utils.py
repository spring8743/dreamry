# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/utils/utils.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 1183 bytes
import os, pandas as pd

def convert_dates(df, date_col_list):
    """
    Convert a column of date-objects to pandas datetime format
    Need to add fix if the dates do not come year-first
    """
    if not type(date_col_list) is list:
        raise AssertionError
    for col in date_col_list:
        df = df[~pd.isnull(df[col])]
        df = df[df[col].str.startswith('2')]
        df[col] = pd.to_datetime(df[col], errors='coerce')

    return df


def convert_floats(df, float_col_list):
    """
    Convert a column of float-objects to floats
    """
    if not type(float_col_list) is list:
        raise AssertionError
    for col in float_col_list:
        df[col] = df[col].astype(float, copy=False)

    return df


def agg_df_to_max_col(df, max_col, by):
    """
    For a df, take the highest value of column 'max_col' by the 
    list of columns in 'by'
    """
    return (df.sort_values(max_col, ascending=False)).drop_duplicates(by)


def find_file(filename, root_dir):
    """
    Find all instances of 'filename' in the 'root_dir'
    """
    result = []
    for root, dirs, files in os.walk(root_dir):
        if filename in files:
            result.append(os.path.join(root, filename))

    return result