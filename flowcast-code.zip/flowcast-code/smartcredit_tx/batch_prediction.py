# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/batch_prediction.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 19317 bytes
from smartcredit_tx.data_ingestion import transform_data
from smartcredit_tx.compute_simple_features import compute_simple_features
from smartcredit_tx.utils.compute_complex_features import compute_complex_features
from smartcredit_tx.config.feature_definitions import feature_definitions_data, feature_definitions_currency, date_ranges_data
from smartcredit_tx.explanations_lr import generate_explanations
from smartcredit import SCBModel
from smartcredit.helpers.date_utils import get_date_ranges
from smartcredit.models import PredictionModel
from datetime import datetime, timedelta, date
from flowcast.config import BaseConfig
import flowcast.logging, argparse, pandas, sys, gc, time, numpy as np, logging
from pyhive import hive
logger = logging.getLogger('root.batch_prediction')
logging.getLogger('pyhive').setLevel(logging.WARNING)

class BatchPrediction(object):
    model_names = [
     'dr_buckets', 'late_days_buckets']
    config = (BaseConfig(section='batch_prediction')).get()
    hive_config = (BaseConfig(section='hive')).get()
    models = {}
    input_columns = [
     'doc_ccy_amt', 'doc_ccy_code', 'doc_ccy_adj_amt', 'doc_id', 'buyer_id', 'doc_date', 'supplier_id', 'doc_type_code', 'tenor', 'tenor_start_date', 'due_date', 'grace_period', 'maturity_date', 'fin_tenor_start_date', 'fin_tenor', 'goods_category_code', 'goods_desc', 'ship_from', 'ship_to', 'product_code', 'pymt_ccy_code', 'pymt_value_date', 'pymt_alloc_amt', 'pymt_to_doc_fx_rate', 'supplier_name', 'supplier_country', 'buyer_name', 'buyer_country', 'isic_code', 'industry_sector', 'credit_grade', 'sci_city', 'sci_state', 'sci_address_line_1', 'sci_address_line_2', 'year_rate', 'cust_leid', 'cty_code', 'dr', 'late_days']
    insert_fields = {'data':[
      'doc_id', 'doc_date', 'doc_usd_amt', 'supplier_id', 'supplier_country', 'buyer_id', 'buyer_country', 'dr', 'dr_buckets', 'late_days', 'late_days_buckets', 'leid', 'product', 'pymt_alloc_amt', 'pymt_to_doc_fx_rate', 'year_rate'], 
     'explanations':[
      'late_days_explanation_column_1', 'late_days_explanation_column_2', 'late_days_explanation_column_3', 'late_days_explanation_column_4', 'late_days_explanation_column_5', 'late_days_explanation_value_1', 'late_days_explanation_value_2', 'late_days_explanation_value_3', 'late_days_explanation_value_4', 'late_days_explanation_value_5', 'dr_explanation_column_1', 'dr_explanation_column_2', 'dr_explanation_column_3', 'dr_explanation_column_4', 'dr_explanation_column_5', 'dr_explanation_value_1', 'dr_explanation_value_2', 'dr_explanation_value_3', 'dr_explanation_value_4', 'dr_explanation_value_5'], 
     'predictions':[
      'dr_buckets_pred', 'dr_buckets_pred_0', 'dr_buckets_pred_1', 'dr_buckets_pred_2', 'dr_buckets_pred_3', 'dr_buckets_pred_4', 'dr_buckets_pred_5', 'dr_buckets_pred_6', 'dr_buckets_pred_7', 'dr_buckets_pred_8', 'dr_buckets_pred_9', 'dr_buckets_pred_confidence', 'late_days_buckets_pred', 'late_days_buckets_pred_0', 'late_days_buckets_pred_1', 'late_days_buckets_pred_2', 'late_days_buckets_pred_3', 'late_days_buckets_pred_4', 'late_days_buckets_pred_5', 'late_days_buckets_pred_6', 'late_days_buckets_pred_7', 'late_days_buckets_pred_8', 'late_days_buckets_pred_9', 'late_days_buckets_pred_confidence']}

    def __init__(self, days_back, start_date, end_date):
        PredictionModel._tablename_ = self.config.output_table
        if start_date:
            self.start_date = start_date
        else:
            self.start_date = getattr(self.config, 'start_date', None)
        if end_date:
            self.end_date = end_date
        else:
            self.end_date = getattr(self.config, 'end_date', None)
        if days_back:
            self.days_back = days_back
        else:
            self.days_back = getattr(self.config, 'days_back', 365)
        self.days_back = int(self.days_back)
        self.skip_explanations_on_fail = getattr(self.config, 'skip_explanations_on_fail', 1)
        self.model_version = getattr(self.config, 'model_version', datetime.now().isoformat())
        self.batch_size = int(getattr(self.config, 'batch_size', 1000))
        self.load_time_stamp = None
        self.generate_explanations_flag = int(getattr(self.config, 'generate_explanations', 1))
        if not self.generate_explanations_flag:
            logger.info('Explanations disabled.')
        self.load_models()
        self.connect_to_hive()
        self.model_schema = self.models[self.model_names[0]].model_schema
        self.query = "\n\t\t\tselect {columns_hist}\n\t\t\t, 0 as predict_me\n\t\t\tfrom {hive_historical_tablename} as hist\n\t\t\twhere \n\t\t\thist.buyer_id in (select distinct a.buyer_id from {hive_daily_tablename} as a where a.product_code in ('IFNB', 'VSRP'))\n\t\t\tand hist.product_code in ('IFNB', 'VSRP')\n\t\t\tand from_unixtime(unix_timestamp(hist.doc_date , 'yyyy-MM-dd')) >= from_unixtime(unix_timestamp('{min_doc_date}', 'yyyy-MM-dd'))\n\t\t\tunion\n\t\t\tselect {columns_hist}\n\t\t\t, 0 as predict_me\n\t\t\tfrom {hive_historical_tablename} as hist\n\t\t\twhere \n\t\t\thist.supplier_id in (select distinct a.supplier_id from {hive_daily_tablename} as a where a.product_code not in ('IFNB', 'VSRP'))\n\t\t\tand hist.product_code not in ('IFNB', 'VSRP')\n\t\t\tand from_unixtime(unix_timestamp(hist.doc_date , 'yyyy-MM-dd')) >= from_unixtime(unix_timestamp('{min_doc_date}', 'yyyy-MM-dd'))\n\t\t\tunion\n\n\t\t\tselect {columns}\n\t\t\t, 1 as predict_me \n\t\t\tfrom {hive_daily_tablename}\n\t\t\t{where_clause}\n\n\t\t\t{limit_clause}\n\t\t"

    def connect_to_hive(self):
        logger.info('Connecting to Hive...')
        conn_config = {'host':self.hive_config.host, 
         'port':int(self.hive_config.port), 
         'database':self.hive_config.database, 
         'username':self.hive_config.username, 
         'auth':self.hive_config.auth, 
         'password':self.hive_config.password}
        delete_keys = []
        for key, value in conn_config.items():
            if not value:
                delete_keys.append(key)

        for key in delete_keys:
            del conn_config[key]

        self.hive_conn = hive.Connection(**conn_config)

    def load_models(self):
        for model_name in self.model_names:
            logger.info('Loading model %s' % model_name)
            model = SCBModel(self.config.models_path, model_name)
            model.load_predictor()
            model.load_model_schema()
            self.models[model_name] = model

    def load_as_df(self):
        if getattr(self.config, 'query_limit', None):
            limit = getattr(self.config, 'query_limit')
            limit_clause = 'limit %s' % limit
            logger.info('Limiting query to %s rows' % limit)
        else:
            limit_clause = ''
        if self.start_date or self.end_date:
            where_clause = '\n\t\t\t\twhere  \n\t\t\t\t{start_date_where_clause} \n\t\t\t\t{operator}\n\t\t\t\t{end_date_where_clause} \n\t\t\t'
            if self.start_date:
                start_date_where_clause = (" \n\t\t\t\t\tfrom_unixtime(unix_timestamp(doc_date , 'yyyy-MM-dd')) >= from_unixtime(unix_timestamp('{start_date}', 'yyyy-MM-dd')) \n\t\t\t\t").format(start_date=self.start_date)
            else:
                start_date_where_clause = ''
            if self.end_date:
                end_date_where_clause = (" \n\t\t\t\t\tfrom_unixtime(unix_timestamp(doc_date , 'yyyy-MM-dd')) < from_unixtime(unix_timestamp('{end_date}', 'yyyy-MM-dd')) \n\t\t\t\t").format(end_date=self.end_date)
            else:
                end_date_where_clause = ''
            if bool(self.start_date) != bool(self.end_date):
                operator = ''
            else:
                operator = 'and'
            where_clause = where_clause.format(start_date_where_clause=start_date_where_clause,
              end_date_where_clause=end_date_where_clause,
              operator=operator)
        else:
            where_clause = ''
        min_query = ('\n\t\t\tselect min(doc_date) as min_doc_date \n\t\t\tfrom {hive_daily_tablename}\n\t\t\t{where_clause}\n\t\t').format(hive_daily_tablename=self.config.hive_daily_tablename, where_clause=where_clause)
        logger.debug('min_doc_date query formed: %s' % min_query)
        cursor = self.hive_conn.cursor()
        cursor.execute(min_query)
        min_date_docs_to_predict = cursor.fetchall()[0][0]
        cursor.close()
        if min_date_docs_to_predict == None:
            logger.info('No documents to predict in the specified date range. Exiting.')
            return
            min_doc_date = (datetime.strptime(min_date_docs_to_predict, '%Y-%m-%d') - (timedelta(days=self.days_back))).strftime('%Y-%m-%d')
            logger.info('Using %s as the starting doc_date to pull history' % min_doc_date)
            query = self.query.format(columns=(',').join(self.input_columns),
              columns_hist=(',').join(['hist.%s' % column for column in self.input_columns]),
              days_back=self.days_back,
              limit_clause=limit_clause,
              min_doc_date=min_doc_date,
              hive_daily_tablename=self.config.hive_daily_tablename,
              hive_historical_tablename=self.config.hive_historical_tablename,
              where_clause=where_clause)
            logger.debug('Main query formed: %s' % query)
            logger.info('Reading rows...')
            self.load_time_stamp = datetime.now()
            data = (pandas.read_sql(query, con=self.hive_conn)).astype(object)
            data.columns = [col.split('.')[1] for col in data.columns]
            logger.info('Loaded rows, shape is %s. %s rows to be predicted.' % (repr(data.shape), len(data[data['predict_me'] == 1].index)))
            return data

    def generate_predictions(self, data):
        columns_to_extract = self.model_schema['model_fields']['numeric_features'] + self.model_schema['model_fields']['categorical_features']
        data = data.rename(columns={'client': 'client_id'})
        extra_columns = [
         'client_id', 'buyer_id', 'supplier_id']
        for column in ('client_%_doc_usd_amt_previous_q1', 'client_%_doc_usd_amt_previous_q2',
                       'client_%_doc_usd_amt_previous_q3', 'client_%_doc_usd_amt_previous_q4'):
            if column not in data.columns.tolist():
                logger.info('Column %s not found. Filling with 0.' % column)
                data[column] = 0

        data_to_predict = data[columns_to_extract + extra_columns]
        predictors = data_to_predict.to_dict('records')
        predictions_ld = self.models['late_days_buckets'].predict(predictors, False, False)
        predictions_dr = self.models['dr_buckets'].predict(predictors, False, False)
        predictions_ld = self.extract_ld_prediction_fields(predictions_ld)
        predictions_dr = self.extract_dr_prediction_fields(predictions_dr)
        predictions_ld = pandas.DataFrame(predictions_ld)
        predictions_dr = pandas.DataFrame(predictions_dr)
        data = data.rename(columns={'client_id': 'client'})
        data = pandas.concat([data, predictions_ld, predictions_dr], axis=1)
        return data

    def compute_derived_features(self, data):
        data = compute_simple_features(data, feature_definitions_currency)
        self.output_debug_info(data, 'After simple features:')
        data = compute_complex_features(data, feature_definitions_data, date_ranges_data)
        self.output_debug_info(data, 'After complex features:')
        return data

    def generate_explanations(self, data):
        columns_to_extract = self.model_schema['model_fields']['numeric_features'] + self.model_schema['model_fields']['categorical_features']
        data = data.rename(columns={'client': 'client_id'})
        extra_columns = ['client_id', 'buyer_id', 'supplier_id']
        features_df = data[columns_to_extract + extra_columns]
        model = self.models[list(self.models.keys())[0]]
        features_df = model.one_hot_encode_df(features_df)
        features_df = features_df.drop(columns=['client_id', 'buyer_id', 'supplier_id'])
        features_df = features_df[sorted(features_df.columns.tolist())]
        logger.debug('Data shape at generate explanations: %s' % repr(data.shape))
        data = generate_explanations(data, features_df)
        return data

    def extract_data_fields(self, data):
        data = data[self.insert_fields['data']]
        data = data.to_dict('records')
        for index in range(len(data)):
            for key, value in data[index].items():
                if type(value) == pandas.Timestamp:
                    data[index][key] = data[index][key].isoformat()

        return data

    def extract_prediction_fields(self, data):
        predictions = data[self.insert_fields['predictions']]
        predictions = predictions.to_dict('records')
        return predictions

    def extract_explanation_fields(self, data):
        explanations = data[self.insert_fields['explanations']]
        explanations = explanations.to_dict('records')
        return explanations

    def get_prediction_from_probabilities(self, probs):
        threshold = 0.5
        cum_sum = 0
        for index, prob in enumerate(probs):
            cum_sum += prob
            if cum_sum >= threshold:
                return index

    def extract_dr_prediction_fields(self, predictions):
        labels = [
         '0%', '0%-2%', '2%-5%', '5%-10%', '10%+']
        results = []
        for prediction in predictions:
            result = {}
            result['dr_buckets_pred'] = self.get_prediction_from_probabilities(prediction['probability'].values())
            result['dr_buckets_pred_confidence'] = prediction['buckets_confidence']
            for i in range(len(labels)):
                result['dr_buckets_pred_%s' % i] = prediction['probability'][labels[i]]

            for i in range(len(labels), 10):
                result['dr_buckets_pred_%s' % i] = None

            results.append(result)

        return results

    def extract_ld_prediction_fields(self, predictions):
        labels = [
         '0', '0-15', '15-30', '30-60', '60-90', '90+']
        results = []
        for prediction in predictions:
            result = {}
            result['late_days_buckets_pred'] = self.get_prediction_from_probabilities(prediction['probability'].values())
            result['late_days_buckets_pred_confidence'] = prediction['buckets_confidence']
            for i in range(len(labels)):
                result['late_days_buckets_pred_%s' % i] = prediction['probability'][labels[i]]

            for i in range(len(labels), 10):
                result['late_days_buckets_pred_%s' % i] = None

            results.append(result)

        return results

    def get_extra_fields(self):
        extra_fields = {}
        extra_fields['model_version'] = self.model_version
        extra_fields['load_time_stamp'] = self.load_time_stamp
        return extra_fields

    def cast_fields_for_insertion(self, row):
        row['doc_date'] = datetime.strptime(row['doc_date'], '%Y-%m-%dT%H:%M:%S')
        for key, value in row.items():
            try:
                if np.isnan(value):
                    row[key] = None
            except:
                pass

        return row

    def build_records_for_insertion(self, data):
        logger.info('Extracting fields from predictions, explanations and data...')
        data = data.replace('NA', np.nan)
        if self.generate_explanations_flag:
            explanations = self.extract_explanation_fields(data)
        predictions = self.extract_prediction_fields(data)
        data = self.extract_data_fields(data)
        results = []
        extra_fields = self.get_extra_fields()
        for index, data_ in enumerate(data):
            if self.generate_explanations_flag:
                data_.update(explanations[index])
            data_.update(predictions[index])
            data_.update(extra_fields)
            data_ = self.cast_fields_for_insertion(data_)
            results.append(data_)

        return results

    def output_debug_info(self, data, message):
        logger.debug('%s\n %s \n %s' % (
         message,
         repr(data['dr_buckets'].value_counts()),
         repr(data['late_days_buckets'].value_counts())))

    def insert_records(self, records):
        logger.info('Inserting to Hive...')
        insert_count = 0
        for record in records:
            prediction = PredictionModel(**record)
            prediction.add()
            insert_count += 1

        logger.info('Added %s models to insert queue.' % insert_count)
        PredictionModel.flush(batch_size=self.batch_size)
        logger.info('Inserted %s rows.' % insert_count)

    def clear_output_table(self):
        PredictionModel.truncate_table()

    def main(self):
        logger.info('Starting batch prediction job for dates %s - %s...' % (repr(self.start_date), repr(self.end_date)))
        data = self.load_as_df()
        if data is None:
            return
            if data.shape[0] == 0:
                logger.info('Empty data for dates, exiting')
                return
                if data[data['predict_me'] == 0].shape[0] == 0:
                    logger.info('Empty historical data, exiting')
                data['daily_nulls'] = (data['predict_me'] == 1) & (data['dr'].isnull() | data['late_days'].isnull())
                data.loc[(data['daily_nulls'], ['dr', 'late_days'])] = 0
                logger.info('Transforming data...')
                data = transform_data(data)
                logger.info('Computing features...')
                data = self.compute_derived_features(data)
                logger.info('Generating predictions...')
                data = self.generate_predictions(data)
                self.output_debug_info(data, 'After predictions features')
                logger.info('Generating explanations...')
        if self.generate_explanations_flag:
            try:
                data = self.generate_explanations(data)
            except Exception as exc:
                logger.critical('Critical exception: %s' % exc)
                if self.skip_explanations_on_fail:
                    self.generate_explanations_flag = False
                else:
                    raise

            data.loc[(data['daily_nulls'], ['dr', 'late_days', 'dr_buckets', 'late_days_buckets'])] = np.nan
            logger.info('Filtering...')
            data = data[data['predict_me'] == 1]
            if data.shape[0] == 0:
                logger.info('No rows left after filtering. Exiting...')
                return
                logger.info('Filtered, shape is now %s...' % repr(data.shape))
                if getattr(self.config, 'clear_output_table', '0') == '1':
                    self.clear_output_table()
                records = self.build_records_for_insertion(data)
                self.insert_records(records)


def get_dates_counts():
    config = (BaseConfig(section='batch_prediction')).get()
    hive_config = (BaseConfig(section='hive')).get()
    conn_config = {'host':hive_config.host, 
     'port':int(hive_config.port), 
     'database':hive_config.database, 
     'username':hive_config.username, 
     'auth':hive_config.auth, 
     'password':hive_config.password}
    delete_keys = []
    for key, value in conn_config.items():
        if not value:
            delete_keys.append(key)

    for key in delete_keys:
        del conn_config[key]

    hive_conn = hive.Connection(**conn_config)
    query = 'SELECT {date_field} AS doc_date, COUNT(1) AS doc_count\n\tFROM {daily_table}\n\tGROUP BY {date_field}\n\tORDER BY {date_field}\n\t'
    query = query.format(date_field='doc_date',
      daily_table=config.hive_daily_tablename)
    data = (pandas.read_sql(query, con=hive_conn)).astype(object)
    data['doc_date'] = pandas.to_datetime(data['doc_date'])
    data = data.sort_values('doc_date').reset_index(drop=True)
    return data


parser = argparse.ArgumentParser(description='Imports CSV files to Hive')
parser.add_argument('--days_back', type=str, help='The number of days back')
parser.add_argument('--start_date', type=str, help='The start date for processing')
parser.add_argument('--end_date', type=str, help='The end date for processing')
parser.add_argument('--chunk_size_limit', type=int, default=5000, help='The end date for processing')
parser.add_argument('--chunk_days_limit', type=int, default=365, help='The end date for processing')
args = parser.parse_args()
if args.start_date is not None or args.end_date is not None:
    dates_ranges = [
     (
      args.start_date, args.end_date)]
else:
    dates_counts = get_dates_counts()
    dates_ranges = get_date_ranges(dates_counts, args.chunk_size_limit, args.chunk_days_limit)
for start_dt, end_dt in dates_ranges:
    BP = BatchPrediction(days_back=args.days_back,
      start_date=start_dt,
      end_date=end_dt)
    BP.main()