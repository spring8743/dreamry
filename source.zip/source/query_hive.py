# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/query_hive.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 2564 bytes
from pyhive import hive
from flowcast.config import BaseConfig
from datetime import date, datetime
import json

def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
        raise TypeError('Type %s not serializable' % type(obj))


config = (BaseConfig(section='smartcredit_transaction')).get()
cols = ['buyer_country', 'buyer_id', 'doc_date', 'doc_id', 'doc_usd_amt', 'dr', 'dr_buckets', 'dr_buckets_explanation_column_1', 'dr_buckets_explanation_column_2', 'dr_buckets_explanation_column_3', 'dr_buckets_explanation_column_4', 'dr_buckets_explanation_column_5', 'dr_buckets_explanation_value_1', 'dr_buckets_explanation_value_2', 'dr_buckets_explanation_value_3', 'dr_buckets_explanation_value_4', 'dr_buckets_explanation_value_5', 'dr_buckets_pred', 'dr_buckets_pred_0', 'dr_buckets_pred_1', 'dr_buckets_pred_2', 'dr_buckets_pred_3', 'dr_buckets_pred_4', 'dr_buckets_pred_5', 'dr_buckets_pred_6', 'dr_buckets_pred_7', 'dr_buckets_pred_8', 'dr_buckets_pred_9', 'dr_buckets_pred_confidence', 'late_days', 'late_days_buckets', 'late_days_buckets_explanation_column_1', 'late_days_buckets_explanation_column_2', 'late_days_buckets_explanation_column_3', 'late_days_buckets_explanation_column_4', 'late_days_buckets_explanation_column_5', 'late_days_buckets_explanation_value_1', 'late_days_buckets_explanation_value_2', 'late_days_buckets_explanation_value_3', 'late_days_buckets_explanation_value_4', 'late_days_buckets_explanation_value_5', 'late_days_buckets_pred', 'late_days_buckets_pred_0', 'late_days_buckets_pred_1', 'late_days_buckets_pred_2', 'late_days_buckets_pred_3', 'late_days_buckets_pred_4', 'late_days_buckets_pred_5', 'late_days_buckets_pred_6', 'late_days_buckets_pred_7', 'late_days_buckets_pred_8', 'late_days_buckets_pred_9', 'late_days_buckets_pred_confidence', 'supplier_country', 'supplier_id']
conn_config = {'host':config.host, 
 'database':config.database, 
 'username':config.username, 
 'auth':config.auth, 
 'password':config.password}
delete_keys = []
for key, value in conn_config.items():
    if not value:
        delete_keys.append(key)

for key in delete_keys:
    del conn_config[key]

hive_conn = hive.connect(**conn_config)
hive_cursor = hive_conn.cursor()
hive_cursor.execute('\n\tselect * from %s \n' % config.output_table)
results = hive_cursor.fetchall()
cols = [desc[0] for desc in hive_cursor.description]
rows = []
for result in results:
    row = {cols[i]:result[i] for i in range(len(cols))}
    rows.append(row)

print(json.dumps(rows, indent=4, default=json_serial))