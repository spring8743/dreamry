# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/compute_cust_cntpty.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 12018 bytes
"""
    smartcredit.compute
    ~~~~~~~~~~~~~~
    :copyright: � 2018 by Flowcast Inc.

usage: compute_cust_cntpty.py [-h]
        [--dr_weights [DR_WEIGHTS [DR_WEIGHTS ...]]]
        [--ld_weights [LD_WEIGHTS [LD_WEIGHTS ...]]]
        [--dr_field_name DR_FIELD_NAME]
        [--ld_field_name LD_FIELD_NAME]
        [--dr_bands_label_ranges DR_BANDS_LABEL_RANGES]
        [--ld_bands_label_ranges LD_BANDS_LABEL_RANGES]
        [--dr_bands DR_BANDS] [--ld_bands LD_BANDS]
        [--dr_bands_fc DR_BANDS_FC]
        [--ld_bands_fc LD_BANDS_FC]
        [--dr_bands_labels DR_BANDS_LABELS]
        [--ld_bands_labels LD_BANDS_LABELS]
        [--rolling_back_windows [ROLLING_BACK_WINDOWS ...]]
        [--discount_rate DISCOUNT_RATE]
        [--start_date START_DATE] [--end_date END_DATE]
        [--months MONTHS]
        [--hive_input_host HIVE_INPUT_HOST]
        [--hive_input_port HIVE_INPUT_PORT]
        [--hive_input_db HIVE_INPUT_DB]
        [--hive_input_auth HIVE_INPUT_AUTH]
        [--hive_input_username HIVE_INPUT_USERNAME]
        [--hive_input_password HIVE_INPUT_PASSWORD]
        [--hive_input_table HIVE_INPUT_TABLE]
        [--hive_tmp_table_name HIVE_TMP_TABLE_NAME]
        [--hive_output_host HIVE_OUTPUT_HOST]
        [--hive_output_port HIVE_OUTPUT_PORT]
        [--hive_output_db HIVE_OUTPUT_DB]
        [--hive_output_auth HIVE_OUTPUT_AUTH]
        [--hive_output_username HIVE_OUTPUT_USERNAME]
        [--hive_output_password HIVE_OUTPUT_PASSWORD]
        [--hive_output_table HIVE_OUTPUT_TABLE]
        [--hive_input_primary_key HIVE_INPUT_PRIMARY_KEY]
        [--hive_input_product_key HIVE_INPUT_PRODUCT_KEY]
        [--hive_input_amount_expr HIVE_INPUT_AMOUNT_EXPR]
        [--hive_output_truncate HIVE_OUTPUT_TRUNCATE]
        [--hive_output_table_format HIVE_OUTPUT_TABLE_FORMAT]
        [--hive_input_buyer_key HIVE_INPUT_BUYER_KEY]
        [--hive_cust_cntpty_tmp_tbl HIVE_CUST_CNTPTY_TMP_TBL]
"""
__version__ = '1.0.0'
import argparse, datetime, logging, pandas, numpy, flowcast.logging
from calendar import monthrange
from flowcast.config import BaseConfig
from smartcredit.templates.aggregations import SELLER_BUYER_SQL, CUST_CNTPTY_TEMP_SQL, INSERT_INTO_CUST_CNTPTY_SQL, TRUNCATE_SQL, SELLER_BUYER_MONTHLY_CREATE_TABLE_SQL, PRE_AGG_NA_FILL, TIMEFRAME_TEMP_SQL, TIMEFRAME_TEMP_SQL_VAL
from smartcredit.args import SellerBuyerMonthlyArgs
from smartcredit.helpers.aggregations import compute_flowcast_score, timeframe_ranges, prepare_agg_query_cust_cntpty, get_score_bands, return_if_not_null
from smartcredit.helpers.db import load_data_from_query, get_hive_cursor, write_to_hive, get_hive_conn, exec_in_hive
from smartcredit.helpers.date_utils import last_day_of_month_as_str, get_lower_boundary_date_as_str, get_date_target_range, decrease_month, get_upper_boundary_date_as_str
logger = logging.getLogger('root.compute_aggregations')
logging.getLogger('pyhive').setLevel(logging.WARNING)

def fetch_aggregated_data(params, hive_conn, cust, cntpty):
    """Fetch aggregated data from hive using the aggregation query
    Args:
        params: Namespace object with the corresponding attributes.
        hive_conn: Hive connection object.
    
    Returns:
        Pandas DataFrame object with the following columns:
            seller_id, late_days_score, dilution_rate_score,
            late_days_confidence, dilution_rate_confidence,
            cost_of_lateness, cost_of_dilution, total_amount
    """
    cust_op = None
    cntpty_op = None
    count = False
    if cust:
        if cntpty:
            cust_op = cntpty_op = '='
            count = True
        if cust:
            cust_op = '='
            cntpty_op = '!='
        else:
            if cntpty:
                cust_op = '!='
                cntpty_op = '='
        query_str = prepare_agg_query_cust_cntpty(params.target_date, params.lower_date_boundary, params.ld_bands, params.dr_bands, params.hive_input_table, params.hive_tmp_table_name, params.hive_cust_cntpty_tmp_tbl, params.hive_input_primary_key, params.hive_input_buyer_key, cust_op, cntpty_op, params.hive_input_amount_expr, count)
        logger.debug('Running the following query in hive: [%s]' % query_str)
        data = load_data_from_query(query_str, hive_conn)
        return data


def prepare_output_table(params):
    """Prepare output's table
    Args:
        params: Namespace object with the corresponding attributes.
    """
    conn_config = {'host':params.hive_output_host, 
     'port':int(params.hive_output_port), 
     'database':params.hive_output_db, 
     'username':params.hive_output_username, 
     'auth':params.hive_output_auth, 
     'password':params.hive_output_password}
    out_table_query = SELLER_BUYER_MONTHLY_CREATE_TABLE_SQL.format(table_name=params.hive_output_table,
      tbl_format=params.hive_output_table_format)
    logger.debug('Creating output table if not exists Query: [%s]' % out_table_query)
    exec_in_hive(out_table_query, get_hive_conn(conn_config))
    if params.hive_output_truncate:
        logger.info('Truncating data from output table')
        exec_in_hive(TRUNCATE_SQL.format(table_name=params.hive_output_table), get_hive_conn(conn_config))


def store_aggregated_data(data, params):
    """Store aggregated data into hive using
    Args:
        data: Pandas DataFrame object.
        params: Namespace object with the corresponding attributes.
    """
    conn_config = {'host':params.hive_output_host, 
     'port':int(params.hive_output_port), 
     'database':params.hive_output_db, 
     'username':params.hive_output_username, 
     'auth':params.hive_output_auth, 
     'password':params.hive_output_password}
    logger.info("Fetching output's table schema")
    output_table = load_data_from_query('SELECT * FROM %s LIMIT 1' % params.hive_output_table, get_hive_conn(conn_config))
    columns = list(map(lambda x: x.split('.')[-1], list(output_table.columns)))
    logger.info('Inserting records in output table %s' % params.hive_output_table)
    records_stored = write_to_hive(data, columns, params.hive_output_table, get_hive_cursor(conn_config))
    logger.info('%d records stored into hive@%s' % (
     records_stored, params.hive_output_host))


def process_data(target_date, params):
    """Exexute and process data for the target date.
    Args:
        target_date: String object representing target date.
        params: Namespace object with attributes coming from cli args.
    """
    logger.info(('Processing date for: {target_date}').format(target_date=target_date))
    setattr(params, 'target_date', target_date)
    lower_date_boundary = get_lower_boundary_date_as_str(params.target_date, params.rolling_back_windows, '%Y-%m-%d %H:%M:%S')
    setattr(params, 'lower_date_boundary', lower_date_boundary)
    conn_config = {'host':params.hive_input_host, 
     'port':int(params.hive_input_port), 
     'database':params.hive_input_db, 
     'username':params.hive_input_username, 
     'auth':params.hive_input_auth, 
     'password':params.hive_input_password}
    hive_conn = get_hive_conn(conn_config)
    logger.debug('Creating temporary table using query [%s]' % (TIMEFRAME_TEMP_SQL.format(table_name=params.hive_tmp_table_name)))
    exec_in_hive(TIMEFRAME_TEMP_SQL.format(table_name=params.hive_tmp_table_name), hive_conn)
    exec_in_hive(TIMEFRAME_TEMP_SQL_VAL.format(table_name=params.hive_tmp_table_name,
      values=(',').join(timeframe_ranges(params.rolling_back_windows))), hive_conn)
    logger.debug('Creating temporary table using query [%s]' % (CUST_CNTPTY_TEMP_SQL.format(table_name=params.hive_cust_cntpty_tmp_tbl)))
    exec_in_hive(CUST_CNTPTY_TEMP_SQL.format(table_name=params.hive_cust_cntpty_tmp_tbl), hive_conn)
    exec_in_hive(INSERT_INTO_CUST_CNTPTY_SQL.format(temp_table=params.hive_cust_cntpty_tmp_tbl,
      cust_col=params.hive_input_primary_key,
      cntpty_col=params.hive_input_buyer_key,
      table=params.hive_input_table,
      date_col='doc_date',
      start_date=lower_date_boundary,
      end_date=get_upper_boundary_date_as_str(params.target_date, '%Y-%m-%d %H:%M:%S')), hive_conn)
    groups = [
     'cust_sel_cntpty', 'cust_oth_cntpty', 'cntpty_oth_cust']
    groups_mappings = [(True, True), (True, False), (False, True)]
    dataframes = []
    for g, gm in zip(groups, groups_mappings):
        pre_agg_data = fetch_aggregated_data(params, hive_conn, *gm)
        if pre_agg_data.empty:
            logger.debug('No data availalble for date %s\n Config params: [%s]' % (
             params.target_date, str(params)))
            continue
        pre_agg_data = pre_agg_data.fillna(PRE_AGG_NA_FILL)
        get_score_bands(pre_agg_data, params.dr_bands, params.dr_bands_labels, [
         'dilution_rate_avg_window', 'dilution_rate_avg_month'])
        get_score_bands(pre_agg_data, params.ld_bands, params.ld_bands_labels, [
         'late_days_avg_window', 'late_days_avg_month'])
        for postfix in ('_window', '_month'):
            pre_agg_data[g + '_ps' + postfix] = pre_agg_data.apply(lambda row: row['late_days_avg' + postfix] + row['dilution_rate_avg' + postfix],
              axis=1)
            pre_agg_data[g + '_txn_amt' + postfix] = pre_agg_data['txn_amount' + postfix]
            pre_agg_data[g + '_txn_count' + postfix] = pre_agg_data['txn_count' + postfix]

        pre_agg_data['rolling_month_window'] = pre_agg_data['rolling_month_window'].apply(int)
        dataframes.append(pre_agg_data)

    if len(dataframes) == 0:
        logger.critical('No data available for: %s' % params.target_date)
        return
        agg_data = dataframes[0]
        for i in range(1, len(dataframes)):
            agg_data = pandas.merge(agg_data,
              dataframes[i],
              how='outer',
              on=[
             'leid', 'cntpty_id', 'month_name', 'rolling_month_window'])

        agg_data['load_time_stamp'] = agg_data.apply(lambda row: return_if_not_null([
         row.get('load_time_stamp'),
         row.get('load_time_stamp_x'),
         row.get('load_time_stamp_y')]),
          axis=1)
        agg_data['model_version'] = agg_data.apply(lambda row: return_if_not_null([
         row.get('model_version'),
         row.get('model_version_x'),
         row.get('model_version_y')]),
          axis=1)
        agg_data = agg_data[agg_data['cust_sel_cntpty_ps_window'].notnull()]
        store_aggregated_data(agg_data, params)


def main():
    """ Load data from input sources, calculate aggregations for each
    score and outputs to the target sources
    """
    params = SellerBuyerMonthlyArgs().get_params()
    logger.info(('Getting Seller-Buyer Score for {start_date} to {end_date}').format(start_date=params.start_date,
      end_date=params.end_date))
    prepare_output_table(params)
    date_ranges = get_date_target_range(params.start_date, params.end_date)
    for date in date_ranges:
        process_data(date, params)


if __name__ == '__main__':
    main()