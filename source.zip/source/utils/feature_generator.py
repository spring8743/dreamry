# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/utils/feature_generator.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 2143 bytes
import pandas as pd, numpy as np

def add_window_delay(df, on, calculated_field, id_column_name, shift_amount=90):
    """
    For adding delay to the window due to information coming a 'shfit_amount' later in time,
    in days
    """
    shifted_df = pd.DataFrame({on: [x + pd.DateOffset(shift_amount) for x in df[on]], 
     id_column_name: df[id_column_name], 
     calculated_field: df[calculated_field]})
    min_date = min(df[on])
    max_date = max(df[on])
    shifted_df = shifted_df.query(("{} <= '{}'").format(on, max_date))
    shifted_df = shifted_df.merge(pd.DataFrame({on: pd.date_range(min_date, max_date)}), on=on,
      how='outer')
    return shifted_df.sort_values(on)


def rolling_window_feature(df, on, id_column_name, date_range, calculated_field, agg_fn, shift_amount=90):
    """
    Given a dataframe 'df', date column 'on', the 'calculated_field' to run the calc on,
    and the type of aggregating function to perform on the lookback subset 'agg_fn',
    return a list of windowed aggregated calcs to join to df. 
    Items of the same date should have the same value (no peering into the future) and start 
    with knowledge only on yesterday and prior.
    Allowed agg_fn :
    count
    sum
    mean
    median
    var
    std
    min
    max
    corr
    corr_pairwise
    cov
    skew
    kurt
    quantile
    """
    if shift_amount:
        calced_df = add_window_delay(df, on, calculated_field, id_column_name, shift_amount)
    if not shift_amount:
        calced_df = df.copy()
    calcs = (calced_df[[on, calculated_field]].rolling(date_range,
      on=on, closed='left'))[calculated_field]
    rolling_calcs = pd.DataFrame({on: calced_df[on], 
     'calcs': getattr(calcs, agg_fn)()})
    result = (calced_df[[on, id_column_name]].merge(rolling_calcs[~rolling_calcs[on].duplicated()],
      how='left')).drop_duplicates()
    result = df[[on]].merge(result, how='left')
    return list(result['calcs'])