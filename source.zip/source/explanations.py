# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/explanations.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 3569 bytes
from lime import lime_tabular
import numpy as np
from sklearn.externals import joblib
from multiprocessing import Pool
import pickle

def convert_dataframe(df, feature_names, categorical_feature_names_dict, categorical_names_full):
    numerical_features = [x for x in feature_names if x not in categorical_feature_names_dict.values()]
    return_df = df[numerical_features]
    for k, v in categorical_feature_names_dict.items():
        columns = [x for x in data_features.columns if x in (' ').join(categorical_names_full[k])]
        df_sub = df[columns]
        return_df[v] = np.argmax(np.array(df_sub), axis=1)

    return return_df


def encoder_transform_row(data_row, schema, categorical_feature_names_dict, categorical_names):
    numerical_features = [i for i, v in enumerate(schema) if v not in categorical_feature_names_dict.values()]
    return_array = data_row[numerical_features]
    for i, v in categorical_names.items():
        feature_array = np.zeros(len(v))
        feature_array[int(data_row[i])] = np.array(1)
        return_array = np.append(return_array, feature_array)

    return return_array


def encoder_transform(data, schema, categorical_feature_names_dict, categorical_names):
    return np.array([encoder_transform_row(i, schema, categorical_feature_names_dict, categorical_names) for i in np.array(data)])


categorical_feature_names = [
 'cty_code', 'doc_type_code', 'doc_ccy_code', 'fin_ccy_code', 'product_variant_code',
 'product', 'CG', 'industry_code']
feature_names = list(data_features.columns[0:78]) + categorical_feature_names
categorical_features = range(78, len(feature_names))
categorical_feature_names_dict = {k:v for k, v in zip(categorical_features, categorical_feature_names)}
categorical_names = {}
categorical_names_full = {}
for feature in categorical_features:
    existing_feature_list = list(data_features.columns[data_features.columns.str.contains(feature_names[feature])])
    if feature == feature_names.index('product'):
        existing_feature_list = [x for x in existing_feature_list if len(x) < 20]
    categorical_names[feature] = [x.split('_')[-1] for x in existing_feature_list]
    categorical_names_full[feature] = [x for x in existing_feature_list]

data_explanations = convert_dataframe(data_features, feature_names, categorical_feature_names_dict, categorical_names_full)
schema = data_explanations.columns
exp = lime_tabular.LimeTabularExplainer(np.array(data_explanations.sample(100000)), feature_names=data_explanations.columns,
  categorical_features=categorical_features,
  categorical_names=categorical_names,
  discretize_continuous=0)
predict_fn = lambda x: rf.predict_proba(encoder_transform(x, schema, categorical_feature_names_dict, categorical_names))

def explanation_fn(i):
    e = exp.explain_instance(data_explanations.loc[i], predict_fn,
      top_labels=1, num_features=30, num_samples=10000)
    return e.as_list(np.argmax(e.predict_proba))


if __name__ == 'smartcredit_tx.explanations':
    pool = Pool(processes=None)
    results = pool.map(explanation_fn, range(0, len(data_explanations)))
    with open('explanations.pkl', 'wb') as (fp):
        pickle.dump(results, fp)