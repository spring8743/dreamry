# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/compute_simple_features.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 7750 bytes
import pandas as pd, numpy as np, sqlite3, logging, sys
from functools import reduce
from smartcredit_tx.config.feature_definitions import feature_definitions_currency
from smartcredit_tx.utils.compute_complex_features import compute_complex_features
import flowcast.logging
logger = logging.getLogger('root.compute_features')
dr_boundaries = [
 0, 1e-10, 0.02, 0.05, 0.1, 1.1]
late_days_boundaries = [0, 1e-10, 15, 30, 60, 90, float('inf')]

def load_currency_xchange_data(filename):
    """
    Load the external currency exchange file.
    """
    currency_df = pd.read_csv(filename).dropna(axis=1, how='all')
    currency_df['Date'] = pd.to_datetime(currency_df['Date'])
    currency_df['yr-mo'] = [str(x)[0:7] for x in currency_df['Date']]
    return currency_df


def convert_currency(currency_df, date, ccy, amt):
    """
    Convert a currency amount 'amt' by the currency exchange table currency_df. Currently using
    the monthly average of the currency exchange. Should change to more accurate daily
    represenation.
    """
    df = pd.DataFrame({'Date':date.dt.date,  'CCY':ccy, 
     'amt':amt})
    df['yr-mo'] = [str(x)[0:7] for x in df['Date']]
    currency_df['yr-mo'] = [str(x)[0:7] for x in currency_df['Date']]
    currency_df = currency_df.groupby(['CCY', 'yr-mo']).agg({'Rate': np.mean}).reset_index()
    df = df.merge(currency_df, how='left')
    df.loc[(df['CCY'] == 'USD', 'Rate')] = 1
    return list(df['Rate'].astype(float).multiply(df['amt'].astype(float)))


def compute_currency_features(data_df, currency_df, feature_definitions_currency, date_ranges=[
 '7d', '30d', '180d'], compute_by=[
 'CCY'], date_column_name='Date'):
    """
    Compute volatility and vector time-based metrics on the 'currency_df'. Take monthly average and join
    to the 'data_df'. Should change to more accurate daily represenation.
    """
    currency_df = compute_complex_features(currency_df, feature_definitions_currency, date_ranges, compute_by=compute_by,
      date_column_name=date_column_name)
    agg_currency_df_list = []
    for date_range in date_ranges:
        volatility_label = 'currency_volatility_' + date_range
        vector_label = 'currency_vector_' + date_range
        stddev_label = ('_').join([compute_by[0], 'currency', 'stddev', date_range])
        mean_label = ('_').join([compute_by[0], 'currency', 'mean', date_range])
        currency_df[volatility_label] = currency_df[stddev_label] / currency_df[mean_label]
        currency_df[vector_label] = (currency_df['Rate'] - currency_df[mean_label]) / currency_df['Rate']
        agg_currency_df_list.append(currency_df[['yr-mo', compute_by[0], volatility_label, vector_label]].groupby([
         compute_by[0], 'yr-mo']).agg({volatility_label: np.mean, 
         vector_label: np.mean}).reset_index())

    agg_currency_df = reduce(lambda a, b: pd.merge(a, b), agg_currency_df_list)
    df = data_df[['doc_date', 'doc_ccy_code']]
    df['yr-mo'] = [str(x)[0:7] for x in df['doc_date']]
    df = (df.merge(agg_currency_df, how='left', left_on=[
     'yr-mo', 'doc_ccy_code'],
      right_on=[
     'yr-mo', 'CCY'])).fillna(0)
    return pd.concat([data_df, df.drop(['yr-mo', 'CCY', 'doc_date', 'doc_ccy_code'], axis=1)], axis=1)


def compute_response_buckets(response, boundary_list):
    """
    For the response series, enumerate the buckets by the boundary_list
    """
    if not type(boundary_list) is list:
        raise AssertionError
    return pd.cut(response, bins=boundary_list, right=False, labels=False)


def compute_labels(df, feature_definitions_currency):
    """
    Convert the currencies of doc_ccy_amt to usd, calculate the dilution amount, and
    calculate the late days labels
    """
    df['doc_ccy_amt_fixed'] = df['doc_ccy_amt'].add(df['doc_ccy_adj_amt'])
    df['doc_usd_amt'] = df['doc_ccy_amt_fixed'].multiply(df['year_rate'])
    df['pymt_ccy_amt'] = df['pymt_alloc_amt'] * df['pymt_to_doc_fx_rate']
    df = df[~df['dr'].isin(['NA'])]
    df = df[~df['late_days'].isin(['NA'])]
    df['late_days'] = df['late_days'].astype(float)
    df['dr'] = df['dr'].astype(float)
    df['is_diluted'] = df['dr'] > 0
    df['dr_buckets'] = compute_response_buckets(df['dr'], dr_boundaries)
    df['is_late'] = df['late_days'] > 0
    df['late_days_buckets'] = compute_response_buckets(df['late_days'], late_days_boundaries)
    ld_buckets_counts = df['late_days_buckets'].value_counts()
    dr_buckets_counts = df['dr_buckets'].value_counts()
    logger.info('Buckets counts LD: %s & DR: %s' % (
     ld_buckets_counts,
     dr_buckets_counts))
    if len(dr_buckets_counts) != len(dr_boundaries) - 1 or len(ld_buckets_counts) != len(late_days_boundaries) - 1:
        logger.critical('Buckets count different that expected')
    return df


def compute_quarter(df, date='doc_date'):
    """
    Compute which quarter the date is in.
    input: a series of datetime values
    output: DataFrame with quarter feature based on dates
    """
    month = pd.to_datetime(df[date]).dt.month
    df.loc[:, 'quarter'] = ((month - 1) / 3 + 1).astype(int)
    df.loc[:, 'year'] = df['doc_date'].dt.year


def compute_percent_by_quarter(df, amt='doc_usd_amt', by='client'):
    """
    Compute quarterly percentage amt for each client.
    Example: % amount in Q1 2018 = total_invoice_amount (Jan, Feb, Mar) in 2017 / total_invoice_amount(full year) in 2017
    """
    yearly = df.groupby([by, 'year'])['doc_usd_amt'].sum().reset_index()
    quarterly = df.groupby([by, 'year', 'quarter'])['doc_usd_amt'].sum().reset_index()
    merge = quarterly.merge(yearly, how='left', on=[by, 'year'])
    quarterly['client_%_doc_usd_amt_previous_q'] = (merge['doc_usd_amt_x'] / merge['doc_usd_amt_y']).values.tolist()
    quarterly = quarterly.reset_index()
    quarterly['year'] = quarterly['year'] + 1
    quarterly.drop(columns=['doc_usd_amt', 'index'], inplace=True)
    quarterly_percentage_amt = quarterly.set_index([by, 'year', 'quarter']).unstack().fillna(0).reset_index()
    quarterly_percentage_amt.columns = quarterly_percentage_amt.columns.map(('{0[0]}{0[1]}').format)
    return quarterly_percentage_amt


def compute_simple_features(df, feature_definitions_currency):
    """
    Convert and compute a few simple metrics on the full dataframe
    """
    df['client'] = np.where(df['product'].isin(['IFNB', 'VSRP']), df.buyer_id, df.supplier_id)
    df['buyer_supplier'] = [('_').join([str(x), str(y)]) for x, y in zip(df.buyer_id, df.supplier_id)]
    df = compute_labels(df, feature_definitions_currency)
    df['due_date_dow'] = [pd.to_datetime(x).weekday() for x in df.due_date]
    df['maturity_date_dow'] = [pd.to_datetime(x).weekday() for x in df.maturity_date]
    df = df.query('dr >= 0.0')
    df = df.dropna()
    df.loc[:, 'days_between_fin_tenor_and_tenor'] = (df['fin_tenor_start_date'] - df['tenor_start_date']).dt.days
    df.loc[:, 'days_between_fin_tenor_and_due_date'] = (df['due_date'] - df['fin_tenor_start_date']).dt.days
    compute_quarter(df)
    percent_amt_by_quarter = compute_percent_by_quarter(df)
    df = (df.merge(percent_amt_by_quarter, on=['client', 'year'], how='left')).fillna(0)
    df.drop(columns=['year'], inplace=True)
    df.reset_index(drop=True, inplace=True)
    return df