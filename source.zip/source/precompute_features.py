# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/precompute_features.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 1686 bytes
"""
name = Trade Finance AI Engine
version = '0.1'
description = Generate ML models and validate against an out of time sample
author = Dr. Eitan Anzenberg, Flowcast
author_email = eitan.anzenberg@flowcast.ai
"""
import argparse
from smartcredit import FeaturesHandler
from smartcredit_tx.data_ingestion import load_data
from smartcredit_tx.compute_simple_features import compute_simple_features
from smartcredit_tx.utils.compute_complex_features import compute_complex_features
from smartcredit_tx.config.feature_definitions import feature_definitions_data, feature_definitions_currency, date_ranges_data
from smartcredit_tx.train import train

def main(sql_config_file='config/db.ini', lower_cutoff='2017-03-01', upper_cutoff=None):
    data = load_data()
    data = compute_simple_features(data, feature_definitions_currency)
    data = compute_complex_features(data, feature_definitions_data, date_ranges_data)
    precompute = (data.sort_values(['doc_date'], ascending=False)).groupby(['client', 'buyer_id', 'supplier_id']).head(1)
    precompute = precompute.rename(columns={'client': '_client'})
    FeaturesHandler.store_from_df(precompute)


if __name__ == 'smartcredit_tx.precompute_features':
    parser = argparse.ArgumentParser(description='Run datapipeline, train model,\noutput results on the validation set')
    parser.add_argument('-l', '--lower_cutoff', help='Date to start validation set', required=False, default='2017-03-01')
    parser.add_argument('-u', '--upper_cutoff', help='Date to end validation set', required=False, default=None)
    args = parser.parse_args()
    main(**vars(args))