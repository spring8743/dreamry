# uncompyle6 version 3.2.5
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.7.1 (default, Dec 10 2018, 22:54:23) [MSC v.1915 64 bit (AMD64)]
# Embedded file name: smartcredit_tx/config/feature_definitions.py
# Compiled at: 2019-03-07 20:39:23
# Size of source mod 2**32: 2547 bytes
from smartcredit_tx.utils import feature_generator
feature_definitions_data = {'past_invoice_count':{'fn':feature_generator.rolling_window_feature,  'params':{'calculated_field':'doc_usd_amt', 
   'agg_fn':'count'}}, 
 'doc_usd_amt_ave':{'fn':feature_generator.rolling_window_feature, 
  'params':{'calculated_field':'doc_usd_amt', 
   'agg_fn':'mean'}}, 
 'doc_usd_amt_stddev':{'fn':feature_generator.rolling_window_feature, 
  'params':{'calculated_field':'doc_usd_amt', 
   'agg_fn':'std'}}, 
 'late_days_ave':{'fn':feature_generator.rolling_window_feature, 
  'params':{'calculated_field':'late_days', 
   'agg_fn':'mean'}}, 
 'is_late_ave':{'fn':feature_generator.rolling_window_feature, 
  'params':{'calculated_field':'is_late', 
   'agg_fn':'mean'}}, 
 'dilution_ave':{'fn':feature_generator.rolling_window_feature, 
  'params':{'calculated_field':'dr', 
   'agg_fn':'mean'}}, 
 'term_ave':{'fn':feature_generator.rolling_window_feature, 
  'params':{'calculated_field':'fin_tenor', 
   'agg_fn':'mean'}}}
date_ranges_data = [
 '90d', '180d', '360d']
feature_definitions_currency = {'currency_stddev':{'fn':feature_generator.rolling_window_feature, 
  'params':{'calculated_field':'Rate', 
   'agg_fn':'std'}}, 
 'currency_mean':{'fn':feature_generator.rolling_window_feature, 
  'params':{'calculated_field':'Rate', 
   'agg_fn':'mean'}}}